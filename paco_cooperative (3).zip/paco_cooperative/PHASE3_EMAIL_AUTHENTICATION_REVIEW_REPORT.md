# PASCCO Phase 3 — Email and Authentication Review

## Changes
- Centralized SMTP transport setup in `includes/mail_config.php` so PMES, membership, OTP, password-reset, PMES-completion, and loan-reminder emails share the same transport configuration.
- SMTP host, port, encryption (`tls`, `ssl`, or `none`), and bounded timeout can now be configured in the private `C:/xampp/pascco-private/mail.php` file. Gmail defaults remain for compatibility.
- Updated `security/mail-config.example.php` with the new optional settings. Existing private config files continue to work through defaults.
- SMTP debug output is disabled, character encoding is set to UTF-8, and email exceptions are logged server-side rather than exposing SMTP details in the PMES response.
- Kept member email OTP and administrator authenticator/TOTP verification intact. No MFA method was removed or weakened.
- Added `tests/phase3_email_authentication_review_tests.php`.

## Configuration
Keep real SMTP credentials outside the project at `C:/xampp/pascco-private/mail.php`. Copy the example template and enter actual credentials locally. Never put SMTP passwords into the ZIP, source control, or a public web directory. Gmail typically requires an app password when two-step verification is enabled.

## Findings / items not changed
- Membership approval email currently includes a temporary password. This is a security concern and should be redesigned alongside the membership account activation/reset flow; removing it alone could lock newly approved members out, so this phase does not silently change that workflow.
- Loan notification idempotency uses the database unique key `(loan_id, notification_type, reference_date)` and skips records already marked sent. A failed record is retried on the next run. Concurrent scheduled runners may still race while sending before either records success; schedule only one runner until an atomic claim/lease workflow is implemented.
- Email OTP delivery and authenticator verification cannot be tested against a real mailbox or SMTP server in this environment.

## Validation
Static checks and PHP syntax checks only. Live XAMPP, database, SMTP delivery, mailbox receipt, and concurrent-run behavior were not tested. Existing test suite results are recorded separately by the build process.
