# PASCCO Phase 10 — Local XAMPP Acceptance Testing

## Purpose
This phase prepares a controlled local acceptance test. It does not apply migrations, reset simulation data, create accounts, or modify the database. Live checks must be run on the user's own XAMPP instance because the package environment does not have access to `C:\xampp\pascco-private\config.php` or the user's MariaDB server.

## Verified in the packaging environment
- `php tools/phase9_static_verification.php`: PASS — 106/106 PHP syntax checks, 9/9 JavaScript syntax checks, and 13/13 existing test scripts passed.
- `php tools/deployment_readiness.php`: 13 PASS, 2 CHECK, 0 FAIL, 3 MANUAL. The checks are environment-specific; private DB config and `pdo_mysql` were not available in this runtime.
- No live MySQL/MariaDB connection, browser sign-in, email delivery, MFA, or SQL import was tested.

## Before testing
1. Keep this phase package separate from your working project until you compare the files.
2. Back up the database if it contains anything you need to preserve. Never use a reset tool on a database you want to keep.
3. Start Apache and MySQL from XAMPP and confirm phpMyAdmin opens.
4. Confirm the private config exists at `C:\xampp\pascco-private\config.php`; do not paste or share its password.
5. Run Command Prompt as your normal user and change directory to the PASCCO project root.

## Read-only checks first
Run:

```bat
php tools/phase9_static_verification.php
php tools/deployment_readiness.php
php tools/migration_tracker.php list
php tools/database_schema_audit.php
```

The last two commands require the configured local database connection. The schema audit is intended to inspect metadata only. Save the complete output locally and redact usernames, paths, host details, and any secrets before sharing.

## Browser smoke-test checklist
Use only a test member and test transactions where possible. Do not create real-looking balances in a live or important database.

- [ ] Public home page and navigation load; no PHP warnings or missing assets.
- [ ] Member login, logout, session timeout, and MFA challenge behave as expected.
- [ ] Admin login and MFA work for the single administrator.
- [ ] Member can submit a loan application with valid inputs; invalid amounts and missing required fields are rejected.
- [ ] Admin can approve or reject a loan once; there is no second-admin requirement.
- [ ] Loan status and schedule are consistent after approval; no duplicate disbursement or payment records appear after refreshing/resubmitting.
- [ ] Deposit request and receipt upload work; invalid file types and oversized files are rejected.
- [ ] Withdrawal request remains pending until reviewed; submitting a request does not immediately debit the member's balance.
- [ ] Rejecting a request does not create a financial transaction; approving twice does not duplicate it.
- [ ] Announcements can be targeted to Public or Member as intended.
- [ ] Notifications, active sessions, login history, privacy/security settings, and certificates load with correct authorization.
- [ ] Dashboard charts show values consistent with the underlying test data and do not expose another member's records.
- [ ] Member pages reject access to another member's IDs/documents; admin-only pages reject member sessions.
- [ ] Upload files are not directly accessible without authorization.

## SQL import / migration policy
- Do not import every `.sql` file in the project as a batch.
- Do not run migrations against the current database until the baseline schema and migration prerequisites are confirmed.
- If SQL import testing is needed, create a separate disposable database on the same MariaDB/MySQL version, import the chosen baseline once, then apply only the ordered migrations that are required and not already present.
- Record the exact SQL filename, server version, import result, and first error. Stop at the first error; do not continue blindly.
- Do not fix duplicate account numbers or normalized emails by deleting/merging records automatically. Review findings deliberately.

## Result recording
Mark each smoke test PASS, FAIL, or BLOCKED and include a short redacted error message. A static pass is not a live acceptance pass. Do not describe this project as production-ready until live tests, backup restore, security/privacy review, and a real deployment review are complete.
