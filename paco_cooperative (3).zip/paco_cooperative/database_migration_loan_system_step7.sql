-- PASCCO Loan System Step 7 — Multi-Stage Loan Approval Workflow
-- Adds a two-admin approval workflow without changing financial policies.
-- Apply after database_migration_loan_system_step6.sql.

ALTER TABLE loans
    ADD COLUMN IF NOT EXISTS required_approvals TINYINT UNSIGNED NOT NULL DEFAULT 2,
    ADD COLUMN IF NOT EXISTS committee_submitted_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS committee_completed_at DATETIME NULL;

SET @loan_committee_index_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'loans'
      AND INDEX_NAME = 'idx_loans_committee_status'
);
SET @sql := IF(
    @loan_committee_index_exists = 0,
    'ALTER TABLE loans ADD INDEX idx_loans_committee_status (status, committee_submitted_at)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS loan_approval_reviews (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    reviewer_id INT UNSIGNED NOT NULL,
    decision ENUM('approved','rejected') NOT NULL,
    notes VARCHAR(500) DEFAULT NULL,
    reviewed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_loan_reviewer (loan_id, reviewer_id),
    INDEX idx_loan_reviews_loan (loan_id, reviewed_at),
    INDEX idx_loan_reviews_reviewer (reviewer_id, reviewed_at),
    CONSTRAINT fk_loan_reviews_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_loan_reviews_reviewer FOREIGN KEY (reviewer_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
