/* PASCCO Animation Phase 7 — final shared motion safeguards */
(function () {
  'use strict';
  var root = document.documentElement;
  var reduced = false;

  try {
    reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  } catch (error) {
    reduced = false;
  }

  root.setAttribute('data-pascco-motion', reduced ? 'reduced' : 'full');
  root.classList.add('pascco-motion-js');

  // Re-evaluate if the user changes the OS accessibility preference while the page is open.
  if (window.matchMedia) {
    var query = window.matchMedia('(prefers-reduced-motion: reduce)');
    var update = function (event) {
      root.setAttribute('data-pascco-motion', event.matches ? 'reduced' : 'full');
    };
    if (typeof query.addEventListener === 'function') {
      query.addEventListener('change', update);
    } else if (typeof query.addListener === 'function') {
      query.addListener(update);
    }
  }
})();
