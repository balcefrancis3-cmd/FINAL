/* PASCCO MEMBER DASHBOARD — PHASE 2 */
(function () {
    'use strict';

    const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function revealDashboard() {
        const groups = document.querySelectorAll('.pascco-dashboard-reveal, .pascco-dashboard-stagger');
        if (!groups.length) return;

        let delay = 0;
        groups.forEach((element) => {
            if (element.classList.contains('pascco-dashboard-stagger')) {
                element.setAttribute('data-dashboard-delay', String(Math.min(4, Math.floor(delay / 50) + 1)));
                delay += 50;
            }
        });

        if (reduceMotion) {
            groups.forEach((element) => element.classList.add('is-dashboard-visible'));
            return;
        }

        window.requestAnimationFrame(() => {
            groups.forEach((element) => element.classList.add('is-dashboard-visible'));
        });
    }

    function animateCurrency() {
        const elements = document.querySelectorAll('.pascco-count-up[data-value]');
        if (!elements.length) return;

        elements.forEach((element) => {
            const target = Number(element.dataset.value);
            if (!Number.isFinite(target)) return;

            const prefix = element.dataset.prefix || '';
            if (reduceMotion || target === 0) {
                element.textContent = prefix + target.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                return;
            }

            const duration = 650;
            const start = performance.now();

            function frame(now) {
                const progress = Math.min(1, (now - start) / duration);
                const eased = 1 - Math.pow(1 - progress, 3);
                const value = target * eased;
                element.textContent = prefix + value.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                if (progress < 1) {
                    window.requestAnimationFrame(frame);
                }
            }

            element.textContent = prefix + '0.00';
            window.requestAnimationFrame(frame);
        });
    }

    function init() {
        revealDashboard();
        animateCurrency();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
