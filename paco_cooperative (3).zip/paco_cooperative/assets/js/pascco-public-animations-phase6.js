(function () {
  'use strict';
  var body = document.body;
  if (!body || !body.classList.contains('pascco-public-site')) return;

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var selectors = [
    '.home-hero', '.section-heading', '.feature-card', '.member-callout',
    '.announcements-page > .hero', '.announcements-page .section-head',
    '.announcement-card', '.page-shell > section:not(.home-hero)',
    '.page-shell .product-card', '.page-shell .credit-card', '.page-shell .requirement-card',
    '.page-shell .about-card', '.page-shell .callout'
  ];
  var nodes = Array.prototype.slice.call(document.querySelectorAll(selectors.join(',')));
  nodes = nodes.filter(function (node, index, list) { return list.indexOf(node) === index; });
  if (!nodes.length || reduceMotion || !('IntersectionObserver' in window)) return;

  nodes.forEach(function (node, index) {
    node.classList.add('pascco-public-reveal');
    if (node.classList.contains('feature-card') || node.classList.contains('announcement-card')) {
      node.style.transitionDelay = Math.min((index % 4) * 70, 210) + 'ms';
    }
  });

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -24px 0px' });

  nodes.forEach(function (node) { observer.observe(node); });
})();
