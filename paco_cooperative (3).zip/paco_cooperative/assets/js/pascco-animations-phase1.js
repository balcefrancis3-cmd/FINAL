/* =========================================================
   PASCCO ANIMATION SYSTEM — PHASE 1
   Safe global motion helpers.
   No banking, authentication, or database logic.
   ========================================================= */
(function () {
    'use strict';

    const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function initPageEntrance() {
        document.body.classList.add('pascco-page-enter');
    }

    function initRevealObserver() {
        const elements = document.querySelectorAll('.pascco-reveal');
        if (!elements.length) return;

        if (reduceMotion || !('IntersectionObserver' in window)) {
            elements.forEach((element) => element.classList.add('is-visible'));
            return;
        }

        const observer = new IntersectionObserver((entries, currentObserver) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                entry.target.classList.add('is-visible');
                currentObserver.unobserve(entry.target);
            });
        }, {
            threshold: 0.08,
            rootMargin: '0px 0px -30px 0px'
        });

        elements.forEach((element) => observer.observe(element));
    }

    function initPressFeedback() {
        document.addEventListener('pointerdown', (event) => {
            const target = event.target.closest('.pascco-press');
            if (!target) return;
            target.classList.add('is-pressed');
        }, { passive: true });

        document.addEventListener('pointerup', clearPressed);
        document.addEventListener('pointercancel', clearPressed);
        document.addEventListener('pointerleave', clearPressed);

        function clearPressed() {
            document.querySelectorAll('.pascco-press.is-pressed').forEach((element) => {
                element.classList.remove('is-pressed');
            });
        }
    }

    window.PASCCOAnimations = {
        showToast: function (message, type, title) {
            type = type || 'info';
            title = title || (type === 'success' ? 'Success' : type === 'error' ? 'Something went wrong' : 'PASCCO');

            const toast = document.createElement('div');
            toast.className = 'pascco-toast pascco-toast-' + type;
            toast.setAttribute('role', type === 'error' ? 'alert' : 'status');

            const iconName = type === 'success' ? 'bx-check' : type === 'error' ? 'bx-error-circle' : 'bx-info-circle';
            toast.innerHTML = `
                <span class="pascco-toast-icon"><i class="bx ${iconName}" aria-hidden="true"></i></span>
                <span>
                    <span class="pascco-toast-title">${escapeHTML(title)}</span>
                    <span class="pascco-toast-message">${escapeHTML(message)}</span>
                </span>
            `;

            document.body.appendChild(toast);
            requestAnimationFrame(() => toast.classList.add('is-visible'));

            window.setTimeout(() => {
                toast.classList.add('is-leaving');
                window.setTimeout(() => toast.remove(), 240);
            }, 3600);

            return toast;
        },

        success: function (message, title) {
            return this.showToast(message, 'success', title || 'Success');
        },

        error: function (message, title) {
            return this.showToast(message, 'error', title || 'Something went wrong');
        }
    };

    function escapeHTML(value) {
        const div = document.createElement('div');
        div.textContent = String(value);
        return div.innerHTML;
    }

    function init() {
        initPageEntrance();
        initRevealObserver();
        initPressFeedback();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
