/* PASCCO Animation Phase 3 — Admin Dashboard */
(function () {
  'use strict';

  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function markVisible(elements) {
    elements.forEach((element) => element.classList.add('is-visible'));
  }

  function revealAdminContent() {
    const revealItems = document.querySelectorAll('.pascco-admin-dashboard-phase3 .pascco-admin-reveal');
    const staggerItems = document.querySelectorAll('.pascco-admin-dashboard-phase3 .pascco-admin-stagger-item');
    const statusItems = document.querySelectorAll('.pascco-admin-dashboard-phase3 .pascco-admin-status-tile');
    const rows = document.querySelectorAll('.pascco-admin-dashboard-phase3 .pascco-admin-table-row');

    if (reduceMotion) {
      markVisible(revealItems);
      markVisible(staggerItems);
      markVisible(statusItems);
      markVisible(rows);
      return;
    }

    staggerItems.forEach((element, index) => {
      element.style.transitionDelay = Math.min(index * 55, 220) + 'ms';
    });
    statusItems.forEach((element, index) => {
      element.style.transitionDelay = Math.min(index * 55, 220) + 'ms';
    });
    rows.forEach((element, index) => {
      element.style.transitionDelay = Math.min(index * 30, 180) + 'ms';
    });

    requestAnimationFrame(() => {
      markVisible(revealItems);
      markVisible(staggerItems);
      markVisible(statusItems);
      markVisible(rows);
    });
  }

  function animateCount(element) {
    const target = Number(element.dataset.value || 0);
    const decimals = Number(element.dataset.decimals || 0);
    const prefix = element.dataset.prefix || '';
    if (!Number.isFinite(target)) return;

    if (reduceMotion) {
      element.textContent = prefix + target.toLocaleString('en-PH', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });
      return;
    }

    const duration = 720;
    const start = performance.now();
    element.classList.add('is-counting');

    function frame(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = target * eased;
      element.textContent = prefix + current.toLocaleString('en-PH', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });

      if (progress < 1) {
        window.requestAnimationFrame(frame);
      } else {
        element.textContent = prefix + target.toLocaleString('en-PH', {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals
        });
        element.classList.remove('is-counting');
      }
    }

    window.requestAnimationFrame(frame);
  }

  function init() {
    revealAdminContent();
    document.querySelectorAll('.pascco-admin-dashboard-phase3 .pascco-admin-count-up').forEach(animateCount);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
