/* PASCCO Animation Phase 4 — Loans & Financial Pages */
(function(){
    'use strict';
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const stagger = document.querySelectorAll('.pascco-financial-stagger');
    stagger.forEach(function(el,i){ if(!reduce) el.style.setProperty('--pascco-financial-delay',(Math.min(i,9)*70)+'ms'); });

    document.querySelectorAll('.pascco-financial-form').forEach(function(form){
        form.addEventListener('submit', function(){
            if (form.classList.contains('is-submitting')) return;
            form.classList.add('is-submitting');
            const button = form.querySelector('button[type="submit"]');
            if (!button) return;
            const label = button.querySelector('.pascco-submit-label');
            if (label) {
                label.dataset.original = label.textContent;
                label.textContent = label.dataset.processing || 'Processing…';
            }
            if (!button.querySelector('.pascco-submit-spinner')) {
                const spinner = document.createElement('span');
                spinner.className = 'pascco-submit-spinner';
                spinner.setAttribute('aria-hidden','true');
                button.prepend(spinner);
            }
            button.setAttribute('aria-busy','true');
        });
    });

    document.querySelectorAll('.pascco-bracket-summary-trigger').forEach(function(el){
        el.addEventListener('change', function(){
            const target = document.querySelector(el.dataset.target || '');
            if (!target || target.hidden) return;
            target.classList.remove('pascco-bracket-reveal');
            void target.offsetWidth;
            target.classList.add('pascco-bracket-reveal');
        });
    });

    document.querySelectorAll('[data-pascco-financial-reveal]').forEach(function(el){
        if (reduce) return;
        el.classList.add('pascco-financial-reveal');
    });
})();
