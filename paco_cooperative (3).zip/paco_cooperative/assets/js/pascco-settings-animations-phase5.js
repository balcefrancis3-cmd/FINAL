/* PASCCO Animation Phase 5 — Settings */
(function(){
    'use strict';
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.querySelectorAll('.pascco-settings-stagger').forEach(function(el,i){
        if(!reduce) el.style.setProperty('--pascco-settings-delay',(Math.min(i,10)*65)+'ms');
    });
    document.querySelectorAll('[data-pascco-settings-reveal]').forEach(function(el){
        if(!reduce) el.classList.add('pascco-settings-reveal');
    });
    document.querySelectorAll('.pascco-settings-form').forEach(function(form){
        form.addEventListener('submit',function(){
            if(form.classList.contains('is-submitting')) return;
            form.classList.add('is-submitting');
            const button=form.querySelector('button[type="submit"]');
            if(!button) return;
            const label=button.querySelector('.pascco-settings-submit-label');
            if(label){
                label.dataset.original=label.textContent;
                label.textContent=label.dataset.processing || 'Saving…';
            }
            if(!button.querySelector('.pascco-settings-submit-spinner')){
                const spinner=document.createElement('span');
                spinner.className='pascco-settings-submit-spinner';
                spinner.setAttribute('aria-hidden','true');
                button.prepend(spinner);
            }
            button.setAttribute('aria-busy','true');
        });
    });
    document.querySelectorAll('.notice.success,.notice.ok,.status.ok,.acknowledged').forEach(function(el){
        el.classList.add('pascco-settings-status');
        if(el.classList.contains('acknowledged')) el.classList.add('pascco-settings-check');
    });
    document.querySelectorAll('.session').forEach(function(el){el.classList.add('pascco-session-item')});
    document.querySelectorAll('.history-table tbody tr').forEach(function(el){el.classList.add('pascco-history-row')});
    document.querySelectorAll('.notification-page .option').forEach(function(el){el.classList.add('pascco-toggle-option')});
    document.querySelectorAll('.mfa-page .status.ok strong').forEach(function(el){el.classList.add('pascco-security-pulse')});
})();
