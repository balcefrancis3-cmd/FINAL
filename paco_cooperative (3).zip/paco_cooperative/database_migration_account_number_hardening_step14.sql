-- PASCCO Step 14: Account Number Hardening
-- Purpose:
--   1. Prevent duplicate account_number values at the database level.
--   2. Refuse the migration instead of silently changing existing duplicate data.
--
-- No account balances, account numbers, or transaction records are modified.

DROP PROCEDURE IF EXISTS pascco_enforce_unique_account_number;

DELIMITER $$

CREATE PROCEDURE pascco_enforce_unique_account_number()
BEGIN
    DECLARE duplicate_count INT DEFAULT 0;
    DECLARE unique_index_count INT DEFAULT 0;

    SELECT COUNT(*)
      INTO duplicate_count
      FROM (
          SELECT account_number
          FROM accounts
          GROUP BY account_number
          HAVING COUNT(*) > 1
      ) AS duplicates;

    IF duplicate_count > 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Step 14 stopped: duplicate account_number values already exist. Review and resolve those records before adding the unique constraint.';
    END IF;

    SELECT COUNT(*)
      INTO unique_index_count
      FROM information_schema.statistics
     WHERE table_schema = DATABASE()
       AND table_name = 'accounts'
       AND column_name = 'account_number'
       AND non_unique = 0;

    IF unique_index_count = 0 THEN
        SET @pascco_add_account_number_unique = 'ALTER TABLE accounts ADD UNIQUE KEY uq_accounts_account_number (account_number)';
        PREPARE pascco_add_account_number_unique_stmt FROM @pascco_add_account_number_unique;
        EXECUTE pascco_add_account_number_unique_stmt;
        DEALLOCATE PREPARE pascco_add_account_number_unique_stmt;
    END IF;
END$$

DELIMITER ;

CALL pascco_enforce_unique_account_number();
DROP PROCEDURE IF EXISTS pascco_enforce_unique_account_number;
