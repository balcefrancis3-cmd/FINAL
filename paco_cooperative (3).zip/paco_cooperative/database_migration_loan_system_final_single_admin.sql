-- PASCCO Loan System Final Correction — Single Administrator Approval Model
-- Apply AFTER database_migration_loan_system_step12.sql.
-- Aligns the existing loan workflow with PASCCO's current one-admin setup.
-- No financial transactions are created, deleted, or changed by this migration.

START TRANSACTION;

UPDATE loans
SET required_approvals = 1
WHERE required_approvals IS NULL OR required_approvals <> 1;

ALTER TABLE loans
    ALTER COLUMN required_approvals SET DEFAULT 1;

COMMIT;

-- The application layer also enforces one required approval.
-- Restructuring review/execution is single-admin in the current setup.
