-- PASCCO Loan System - Step 2
-- Adds an explicit interest-rate basis so loan calculations are not ambiguous.
-- This does NOT invent PASCCO financial policies. Administrators must enter the
-- cooperative-approved bracket values through the Loan Products page.

START TRANSACTION;

ALTER TABLE loan_brackets
    ADD COLUMN IF NOT EXISTS interest_rate_basis ENUM('annual','term') NOT NULL DEFAULT 'annual' AFTER interest_rate;

COMMIT;
