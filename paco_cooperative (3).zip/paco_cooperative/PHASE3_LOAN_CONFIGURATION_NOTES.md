# PASCCO Phase 3 — Loan Product Configuration

## Purpose

Phase 3 improves the existing loan product/bracket administration workflow. It does not invent official PASCCO financial policy and does not insert sample loan amounts, terms, rates, income thresholds, or savings requirements.

## Changes

- Added prefilled edit flows for loan products and loan brackets.
- Validates product descriptions and bracket names on the server.
- Validates interest-rate input as a decimal percentage with no more than four decimal places.
- Prevents active amount brackets for the same product from overlapping.
- Prevents activating a bracket while its parent product is inactive, and checks overlap before activation.
- Flags products that have no active brackets, so the admin can see which products are not ready for member applications.
- Improves schema readiness checks for both loan products and brackets.
- Uses the total balance across all active member accounts when checking required savings.
- Rejects impossible or future birth dates in loan applications.
- Logs unexpected loan-application and loan-configuration exceptions instead of showing internal database details.
- No database schema change is required; existing Phase 1/2 loan configuration tables are used.

## Admin setup

1. Back up the PASCCO project folder and database.
2. Open `admin/admin_loan_products.php` while logged in as the single admin.
3. Add or edit each product, then add its bracket(s).
4. Enter only values confirmed by the cooperative. Do not activate products for member applications until their active brackets have been configured and checked.
5. Test a member application using a test account and confirm amount, income, savings, interest, and term validation.

## Tests

Run from the project folder:

```bat
php tests\phase3_loan_configuration_static_tests.php
php tests\phase2_money_tests.php
```

Static checks and PHP syntax checks do not replace live XAMPP/MariaDB integration and browser testing.
