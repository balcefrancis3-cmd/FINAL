# PASCCO Phase 9 — Integrated Static Verification

## Scope
This phase validates the supplied Phase 8 package using repeatable local static checks. It does not connect to MySQL/MariaDB, apply SQL migrations, sign in to the application, or change member/account/financial data.

## Results from the packaging environment
- PHP syntax: all 106 PHP files discovered outside `vendor/` and `.git/` passed `php -l`.
- JavaScript syntax: all 9 JavaScript files discovered outside `vendor/` and `.git/` passed `node --check`.
- Existing test scripts: all 13 test scripts passed, totaling 153 individual checks as reported by those scripts.
- The bundled Phase 9 runner is `tools/phase9_static_verification.php`. Run it from a command prompt in the project root with `php tools/phase9_static_verification.php`.

## What this does not prove
- It does not prove the SQL imports cleanly on the user's installed MariaDB/MySQL version.
- It does not prove live authentication, email delivery, MFA, uploads, charts, or all pages work in a browser.
- It does not confirm that the migration ledger matches the actual live database.
- It does not certify the application as production-ready.

## Recommended local acceptance sequence
1. Keep a backup of any database that must be preserved.
2. Run the static verification runner from the project root.
3. Run `php tools/migration_tracker.php list` and `php tools/database_schema_audit.php` only after confirming the private configuration and local database are available. These are inventory tools, not migration executors.
4. Test migrations only against a separate disposable database that matches the real server version; apply one migration at a time after reviewing its prerequisites.
5. Smoke-test member login/MFA, admin login, loan submission and single-admin approval, deposit/withdrawal review, notification preferences, privacy settings, certificates, and dashboard charts in a local browser.
6. Review the complete logs and phpMyAdmin import output before deciding whether to promote the build.

## Safety notes retained from Phase 8
- Do not import every SQL file in the folder as a batch.
- Do not treat `schema_migrations` or the migration tracker as proof that a migration's schema effects exist.
- Resolve duplicate normalized email/account-number pre-flight findings deliberately; do not auto-delete or merge member records.
- The live XAMPP/MariaDB checks remain pending until run in the user's environment.
