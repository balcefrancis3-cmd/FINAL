<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member' || empty($_SESSION['email_otp_verified'])) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$currentSessionHash = hash('sha256', session_id());
$message = '';
$error = '';

function active_sessions_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function active_sessions_device_label(string $userAgent): string
{
    $ua = strtolower($userAgent);
    $device = str_contains($ua, 'mobile') || str_contains($ua, 'android') || str_contains($ua, 'iphone') ? 'Mobile device' : 'Computer';
    $browser = 'Browser';
    if (str_contains($ua, 'edg/')) $browser = 'Microsoft Edge';
    elseif (str_contains($ua, 'chrome/')) $browser = 'Google Chrome';
    elseif (str_contains($ua, 'firefox/')) $browser = 'Mozilla Firefox';
    elseif (str_contains($ua, 'safari/') && !str_contains($ua, 'chrome/')) $browser = 'Safari';
    return $browser . ' · ' . $device;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    try {
        if ($action === 'revoke') {
            $sessionId = filter_var($_POST['session_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$sessionId) throw new RuntimeException('Invalid session selected.');

            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'UPDATE user_sessions SET revoked_at = NOW() WHERE id = ? AND user_id = ? AND revoked_at IS NULL AND session_hash <> ?'
            );
            $stmt->execute([$sessionId, $userId, $currentSessionHash]);
            if ($stmt->rowCount() !== 1) throw new RuntimeException('That session is no longer active or is your current session.');
            $pdo->commit();
            record_audit($pdo, $userId, 'session_revoked', 'Member remotely revoked another active session.', 'success');
            $message = 'The selected session has been signed out.';
        } elseif ($action === 'revoke_others') {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ? AND revoked_at IS NULL AND session_hash <> ?'
            );
            $stmt->execute([$userId, $currentSessionHash]);
            $count = $stmt->rowCount();
            $pdo->commit();
            record_audit($pdo, $userId, 'sessions_revoked_others', 'Member remotely revoked all other active sessions (' . $count . ' session(s)).', 'success');
            $message = $count > 0 ? $count . ' other session(s) have been signed out.' : 'There were no other active sessions to sign out.';
        } else {
            throw new RuntimeException('Invalid session action.');
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $exception->getMessage();
    }
}

// Keep the current session record current and remove stale records from the list.
$currentSessionHash = hash('sha256', session_id());
$sync = $pdo->prepare(
    'INSERT INTO user_sessions (user_id, session_hash, role, ip_address, user_agent)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE last_activity_at = NOW(), ip_address = VALUES(ip_address), user_agent = VALUES(user_agent), revoked_at = NULL'
);
$sync->execute([
    $userId,
    $currentSessionHash,
    'member',
    substr((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45),
    substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown browser'), 0, 500)
]);

$list = $pdo->prepare(
    'SELECT id, session_hash, ip_address, user_agent, created_at, last_activity_at
     FROM user_sessions
     WHERE user_id = ? AND revoked_at IS NULL
       AND last_activity_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
       AND created_at >= DATE_SUB(NOW(), INTERVAL 8 HOUR)
     ORDER BY (session_hash = ?) DESC, last_activity_at DESC'
);
$list->execute([$userId, $currentSessionHash]);
$sessions = $list->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
<title>Active Sessions | PASCCO</title>
<link rel="stylesheet" href="/paco_cooperative/assets/css/member-panels.css?v=2">
<style>
body{margin:0;background:#f4f7fb;color:#182a45;font-family:Georgia,'Times New Roman',serif}.sessions-page{max-width:900px;margin:0 auto;padding:36px 22px 64px}.card{background:#fff;border:1px solid #dbe3ef;border-radius:12px;padding:24px;box-shadow:0 5px 18px rgba(7,29,73,.04);margin-top:18px}.back{display:inline-block;margin-bottom:14px;color:#1456a0;text-decoration:none;font-weight:700}.heading h1{margin:0 0 8px;color:#071d49}.heading p{margin:0;color:#617187;line-height:1.6}.status{padding:13px 15px;border-radius:8px;margin:18px 0}.ok{background:#edf7f0;border:1px solid #cfe4d5;color:#22543d}.error{background:#fff1f1;border:1px solid #efcccc;color:#9b2c2c}.session{display:flex;justify-content:space-between;gap:18px;align-items:center;padding:18px 0;border-bottom:1px solid #e5ebf2}.session:last-child{border-bottom:0}.session-main{min-width:0}.session-title{font-weight:700;color:#071d49}.session-meta{margin-top:5px;color:#617187;font:13px/1.55 Arial,sans-serif;overflow-wrap:anywhere}.current{display:inline-block;margin-left:8px;padding:3px 7px;border-radius:999px;background:#edf4ff;color:#1456a0;font:700 10px Arial,sans-serif;text-transform:uppercase}.danger{flex:0 0 auto;padding:9px 13px;border:1px solid #9b2c2c;background:#fff;color:#9b2c2c;border-radius:7px;font-weight:700;cursor:pointer}.toolbar{display:flex;justify-content:flex-end;margin-bottom:4px}.secondary{padding:10px 14px;border:1px solid #c5d1df;background:#fff;color:#182a45;border-radius:7px;font-weight:700;cursor:pointer}.empty{color:#617187}.note{font:12px/1.6 Arial,sans-serif;color:#6b7789;margin-top:18px}@media(max-width:650px){.sessions-page{padding:26px 16px 44px}.session{align-items:flex-start;flex-direction:column}.danger{width:100%}.toolbar{justify-content:stretch}.secondary{width:100%}}
</style>
</head>
<body>
<?php pascco_member_header('Active Sessions'); ?>
<main class="pascco-settings-reveal sessions-page member-content">
<a class="back settings-back" href="settings.php">← Back to Settings</a>
<section class="heading"><h1>Active Sessions</h1><p>Review where your PASCCO account is currently signed in. You can remotely sign out other sessions without ending this session.</p></section>
<?php if($message): ?><div class="status ok" role="status"><?php echo active_sessions_escape($message); ?></div><?php endif; ?>
<?php if($error): ?><div class="status error" role="alert"><?php echo active_sessions_escape($error); ?></div><?php endif; ?>
<section class="card pascco-settings-stagger">
<div class="toolbar"><form class="pascco-settings-form" method="post"><input type="hidden" name="csrf_token" value="<?php echo active_sessions_escape($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="revoke_others"><button class="secondary" type="submit">Sign out all other sessions</button></form></div>
<?php if(!$sessions): ?><p class="empty">No active session records are available yet.</p><?php else: ?>
<?php foreach($sessions as $row): $isCurrent = hash_equals($currentSessionHash, (string)$row['session_hash']); ?>
<div class="session">
<div class="session-main">
<div class="session-title"><?php echo active_sessions_escape(active_sessions_device_label((string)$row['user_agent'])); ?><?php if($isCurrent): ?><span class="current">This device</span><?php endif; ?></div>
<div class="session-meta">IP: <?php echo active_sessions_escape($row['ip_address']); ?><br>Started: <?php echo active_sessions_escape($row['created_at']); ?><br>Last active: <?php echo active_sessions_escape($row['last_activity_at']); ?></div>
</div>
<?php if(!$isCurrent): ?><form class="pascco-settings-form" method="post"><input type="hidden" name="csrf_token" value="<?php echo active_sessions_escape($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="revoke"><input type="hidden" name="session_id" value="<?php echo (int)$row['id']; ?>"><button class="danger" type="submit">Sign out</button></form><?php endif; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>
<p class="note">PASCCO records the session IP address and browser information to help you recognize active sign-ins. This page does not claim geographic location from the IP address.</p>
</section>
</main>
<?php pascco_global_footer(); ?>
</body></html>
