<?php
header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || !in_array(($_SESSION['role'] ?? ''), ['member', 'admin'], true)) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$isAdmin = ($_SESSION['role'] ?? '') === 'admin';
$receiptId = (int) ($_GET['receipt_id'] ?? 0);
if ($receiptId <= 0) {
    http_response_code(400);
    exit('Invalid receipt selected.');
}

$sql = "SELECT r.*, l.loan_number, l.loan_product, l.loan_amount, l.total_payable, l.status AS loan_status,
               m.member_number, m.first_name, m.last_name, m.email,
               u.username AS received_by_username
        FROM loan_payment_receipts r
        JOIN loans l ON l.id = r.loan_id
        JOIN members m ON m.id = l.member_id
        LEFT JOIN users u ON u.id = r.received_by
        WHERE r.id = ?";
$params = [$receiptId];
if (!$isAdmin) {
    $sql .= ' AND m.user_id = ?';
    $params[] = (int) $_SESSION['user_id'];
}
$sql .= ' LIMIT 1';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$receipt = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$receipt) {
    http_response_code(404);
    exit('Payment receipt not found.');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Payment Receipt | <?php echo htmlspecialchars($receipt['receipt_number'],ENT_QUOTES,'UTF-8'); ?> | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--line:#d5deea;--muted:#68788d}body{margin:0;background:#f3f6fa;color:#1c314b;font-family:Georgia,'Times New Roman',serif}.wrap{width:min(700px,calc(100% - 28px));margin:30px auto 60px}.actions{display:flex;justify-content:flex-end;gap:9px;margin-bottom:14px}.btn{border:1px solid var(--line);background:#fff;color:var(--navy);padding:9px 13px;border-radius:8px;text-decoration:none;font:800 .82rem Arial,sans-serif}.btn.primary{background:var(--blue);color:#fff;border-color:var(--blue)}.receipt{background:#fff;border:1px solid var(--line);box-shadow:0 10px 30px rgba(7,29,73,.07);padding:38px}.brand{text-align:center;border-bottom:3px solid var(--gold);padding-bottom:18px}.brand h1{margin:0;color:var(--navy);font-size:1.8rem}.brand p{margin:5px 0;color:var(--muted);font:12px Arial,sans-serif}.receipt-title{text-align:center;margin:25px 0}.receipt-title h2{margin:0;color:var(--navy);font-size:1.3rem}.receipt-title p{margin:6px 0;color:var(--muted);font:12px Arial,sans-serif}.amount{text-align:center;border:1px solid var(--line);border-radius:10px;padding:18px;margin-bottom:20px}.amount small{display:block;color:var(--muted);font:700 10px Arial,sans-serif;text-transform:uppercase;letter-spacing:.08em}.amount strong{display:block;color:var(--blue);font-size:2rem;margin-top:5px}.details{border-top:1px solid var(--line)}.row{display:flex;justify-content:space-between;gap:20px;padding:10px 0;border-bottom:1px solid var(--line);font:12px Arial,sans-serif}.row span{color:var(--muted)}.row strong{text-align:right;color:var(--navy);max-width:62%;overflow-wrap:anywhere}.note{margin-top:20px;padding:12px;background:#f7f9fc;border-radius:8px;font:11px/1.55 Arial,sans-serif;color:var(--muted)}.footer{margin-top:24px;text-align:center;color:var(--muted);font:10px/1.5 Arial,sans-serif}@media print{body{background:#fff}.wrap{width:100%;margin:0}.actions,.pascco-global-header,.pascco-global-footer{display:none!important}.receipt{border:0;box-shadow:none;padding:0}}
</style>
</head>
<body>
<?php if($isAdmin): pascco_admin_header(); else: pascco_member_header('Payment Receipt'); endif; ?>
<main class="wrap"><div class="actions"><a class="btn" href="/paco_cooperative/member/loan_statement.php?loan_id=<?php echo (int)$receipt['loan_id']; ?>">← Loan Statement</a><button class="btn primary" type="button" onclick="window.print()">Print / Save PDF</button></div><article class="receipt"><header class="brand"><h1>PASCCO</h1><p>Paco Savings &amp; Credit Cooperative</p></header><section class="receipt-title"><h2>Official Payment Receipt</h2><p><?php echo htmlspecialchars($receipt['receipt_number'],ENT_QUOTES,'UTF-8'); ?></p></section><div class="amount pascco-receipt-amount"><small>Payment Amount</small><strong>₱<?php echo number_format((float)$receipt['amount'],2); ?></strong></div><div class="details"><div class="row"><span>Received</span><strong><?php echo htmlspecialchars($receipt['received_at'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="row"><span>Member</span><strong><?php echo htmlspecialchars($receipt['first_name'].' '.$receipt['last_name'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="row"><span>Member Number</span><strong><?php echo htmlspecialchars($receipt['member_number'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="row"><span>Loan Number</span><strong><?php echo htmlspecialchars($receipt['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="row"><span>Payment Method</span><strong><?php echo htmlspecialchars($receipt['payment_method'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="row"><span>External Reference</span><strong><?php echo htmlspecialchars($receipt['external_reference'] ?: '—',ENT_QUOTES,'UTF-8'); ?></strong></div><div class="row"><span>Received By</span><strong><?php echo htmlspecialchars($receipt['received_by_username'] ?: 'PASCCO Administrator',ENT_QUOTES,'UTF-8'); ?></strong></div></div><?php if(!empty($receipt['notes'])): ?><div class="note"><strong>Notes:</strong> <?php echo nl2br(htmlspecialchars($receipt['notes'],ENT_QUOTES,'UTF-8')); ?></div><?php endif; ?><footer class="footer">This receipt confirms that the payment above was recorded in the PASCCO loan payment system. Retain this document for your records.</footer></article></main>
<?php pascco_global_footer(); ?>
</body></html>
