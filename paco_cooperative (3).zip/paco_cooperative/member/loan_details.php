<?php
header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

if (!isset($_SESSION['user_id']) || !in_array(($_SESSION['role'] ?? ''), ['member','admin'], true)) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$isAdmin = ($_SESSION['role'] ?? '') === 'admin';

$loan_id = (int) ($_GET['loan_id'] ?? 0);
if ($loan_id <= 0) {
    http_response_code(400);
    exit('Invalid loan selected.');
}

pascco_refresh_overdue_loan_payments($pdo);

$query = "SELECT l.*, p.name AS product_name, b.bracket_name, b.term_months, b.interest_method, b.interest_rate_basis FROM loans l LEFT JOIN loan_products p ON p.id = l.loan_product_id LEFT JOIN loan_brackets b ON b.id = l.loan_bracket_id JOIN members m ON m.id = l.member_id WHERE l.id = ?";
$params = [$loan_id];
if (!$isAdmin) {
    $query .= ' AND m.user_id = ?';
    $params[] = (int) $_SESSION['user_id'];
}
$query .= ' LIMIT 1';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$loan = $stmt->fetch();

if (!$loan) {
    http_response_code(404);
    exit('Loan not found.');
}

$schedule_stmt = $pdo->prepare('SELECT * FROM loan_payments WHERE loan_id = ? ORDER BY payment_number');
$schedule_stmt->execute([$loan_id]);
$schedule = $schedule_stmt->fetchAll();

$history_stmt = $pdo->prepare('SELECT a.*, lp.payment_number, lp.due_date FROM loan_payment_allocations a JOIN loan_payments lp ON lp.id = a.loan_payment_id WHERE a.loan_id = ? ORDER BY a.payment_date DESC, a.id DESC');
$history_stmt->execute([$loan_id]);
$history = $history_stmt->fetchAll();

$totalPaidCents = 0;
$nextPayment = null;
foreach ($schedule as $payment) {
    $paidCents = pascco_money_to_cents((string) $payment['amount_paid']);
    $dueCents = pascco_money_to_cents((string) $payment['amount_due']);
    $totalPaidCents += $paidCents;
    if ($nextPayment === null && $paidCents < $dueCents && $payment['status'] !== 'waived') {
        $nextPayment = $payment;
    }
}

$totalPaid = pascco_money_from_cents($totalPaidCents);
$totalPayableCents = pascco_money_to_cents((string) ($loan['total_payable'] ?? $loan['loan_amount']));
$remaining = pascco_money_from_cents(max(0, $totalPayableCents - $totalPaidCents));

$closureStmt = $pdo->prepare('SELECT closure_reference FROM loan_closures WHERE loan_id = ? LIMIT 1');
$closureStmt->execute([$loan_id]);
$loanClosureReference = $closureStmt->fetchColumn();
$restructureStmt = $pdo->prepare('SELECT execution_reference, effective_date, new_remaining_balance, new_monthly_payment, new_term_months, new_maturity_date, executed_at FROM loan_restructuring_executions WHERE loan_id = ? ORDER BY executed_at DESC LIMIT 1');
$restructureStmt->execute([$loan_id]);
$loanRestructure = $restructureStmt->fetch(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Loan Details | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
<style>
html,body{margin:0;background:#f4f7fb;color:#18324f;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
</style>
<link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-loan-phase5.css?v=1">
</style>
</head>
<body>
<?php if ($isAdmin): pascco_admin_header(); else: pascco_member_header('Loan Details'); endif; ?>
<main class="wrap loan-phase5 loan-details-page pascco-financial-page">
<section class="loan-detail-hero"><div><div class="eyebrow">Loan servicing</div><h1><?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?></h1><p><?php echo htmlspecialchars($loan['product_name'] ?: ($loan['loan_product'] ?: 'Loan'),ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars($loan['status'],ENT_QUOTES,'UTF-8'); ?></p></div><div class="loan-detail-actions"><a href="/paco_cooperative/member/loan_statement.php?loan_id=<?php echo $loan_id; ?>"><i class="bx bx-file"></i> Statement</a><?php if($loanRestructure): ?><a href="/paco_cooperative/member/loan_statement.php?loan_id=<?php echo $loan_id; ?>#restructuring"><i class="bx bx-refresh"></i> Restructuring</a><?php endif; ?><?php if($loanClosureReference): ?><a href="/paco_cooperative/member/loan_clearance.php?loan_id=<?php echo (int)$loan_id; ?>" target="_blank" rel="noopener"><i class="bx bx-check-circle"></i> Clearance</a><?php endif; ?><a href="<?php echo $isAdmin ? '/paco_cooperative/admin/admin_loan_servicing.php' : '/paco_cooperative/member/apply_loan.php'; ?>"><i class="bx bx-arrow-back"></i> Back</a></div></section>
<div class="loan-detail-stats pascco-financial-reveal">
<div class="loan-detail-stat"><span class="label">Original Amount</span><strong class="value">₱<?php echo number_format((float)$loan['loan_amount'],2); ?></strong></div>
<div class="loan-detail-stat"><span class="label">Total Payable</span><strong class="value">₱<?php echo number_format((float)($loan['total_payable'] ?? $loan['loan_amount']),2); ?></strong></div>
<div class="loan-detail-stat"><span class="label">Paid</span><strong class="value">₱<?php echo pascco_money_display($totalPaid); ?></strong></div>
<div class="loan-detail-stat"><span class="label">Remaining</span><strong class="value">₱<?php echo pascco_money_display($remaining); ?></strong></div>
</div>
<div class="loan-detail-meta"><div><small>Monthly Payment</small><strong>₱<?php echo number_format((float)($loan['monthly_payment'] ?? 0),2); ?></strong></div><div><small>Next Due</small><strong><?php echo $nextPayment ? htmlspecialchars($nextPayment['due_date'],ENT_QUOTES,'UTF-8') : '—'; ?></strong></div><div><small>Interest</small><strong>₱<?php echo number_format((float)($loan['interest_amount'] ?? 0),2); ?></strong></div><div><small>Maturity</small><strong><?php echo htmlspecialchars($loan['maturity_date'] ?: '—',ENT_QUOTES,'UTF-8'); ?></strong></div></div>
<?php if($nextPayment && $nextPayment['status']==='overdue'): ?><p class="note">Your next scheduled payment is overdue. Please make a repayment from your member dashboard or contact PASCCO if you need assistance.</p><?php endif; ?>
<section class="pascco-financial-reveal"><div class="loan-section-heading"><div><h2>Repayment Schedule</h2><p>Track each installment and identify the next unpaid payment.</p></div></div><div class="loan-table-wrap"><table class="loan-table"><thead><tr><th>#</th><th>Due Date</th><th>Amount Due</th><th>Amount Paid</th><th>Balance</th><th>Status</th><th>Payment Date</th></tr></thead><tbody><?php if($schedule): foreach($schedule as $row): $isNext = $nextPayment && (int)$nextPayment['id'] === (int)$row['id']; ?><tr class="<?php echo $isNext ? 'is-next' : ''; ?>"><td><?php echo (int)$row['payment_number']; ?><?php if($isNext): ?><span class="loan-next-marker">Next</span><?php endif; ?></td><td><?php echo htmlspecialchars($row['due_date'],ENT_QUOTES,'UTF-8'); ?></td><td>₱<?php echo number_format((float)$row['amount_due'],2); ?></td><td>₱<?php echo number_format((float)$row['amount_paid'],2); ?></td><td>₱<?php echo number_format(max(0,(float)$row['amount_due']-(float)$row['amount_paid']),2); ?></td><td><span class="badge <?php echo htmlspecialchars($row['status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($row['status'],ENT_QUOTES,'UTF-8'); ?></span></td><td><?php echo htmlspecialchars($row['payment_date'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td></tr><?php endforeach; else: ?><tr><td colspan="7">No repayment schedule has been created yet.</td></tr><?php endif; ?></tbody></table></div></section>
<section><div class="loan-section-heading"><div><h2>Payment History</h2><p>Recorded allocations applied to this loan.</p></div></div><div class="loan-table-wrap"><table class="loan-table"><thead><tr><th>Date</th><th>Schedule #</th><th>Reference</th><th>Amount</th></tr></thead><tbody><?php if($history): foreach($history as $row): ?><tr><td><?php echo htmlspecialchars($row['payment_date'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo (int)$row['payment_number']; ?></td><td><?php echo htmlspecialchars($row['reference_number'],ENT_QUOTES,'UTF-8'); ?></td><td>₱<?php echo number_format((float)$row['amount'],2); ?></td></tr><?php endforeach; else: ?><tr><td colspan="4">No repayments recorded yet.</td></tr><?php endif; ?></tbody></table></div></section>
</main>
<?php pascco_global_footer(); ?>
</body></html>
