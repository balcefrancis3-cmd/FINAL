<?php
declare(strict_types=1);
header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/../includes/db.php';

if (!isset($_SESSION['user_id']) || !in_array(($_SESSION['role'] ?? ''), ['member', 'admin'], true)) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$memberId = (int) ($_GET['member_id'] ?? 0);
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';
if (!$isAdmin) {
    $stmt = $pdo->prepare("SELECT m.id, m.user_id, m.member_number, m.first_name, m.last_name, m.email, a.updated_at AS approved_at FROM members m JOIN membership_applications a ON a.user_id=m.user_id AND a.status='approved' WHERE m.user_id=? ORDER BY a.id DESC LIMIT 1");
    $stmt->execute([(int) $_SESSION['user_id']]);
} else {
    if ($memberId <= 0) { http_response_code(400); exit('Select a valid member.'); }
    $stmt = $pdo->prepare("SELECT m.id, m.user_id, m.member_number, m.first_name, m.last_name, m.email, a.updated_at AS approved_at FROM members m JOIN membership_applications a ON a.user_id=m.user_id AND a.status='approved' WHERE m.id=? ORDER BY a.id DESC LIMIT 1");
    $stmt->execute([$memberId]);
}
$member = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$member) { http_response_code(404); exit('A membership certificate is available only for an approved membership record.'); }

$certificateReference = 'MEM-' . preg_replace('/[^A-Za-z0-9-]/', '', (string) $member['member_number']);
$memberName = trim((string) $member['first_name'] . ' ' . (string) $member['last_name']);
$issuedDate = !empty($member['approved_at']) ? date('F j, Y', strtotime((string) $member['approved_at'])) : 'Not recorded';
function cert_escape(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
?><!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Membership Certificate | PASCCO</title>
<style>
@page{size:A4 landscape;margin:12mm}*{box-sizing:border-box}body{margin:0;background:#edf2f7;color:#18324f;font-family:Georgia,'Times New Roman',serif}.sheet{position:relative;width:min(1100px,calc(100% - 32px));min-height:650px;margin:28px auto;padding:48px;border:9px double #d4ad45;background:#fffdf7;text-align:center;box-shadow:0 14px 45px #071d4914}.brand{font:800 1.1rem Arial,sans-serif;letter-spacing:.25em;color:#071d49}.coop{font: .8rem Arial,sans-serif;color:#617187;margin-top:7px}.rule{height:2px;background:#d4ad45;margin:22px auto;width:75%}.kicker{font:700 .8rem Arial,sans-serif;letter-spacing:.24em;color:#1456a0;text-transform:uppercase}.title{font-size:clamp(2rem,4vw,3.3rem);color:#071d49;margin:15px 0 25px}.intro{font-size:1.05rem;line-height:1.7;color:#52647a}.name{font-size:clamp(1.7rem,4vw,2.7rem);font-weight:bold;color:#1456a0;border-bottom:1px solid #d4ad45;padding:0 14px 10px;display:inline-block;min-width:50%;margin:14px 0}.details{font: .88rem Arial,sans-serif;line-height:1.8;color:#52647a;margin:22px auto}.ref{font:700 .85rem Arial,sans-serif;color:#071d49;letter-spacing:.04em}.signature{display:flex;justify-content:center;margin:42px auto 0;font: .8rem Arial,sans-serif;color:#52647a}.signature div{width:260px;border-top:1px solid #8391a2;padding-top:8px}.actions{margin:18px auto;text-align:center}.actions button{padding:11px 16px;border:0;border-radius:9px;background:#1456a0;color:#fff;font-weight:700;cursor:pointer}@media print{body{background:white}.sheet{width:100%;min-height:0;margin:0;box-shadow:none;break-inside:avoid}.actions{display:none}}@media(max-width:600px){.sheet{padding:28px 16px;border-width:5px}.name{min-width:0;width:100%}.signature{margin-top:30px}}
</style></head><body><main class="sheet"><div class="brand">PASCCO</div><div class="coop">Paco Savings &amp; Credit Cooperative</div><div class="rule"></div><div class="kicker">Certificate of Membership</div><h1 class="title">Membership Certificate</h1><p class="intro">This document confirms that</p><div class="name"><?php echo cert_escape($memberName); ?></div><p class="intro">is recorded as an approved member of Paco Savings &amp; Credit Cooperative.</p><div class="details">Member Number: <strong><?php echo cert_escape((string) $member['member_number']); ?></strong><br>Membership approval date: <strong><?php echo cert_escape($issuedDate); ?></strong></div><div class="ref">Certificate Reference: <?php echo cert_escape($certificateReference); ?></div><div class="signature"><div>Authorized PASCCO Representative</div></div></main><div class="actions"><button type="button" onclick="window.print()">Print / Save as PDF</button></div></body></html>
