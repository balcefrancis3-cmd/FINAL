<?php
header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

if (!isset($_SESSION['user_id']) || !in_array(($_SESSION['role'] ?? ''), ['member', 'admin'], true)) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$isAdmin = ($_SESSION['role'] ?? '') === 'admin';
$loanId = (int) ($_GET['loan_id'] ?? 0);
if ($loanId <= 0) {
    http_response_code(400);
    exit('Invalid loan selected.');
}

pascco_refresh_overdue_loan_payments($pdo);

$sql = "SELECT l.*, p.name AS product_name, b.bracket_name, m.member_number, m.first_name, m.last_name, m.email, m.contact_number
        FROM loans l
        JOIN members m ON m.id = l.member_id
        LEFT JOIN loan_products p ON p.id = l.loan_product_id
        LEFT JOIN loan_brackets b ON b.id = l.loan_bracket_id
        WHERE l.id = ?";
$params = [$loanId];
if (!$isAdmin) {
    $sql .= ' AND m.user_id = ?';
    $params[] = (int) $_SESSION['user_id'];
}
$sql .= ' LIMIT 1';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$loan) {
    http_response_code(404);
    exit('Loan not found.');
}

$scheduleStmt = $pdo->prepare('SELECT * FROM loan_payments WHERE loan_id = ? ORDER BY payment_number');
$scheduleStmt->execute([$loanId]);
$schedule = $scheduleStmt->fetchAll(PDO::FETCH_ASSOC);

$allocationStmt = $pdo->prepare('SELECT a.*, lp.payment_number, lp.due_date FROM loan_payment_allocations a JOIN loan_payments lp ON lp.id = a.loan_payment_id WHERE a.loan_id = ? ORDER BY a.payment_date ASC, a.id ASC');
$allocationStmt->execute([$loanId]);
$allocations = $allocationStmt->fetchAll(PDO::FETCH_ASSOC);

$receiptStmt = $pdo->prepare('SELECT r.*, u.username AS received_by_username FROM loan_payment_receipts r LEFT JOIN users u ON u.id = r.received_by WHERE r.loan_id = ? ORDER BY r.received_at ASC, r.id ASC');
$receiptStmt->execute([$loanId]);
$receipts = $receiptStmt->fetchAll(PDO::FETCH_ASSOC);

$totalPaidCents = 0;
$nextDue = null;
$overdueCount = 0;
foreach ($schedule as $row) {
    $paidCents = pascco_money_to_cents((string) $row['amount_paid']);
    $dueCents = pascco_money_to_cents((string) $row['amount_due']);
    $totalPaidCents += $paidCents;
    if ($nextDue === null && $paidCents < $dueCents && $row['status'] !== 'waived') {
        $nextDue = $row;
    }
    if ($row['status'] === 'overdue') {
        $overdueCount++;
    }
}
$totalPaid = pascco_money_from_cents($totalPaidCents);
$totalPayable = pascco_money_from_cents(pascco_money_to_cents((string) ($loan['total_payable'] ?? $loan['loan_amount'])));
$remaining = pascco_money_from_cents(max(0, pascco_money_to_cents($totalPayable) - $totalPaidCents));
$statementDate = date('F j, Y');
$documentNumber = 'LS-' . str_pad((string) $loanId, 8, '0', STR_PAD_LEFT) . '-' . date('Ymd');

$closureStmt = $pdo->prepare('SELECT closure_reference FROM loan_closures WHERE loan_id = ? LIMIT 1');
$closureStmt->execute([$loanId]);
$loanClosureReference = $closureStmt->fetchColumn();
$restructureStmt = $pdo->prepare('SELECT execution_reference, effective_date, new_remaining_balance, new_monthly_payment, new_term_months, new_maturity_date, executed_at FROM loan_restructuring_executions WHERE loan_id = ? ORDER BY executed_at DESC LIMIT 1');
$restructureStmt->execute([$loanId]);
$loanRestructure = $restructureStmt->fetch(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Loan Statement | <?php echo htmlspecialchars($loan['loan_number'], ENT_QUOTES, 'UTF-8'); ?> | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--bg:#f3f6fa;--line:#d5deea;--muted:#68788d}body{margin:0;background:var(--bg);color:#1c314b;font-family:Georgia,'Times New Roman',serif}.sheet{width:min(1000px,calc(100% - 30px));margin:28px auto 60px}.actions{display:flex;justify-content:flex-end;gap:9px;margin-bottom:14px}.btn{border:1px solid var(--line);background:#fff;color:var(--navy);padding:9px 13px;border-radius:8px;text-decoration:none;font-weight:800;font-family:Arial,sans-serif;font-size:.82rem}.btn.primary{background:var(--blue);color:#fff;border-color:var(--blue)}.paper{background:#fff;border:1px solid var(--line);box-shadow:0 10px 30px rgba(7,29,73,.07);padding:42px}.brand{display:flex;justify-content:space-between;gap:20px;border-bottom:3px solid var(--gold);padding-bottom:18px}.brand h1{margin:0;color:var(--navy);font-size:1.65rem}.brand p{margin:5px 0 0;color:var(--muted);font-size:.8rem}.doc{text-align:right;font-family:Arial,sans-serif;font-size:.75rem;color:var(--muted)}.doc strong{display:block;color:var(--navy);font-size:.9rem;margin-top:4px}.title{margin:28px 0 18px}.title h2{margin:0;color:var(--navy);font-size:1.55rem}.title p{margin:6px 0;color:var(--muted);font-family:Arial,sans-serif;font-size:.8rem}.info{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:20px}.box{border:1px solid var(--line);border-radius:9px;padding:14px}.box h3{margin:0 0 10px;color:var(--navy);font-size:.88rem}.line{display:flex;justify-content:space-between;gap:15px;padding:5px 0;font-family:Arial,sans-serif;font-size:.78rem}.line span:first-child{color:var(--muted)}.line strong{text-align:right;color:var(--navy)}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:20px 0}.metric{border:1px solid var(--line);padding:12px;border-radius:9px}.metric small{display:block;color:var(--muted);font:700 .65rem Arial,sans-serif;text-transform:uppercase;letter-spacing:.06em}.metric strong{display:block;margin-top:5px;color:var(--navy);font-size:1.05rem}.section{margin-top:25px}.section h3{color:var(--navy);font-size:1rem;border-bottom:1px solid var(--line);padding-bottom:8px}.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;min-width:680px;font-family:Arial,sans-serif}.table th,.table td{padding:8px;border-bottom:1px solid var(--line);text-align:left;font-size:.7rem}.table th{background:#eef4fb;color:var(--navy)}.money{white-space:nowrap;text-align:right!important}.badge{display:inline-block;border-radius:999px;padding:4px 7px;background:#e9f3ff;color:#2865a6;font-weight:800;text-transform:uppercase;font-size:.61rem}.badge.paid{background:#e5f5eb;color:#17663a}.badge.overdue{background:#fde6e7;color:#a62d36}.note{margin-top:20px;padding:11px 13px;border-left:4px solid var(--gold);background:#fffaf0;font:700 .75rem/1.5 Arial,sans-serif;color:#5e4a1c}.footer{margin-top:28px;padding-top:15px;border-top:1px solid var(--line);font:10px/1.5 Arial,sans-serif;color:var(--muted)}.receipt-link{color:var(--blue);font-weight:800;text-decoration:none}@media(max-width:720px){.paper{padding:24px}.info{grid-template-columns:1fr}.summary{grid-template-columns:1fr 1fr}.brand{flex-direction:column}.doc{text-align:left}}@media print{body{background:#fff}.sheet{width:100%;margin:0}.actions{display:none}.paper{box-shadow:none;border:0;padding:0}.pascco-global-header,.pascco-global-footer{display:none!important}.section{break-inside:avoid}}
</style>
</head>
<body>
<?php if ($isAdmin): pascco_admin_header(); else: pascco_member_header('Loan Statement'); endif; ?>
<main class="sheet">
<div class="actions"><?php if($loanClosureReference): ?><a class="button" href="/paco_cooperative/member/loan_clearance.php?loan_id=<?php echo (int)$loanId; ?>" target="_blank" rel="noopener">Loan Clearance</a><?php endif; ?><a class="btn" href="/paco_cooperative/member/loan_details.php?loan_id=<?php echo $loanId; ?>">← Loan Details</a><button class="btn primary" type="button" onclick="window.print()">Print / Save PDF</button></div>
<div class="paper">
<header class="brand"><div><h1>PASCCO</h1><p>Paco Savings &amp; Credit Cooperative</p></div><div class="doc">Statement Date<strong><?php echo htmlspecialchars($statementDate, ENT_QUOTES, 'UTF-8'); ?></strong><br>Document<strong><?php echo htmlspecialchars($documentNumber, ENT_QUOTES, 'UTF-8'); ?></strong></div></header>
<section class="title"><h2>Loan Account Statement</h2><p>This statement reflects the loan records and repayment allocations currently recorded in PASCCO.</p></section>
<div class="info"><div class="box"><h3>Borrower</h3><div class="line"><span>Member</span><strong><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'], ENT_QUOTES, 'UTF-8'); ?></strong></div><div class="line"><span>Member Number</span><strong><?php echo htmlspecialchars($loan['member_number'], ENT_QUOTES, 'UTF-8'); ?></strong></div><div class="line"><span>Email</span><strong><?php echo htmlspecialchars($loan['email'] ?: '—', ENT_QUOTES, 'UTF-8'); ?></strong></div></div><div class="box"><h3>Loan</h3><div class="line"><span>Loan Number</span><strong><?php echo htmlspecialchars($loan['loan_number'], ENT_QUOTES, 'UTF-8'); ?></strong></div><div class="line"><span>Product</span><strong><?php echo htmlspecialchars($loan['product_name'] ?: ($loan['loan_product'] ?: 'Loan'), ENT_QUOTES, 'UTF-8'); ?></strong></div><div class="line"><span>Status</span><strong><?php echo htmlspecialchars(strtoupper($loan['status']), ENT_QUOTES, 'UTF-8'); ?></strong></div><div class="line"><span>Maturity</span><strong><?php echo htmlspecialchars($loan['maturity_date'] ?: '—', ENT_QUOTES, 'UTF-8'); ?></strong></div></div></div>
<div class="summary"><div class="metric"><small>Original Amount</small><strong>₱<?php echo number_format((float)$loan['loan_amount'],2); ?></strong></div><div class="metric"><small>Total Payable</small><strong>₱<?php echo pascco_money_display($totalPayable); ?></strong></div><div class="metric"><small>Total Paid</small><strong>₱<?php echo pascco_money_display($totalPaid); ?></strong></div><div class="metric"><small>Remaining</small><strong>₱<?php echo pascco_money_display($remaining); ?></strong></div></div>
<div class="info"><div class="box"><h3>Terms</h3><div class="line"><span>Term</span><strong><?php echo htmlspecialchars($loan['loan_term'] ?: (($loan['term_months'] ?? '') ? $loan['term_months'].' months' : '—'), ENT_QUOTES, 'UTF-8'); ?></strong></div><div class="line"><span>Interest</span><strong>₱<?php echo number_format((float)($loan['interest_amount'] ?? 0),2); ?></strong></div><div class="line"><span>Monthly Payment</span><strong>₱<?php echo number_format((float)($loan['monthly_payment'] ?? 0),2); ?></strong></div></div><div class="box"><h3>Current Position</h3><div class="line"><span>Next Due</span><strong><?php echo $nextDue ? htmlspecialchars($nextDue['due_date'], ENT_QUOTES, 'UTF-8') : '—'; ?></strong></div><div class="line"><span>Overdue Installments</span><strong><?php echo $overdueCount; ?></strong></div><div class="line"><span>Last Payment</span><strong><?php echo htmlspecialchars($loan['last_payment_date'] ?: '—', ENT_QUOTES, 'UTF-8'); ?></strong></div></div></div>
<?php if($loanRestructure): ?><section class="section" id="restructuring"><h3>Latest Restructuring</h3><div class="info"><div class="box"><div class="line"><span>Execution Reference</span><strong><?php echo htmlspecialchars($loanRestructure['execution_reference'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="line"><span>Effective Date</span><strong><?php echo htmlspecialchars($loanRestructure['effective_date'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="line"><span>New Remaining</span><strong>₱<?php echo number_format((float)$loanRestructure['new_remaining_balance'],2); ?></strong></div></div><div class="box"><div class="line"><span>New Monthly Payment</span><strong>₱<?php echo number_format((float)$loanRestructure['new_monthly_payment'],2); ?></strong></div><div class="line"><span>New Term</span><strong><?php echo (int)$loanRestructure['new_term_months']; ?> months</strong></div><div class="line"><span>New Maturity</span><strong><?php echo htmlspecialchars($loanRestructure['new_maturity_date'],ENT_QUOTES,'UTF-8'); ?></strong></div></div></div></section><?php endif; ?><section class="section"><h3>Repayment Schedule</h3><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Due Date</th><th>Amount Due</th><th>Paid</th><th>Balance</th><th>Status</th></tr></thead><tbody><?php if ($schedule): foreach ($schedule as $row): ?><tr><td><?php echo (int)$row['payment_number']; ?></td><td><?php echo htmlspecialchars($row['due_date'],ENT_QUOTES,'UTF-8'); ?></td><td class="money">₱<?php echo number_format((float)$row['amount_due'],2); ?></td><td class="money">₱<?php echo number_format((float)$row['amount_paid'],2); ?></td><td class="money">₱<?php echo number_format(max(0,(float)$row['amount_due']-(float)$row['amount_paid']),2); ?></td><td><span class="badge <?php echo htmlspecialchars($row['status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($row['status'],ENT_QUOTES,'UTF-8'); ?></span></td></tr><?php endforeach; else: ?><tr><td colspan="6">No repayment schedule is recorded.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="section"><h3>Payment Allocations</h3><div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Schedule #</th><th>Reference</th><th class="money">Amount</th></tr></thead><tbody><?php if ($allocations): foreach ($allocations as $row): ?><tr><td><?php echo htmlspecialchars($row['payment_date'],ENT_QUOTES,'UTF-8'); ?></td><td>#<?php echo (int)$row['payment_number']; ?></td><td><?php echo htmlspecialchars($row['reference_number'],ENT_QUOTES,'UTF-8'); ?></td><td class="money">₱<?php echo number_format((float)$row['amount'],2); ?></td></tr><?php endforeach; else: ?><tr><td colspan="4">No payment allocations are recorded.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="section"><h3>External Payment Receipts</h3><div class="table-wrap"><table class="table"><thead><tr><th>Receipt</th><th>Date</th><th>Method</th><th>Reference</th><th class="money">Amount</th><th>Document</th></tr></thead><tbody><?php if ($receipts): foreach ($receipts as $row): ?><tr><td><?php echo htmlspecialchars($row['receipt_number'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($row['received_at'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($row['payment_method'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($row['external_reference'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td><td class="money">₱<?php echo number_format((float)$row['amount'],2); ?></td><td><a class="receipt-link" target="_blank" rel="noopener" href="/paco_cooperative/member/loan_payment_receipt.php?receipt_id=<?php echo (int)$row['id']; ?>">View</a></td></tr><?php endforeach; else: ?><tr><td colspan="6">No external payment receipts are recorded.</td></tr><?php endif; ?></tbody></table></div></section>
<?php if ($nextDue && $nextDue['status'] === 'overdue'): ?><div class="note">This account currently has an overdue scheduled payment. Please settle the outstanding amount or contact PASCCO for assistance.</div><?php endif; ?>
<footer class="footer">This statement is generated from the loan and payment records currently stored in the PASCCO system. It is an operational account statement and should be reconciled with official cooperative accounting records when required.</footer>
</div></main>
<?php pascco_global_footer(); ?>
</body></html>
