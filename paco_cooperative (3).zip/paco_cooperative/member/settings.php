<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

// Ensure members created after the migration also receive a default settings row.
try {
    $createDefaults = $pdo->prepare('INSERT IGNORE INTO member_settings (user_id) VALUES (?)');
    $createDefaults->execute([$userId]);
    $settingsQuery = $pdo->prepare('SELECT theme, text_size, language_code, created_at, updated_at FROM member_settings WHERE user_id = ? LIMIT 1');
    $settingsQuery->execute([$userId]);
    $settings = $settingsQuery->fetch();
    if (!$settings) {
        throw new RuntimeException('Settings row was not available.');
    }
} catch (Throwable $exception) {
    error_log('PASCCO settings foundation could not be loaded.');
    http_response_code(503);
    exit('Settings are not ready yet. Please import database_migration_settings_phase1.sql and try again.');
}

function settings_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
    <title>Settings | PASCCO</title>
</head>
<body>
<?php pascco_member_header('Settings'); ?>
<main class="settings-center member-content">
    <section class="settings-hero pascco-settings-reveal" aria-labelledby="settings-title">
        <div>
            <div class="settings-eyebrow">Account center</div>
            <h1 id="settings-title">Settings</h1>
            <p>Manage your profile, account security, notifications, privacy choices, and other PASCCO preferences from one place.</p>
        </div>
        <div class="settings-hero-badge">
            <strong>Account settings</strong>
            Your security controls remain protected.
        </div>
    </section>

    <div class="settings-notice" role="status">
        <i class='bx bx-shield-check' aria-hidden="true"></i>
        <div><strong>Your account security is protected.</strong><br>Security-sensitive changes use the existing authentication, CSRF, verification, and authorization controls.</div>
    </div>

    <section class="settings-section" aria-labelledby="account-heading">
        <div class="settings-section-heading">
            <h2 id="account-heading">Account</h2>
            <p>Manage your personal information and account credentials.</p>
        </div>
        <div class="settings-grid">
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-user' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Account &amp; Profile</h3>
                    <p>Update your name and phone number and review your PASCCO account identifiers.</p>
                    <a class="settings-card-link pascco-settings-link" href="profile.php">Manage profile <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-lock-alt' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Password</h3>
                    <p>Change your password after verifying your current password.</p>
                    <a class="settings-card-link pascco-settings-link" href="change_password.php">Manage password <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
        </div>
    </section>

    <section class="settings-section" aria-labelledby="security-heading">
        <div class="settings-section-heading">
            <h2 id="security-heading">Security &amp; Activity</h2>
            <p>Protect your account and review where and how it has been used.</p>
        </div>
        <div class="settings-grid">
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-shield-quarter' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Multi-Factor Authentication</h3>
                    <p>Manage authenticator-app MFA and strengthen sign-in protection.</p>
                    <a class="settings-card-link pascco-settings-link" href="mfa_settings.php">Manage MFA <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-devices' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Active Sessions</h3>
                    <p>Review signed-in devices and remotely sign out sessions you do not recognize.</p>
                    <a class="settings-card-link pascco-settings-link" href="active_sessions.php">Review sessions <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-history' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Login &amp; Security History</h3>
                    <p>Review recent sign-in, verification, password, and session security events.</p>
                    <a class="settings-card-link pascco-settings-link" href="login_history.php">View history <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
        </div>
    </section>

    <section class="settings-section" aria-labelledby="preferences-heading">
        <div class="settings-section-heading">
            <h2 id="preferences-heading">Preferences &amp; Privacy</h2>
            <p>Control optional communications and review the current privacy notice.</p>
        </div>
        <div class="settings-grid">
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-bell' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Notification Preferences</h3>
                    <p>Manage optional loan reminders, announcements, general updates, and the supported email channel.</p>
                    <a class="settings-card-link pascco-settings-link" href="notification_preferences.php">Manage notifications <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-shield' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Privacy &amp; Consent</h3>
                    <p>Review essential information processing, optional communication choices, and privacy-notice acknowledgment.</p>
                    <a class="settings-card-link pascco-settings-link" href="privacy_settings.php">Review privacy settings <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-palette' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Appearance</h3>
                    <p>Current saved preference: <?php echo settings_escape($settings['theme']); ?> theme and <?php echo settings_escape($settings['text_size']); ?> text size.</p>
                    <span class="settings-status-tag is-planned">Preference saved</span>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-globe' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Language</h3>
                    <p>Current saved language: <?php echo settings_escape($settings['language_code']); ?>. Language switching is not enabled yet.</p>
                    <span class="settings-status-tag is-planned">Coming later</span>
                </div>
            </article>
        </div>
    </section>

    <section class="settings-section" aria-labelledby="other-heading">
        <div class="settings-section-heading">
            <h2 id="other-heading">Other</h2>
            <p>Additional member resources and account documents.</p>
        </div>
        <div class="settings-grid">
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-file' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Documents</h3>
                    <p>Centralized access to statements, receipts, and official documents will be developed separately.</p>
                    <span class="settings-status-tag is-planned">Coming later</span>
                </div>
            </article>
            <article class="settings-card pascco-settings-card pascco-settings-stagger">
                <div class="settings-card-icon"><i class='bx bx-help-circle' aria-hidden="true"></i></div>
                <div class="settings-card-content">
                    <h3>Help &amp; Support</h3>
                    <p>Open the existing PASCCO support page for current help resources.</p>
                    <a class="settings-card-link pascco-settings-link" href="/paco_cooperative/public/support.php">Open support <i class='bx bx-right-arrow-alt' aria-hidden="true"></i></a>
                </div>
            </article>
        </div>
    </section>

    <p class="settings-meta">Settings initialized: <?php echo settings_escape($settings['created_at']); ?> · Last updated: <?php echo settings_escape($settings['updated_at']); ?></p>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
