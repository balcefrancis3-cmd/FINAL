<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$noticeVersion = 'privacy_notice_v1';
$message = '';
$error = '';

function privacy_settings_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function load_privacy_acknowledgment(PDO $pdo, int $userId): ?array
{
    $stmt = $pdo->prepare(
        'SELECT notice_version, acknowledged_at, updated_at
         FROM member_privacy_acknowledgments
         WHERE user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

try {
    $acknowledgment = load_privacy_acknowledgment($pdo, $userId);
} catch (Throwable $exception) {
    error_log('PASCCO privacy settings could not be loaded: ' . $exception->getMessage());
    http_response_code(503);
    exit('Privacy settings are not ready yet. Please import database_migration_settings_phase9_privacy.sql and try again.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'acknowledge_notice') {
        try {
            $pdo->beginTransaction();

            $upsert = $pdo->prepare(
                'INSERT INTO member_privacy_acknowledgments (user_id, notice_version, acknowledged_at)
                 VALUES (?, ?, CURRENT_TIMESTAMP)
                 ON DUPLICATE KEY UPDATE
                    notice_version = VALUES(notice_version),
                    acknowledged_at = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP'
            );
            $upsert->execute([$userId, $noticeVersion]);

            if ($upsert->rowCount() < 1) {
                throw new RuntimeException('Privacy notice acknowledgment did not update the member record.');
            }

            record_audit($pdo, $userId, 'privacy_notice_acknowledged', 'Acknowledged the current PASCCO privacy notice version ' . $noticeVersion . '.');
            $pdo->commit();

            $message = 'Your acknowledgment of the current privacy notice was recorded.';
            $acknowledgment = load_privacy_acknowledgment($pdo, $userId);
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('PASCCO privacy notice acknowledgment failed: ' . $exception->getMessage());
            $error = 'Your privacy notice acknowledgment could not be saved. No changes were made.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
    <title>Privacy &amp; Consent | PASCCO</title>
    <style>
        body { margin:0; background:#f4f7fb; color:#182a45; font-family:Georgia,'Times New Roman',serif; }
        .privacy-page { max-width:1000px; margin:0 auto; padding:36px 22px 64px; }
        .heading { margin-bottom:24px; }
        .eyebrow { color:#9b7416; font:700 12px/1.4 Arial,sans-serif; letter-spacing:.13em; text-transform:uppercase; }
        .heading h1 { margin:8px 0; color:#071d49; font-size:clamp(28px,4vw,38px); }
        .heading p { max-width:760px; color:#5c6c81; line-height:1.6; }
        .notice { margin-bottom:18px; padding:13px 15px; border-radius:8px; font:14px/1.5 Arial,sans-serif; }
        .success { background:#f0faf3; border:1px solid #d6e4d9; color:#22543d; }
        .error { background:#fff2f2; border:1px solid #efd0d0; color:#8a2c2c; }
        .card { margin-bottom:18px; background:#fff; border:1px solid #dbe3ef; border-radius:12px; box-shadow:0 5px 18px rgba(7,29,73,.04); overflow:hidden; }
        .card-head { padding:22px 24px; border-bottom:1px solid #e4eaf2; }
        .card-head h2 { margin:0 0 5px; color:#071d49; font-size:20px; }
        .card-head p { margin:0; color:#68788d; font:14px/1.55 Arial,sans-serif; }
        .item { padding:18px 24px; border-bottom:1px solid #edf1f6; }
        .item:last-child { border-bottom:0; }
        .item h3 { margin:0 0 6px; color:#071d49; font:700 16px Arial,sans-serif; }
        .item p { margin:0; color:#647388; font:13px/1.6 Arial,sans-serif; }
        .tag { display:inline-block; margin-top:9px; padding:4px 8px; border-radius:999px; background:#eef3f9; color:#53667d; font:700 10px Arial,sans-serif; letter-spacing:.04em; text-transform:uppercase; }
        .ack { padding:22px 24px; background:#fbfcfe; border-top:1px solid #e4eaf2; }
        .ack-row { display:flex; align-items:center; justify-content:space-between; gap:20px; }
        .ack-row p { margin:0; color:#647388; font:13px/1.55 Arial,sans-serif; }
        .acknowledged { color:#22543d; font-weight:700; }
        button { border:0; border-radius:7px; background:#1456a0; color:#fff; cursor:pointer; font:700 14px Arial,sans-serif; padding:12px 18px; white-space:nowrap; }
        button:hover { background:#0d4380; }
        .links { display:flex; flex-wrap:wrap; gap:12px; margin-top:18px; }
        .links a { color:#1456a0; font:700 13px Arial,sans-serif; }
        @media(max-width:650px){ .privacy-page{padding:26px 16px 44px}.ack-row{align-items:flex-start;flex-direction:column}.button{width:100%} }
    </style>
</head>
<body>
<?php pascco_member_header('Privacy & Consent'); ?>
<main class="pascco-settings-reveal privacy-page member-content">
<a class="settings-back" href="settings.php"><i class='bx bx-left-arrow-alt' aria-hidden="true"></i> Back to Settings</a>
    <header class="heading">
        <div class="eyebrow">Privacy controls</div>
        <h1>Privacy &amp; Consent</h1>
        <p>Review how PASCCO uses information needed to provide cooperative services. Essential processing cannot be disabled from Settings because it supports account security, financial records, and required cooperative operations.</p>
    </header>

    <?php if ($message !== ''): ?><div class="notice success" role="status"><?php echo privacy_settings_escape($message); ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="notice error" role="alert"><?php echo privacy_settings_escape($error); ?></div><?php endif; ?>

    <section class="card pascco-settings-stagger"
        <div class="card-head"><h2>Essential information processing</h2><p>These activities are necessary for PASCCO services and are not optional Settings switches.</p></div>
        <div class="item"><h3>Membership &amp; account records</h3><p>Your identity, contact information, membership details, and account records are maintained to provide cooperative services.</p><span class="tag">Required</span></div>
        <div class="item"><h3>Savings, loans &amp; transactions</h3><p>Financial records are processed to operate accounts, loans, payments, deposits, statements, and related cooperative services.</p><span class="tag">Required</span></div>
        <div class="item"><h3>Security &amp; fraud prevention</h3><p>Authentication, security events, audit records, and session information are used to protect accounts and investigate suspicious activity.</p><span class="tag">Required</span></div>
        <div class="item"><h3>Legal &amp; reporting obligations</h3><p>Information may be retained or processed when required for cooperative administration, reporting, or applicable legal obligations.</p><span class="tag">Required</span></div>
    </section>

    <section class="card pascco-settings-stagger"
        <div class="card-head"><h2>Optional communications</h2><p>Optional communication choices are managed separately under Notification Preferences.</p></div>
        <div class="item"><h3>Notification preferences</h3><p>You can manage optional loan reminders, announcements, general updates, and the supported email notification channel without disabling required security messages.</p><div class="links"><a href="notification_preferences.php">Manage notification preferences</a></div></div>
    </section>

    <section class="card pascco-settings-stagger"
        <div class="card-head"><h2>Privacy notice acknowledgment</h2><p>This records that you reviewed the current PASCCO privacy notice. It is an acknowledgment record, not a claim that optional processing can override required cooperative or legal obligations.</p></div>
        <div class="ack">
            <div class="ack-row">
                <p><?php if ($acknowledgment && $acknowledgment['notice_version'] === $noticeVersion): ?><span class="acknowledged">Acknowledged.</span> Current notice: <?php echo privacy_settings_escape($acknowledgment['notice_version']); ?> on <?php echo privacy_settings_escape($acknowledgment['acknowledged_at']); ?>.<?php else: ?>Current notice version: <strong><?php echo privacy_settings_escape($noticeVersion); ?></strong>.<?php endif; ?></p>
                <form class="pascco-settings-form" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo privacy_settings_escape($_SESSION['csrf_token'] ?? ''); ?>">
                    <input type="hidden" name="action" value="acknowledge_notice">
                    <button type="submit">Acknowledge Privacy Notice</button>
                </form>
            </div>
        </div>
    </section>

    <section class="card pascco-settings-stagger"
        <div class="card-head"><h2>Privacy requests</h2><p>For corrections, access requests, or privacy concerns, use the official PASCCO support contact listed in the public privacy notice.</p><div class="links"><a href="/paco_cooperative/public/privacy.php">Read Privacy &amp; Terms</a><a href="/paco_cooperative/public/support.php">Open Support</a></div></div>
    </section>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
