<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../security/auth.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member' || empty($_SESSION['email_otp_verified'])) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$configKey = base64_decode($pascco_config['encryption_key'] ?? '', true);
if ($configKey === false || strlen($configKey) !== 32) {
    http_response_code(503);
    exit('PASCCO security configuration is not ready.');
}

$loadMfa = $pdo->prepare('SELECT secret, last_step FROM user_mfa WHERE user_id = ? LIMIT 1');
$loadMfa->execute([$userId]);
$mfa = $loadMfa->fetch();
$enabled = (bool) $mfa;
$error = '';
$message = '';
$enrollmentSecret = (string) ($_SESSION['settings_mfa_enrollment_secret'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    try {
        $pdo->beginTransaction();
        $lockUser = $pdo->prepare('SELECT password, status, role FROM users WHERE id = ? FOR UPDATE');
        $lockUser->execute([$userId]);
        $user = $lockUser->fetch();
        if (!$user || $user['status'] !== 'active' || $user['role'] !== 'member') {
            throw new RuntimeException('Account is not available.');
        }

        if ($action === 'start_enrollment') {
            if ($mfa) {
                throw new RuntimeException('Authenticator app protection is already enabled.');
            }
            if (!password_verify((string) ($_POST['current_password'] ?? ''), (string) $user['password'])) {
                throw new RuntimeException('The current password is incorrect.');
            }
            $_SESSION['settings_mfa_enrollment_secret'] = pascco_base32_encode(random_bytes(20));
            $_SESSION['settings_mfa_enrollment_started'] = time();
            $pdo->rollBack();
            $enrollmentSecret = $_SESSION['settings_mfa_enrollment_secret'];
            $message = 'Enrollment started. Add PASCCO to your authenticator app and enter the current code below.';
        } elseif ($action === 'finish_enrollment') {
            if ($mfa || $enrollmentSecret === '' || time() - (int) ($_SESSION['settings_mfa_enrollment_started'] ?? 0) > 600) {
                throw new RuntimeException('The enrollment session has expired. Start again.');
            }
            if (!password_verify((string) ($_POST['current_password'] ?? ''), (string) $user['password'])) {
                throw new RuntimeException('The current password is incorrect.');
            }
            $step = pascco_totp_step($enrollmentSecret, trim((string) ($_POST['otp'] ?? '')), -1);
            if ($step === null) {
                throw new RuntimeException('Invalid authenticator code. Check your phone clock and try again.');
            }
            $encrypted = pascco_encrypt_secret($enrollmentSecret, $configKey);
            $insert = $pdo->prepare('INSERT INTO user_mfa (user_id, secret, last_step) VALUES (?, ?, ?)');
            $insert->execute([$userId, $encrypted, $step]);
            if ($insert->rowCount() !== 1) {
                throw new RuntimeException('Authenticator enrollment could not be saved.');
            }
            $pdo->commit();
            unset($_SESSION['settings_mfa_enrollment_secret'], $_SESSION['settings_mfa_enrollment_started']);
            $_SESSION['member_mfa_verified'] = true;
            $_SESSION['member_mfa_version'] = hash('sha256', $encrypted);
            record_audit($pdo, $userId, 'mfa_enabled', 'Member enabled authenticator-app MFA from Settings.', 'success');
            $mfa = ['secret' => $encrypted, 'last_step' => $step];
            $enabled = true;
            $enrollmentSecret = '';
            $message = 'Authenticator app MFA is now enabled for this account.';
        } elseif ($action === 'disable') {
            if (!$mfa) {
                throw new RuntimeException('Authenticator app protection is not enabled.');
            }
            if (!password_verify((string) ($_POST['current_password'] ?? ''), (string) $user['password'])) {
                throw new RuntimeException('The current password is incorrect.');
            }
            $secret = pascco_decrypt_secret((string) $mfa['secret'], $configKey);
            $step = pascco_totp_step($secret, trim((string) ($_POST['otp'] ?? '')), (int) $mfa['last_step']);
            if ($step === null) {
                throw new RuntimeException('Invalid or already used authenticator code.');
            }
            $delete = $pdo->prepare('DELETE FROM user_mfa WHERE user_id = ?');
            $delete->execute([$userId]);
            if ($delete->rowCount() !== 1) {
                throw new RuntimeException('Authenticator protection could not be disabled.');
            }
            $pdo->commit();
            unset($_SESSION['member_mfa_verified'], $_SESSION['member_mfa_version']);
            record_audit($pdo, $userId, 'mfa_disabled', 'Member disabled authenticator-app MFA from Settings.', 'success');
            $mfa = false;
            $enabled = false;
            $message = 'Authenticator app MFA has been disabled.';
        } else {
            throw new RuntimeException('Invalid security action.');
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        $error = $exception->getMessage();
        if ($action === 'start_enrollment' && $error !== 'The current password is incorrect.') {
            $error = 'Enrollment could not be started. Please try again.';
        }
        if ($action === 'finish_enrollment' && $error === 'The current password is incorrect.') {
            // Keep the actionable password message.
        }
        if ($action === 'disable' && $error === 'The current password is incorrect.') {
            // Keep the actionable password message.
        }
        if (str_contains($error, 'Authenticator') || str_contains($error, 'authenticator') || str_contains($error, 'code') || str_contains($error, 'expired')) {
            // Safe user-facing MFA validation messages are retained.
        }
    }
}

$loadMfa->execute([$userId]);
$mfa = $loadMfa->fetch();
$enabled = (bool) $mfa;
if ($enabled) {
    $enrollmentSecret = '';
}
function mfa_settings_escape($value): string { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
<title>MFA Settings | PASCCO</title>
<link rel="stylesheet" href="/paco_cooperative/assets/css/member-panels.css?v=2">
<style>
body{margin:0;background:#f4f7fb;color:#182a45;font-family:Georgia,'Times New Roman',serif}.mfa-page{max-width:760px;margin:0 auto;padding:36px 22px 64px}.mfa-card{background:#fff;border:1px solid #dbe3ef;border-radius:12px;padding:26px;box-shadow:0 5px 18px rgba(7,29,73,.04);margin-top:18px}.mfa-card h1{color:#071d49;margin:0 0 10px}.mfa-card h2{color:#071d49;font-size:19px}.mfa-card p{color:#617187;line-height:1.6}.status{padding:13px 15px;border-radius:8px;margin:18px 0}.status.ok{background:#edf7f0;border:1px solid #cfe4d5;color:#22543d}.status.error{background:#fff1f1;border:1px solid #efcccc;color:#9b2c2c}.setup-key{display:block;overflow-wrap:anywhere;background:#fff4cf;border:1px solid #ead38a;border-radius:8px;padding:15px;font:700 18px/1.4 monospace;letter-spacing:2px;color:#513d08}.form-row{margin:16px 0}.form-row label{display:block;font-weight:700;color:#182a45;margin-bottom:7px}.form-row input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #c5d1df;border-radius:7px;font:inherit}.primary,.danger{padding:12px 18px;border-radius:7px;font-weight:700;cursor:pointer}.primary{border:1px solid #1456a0;background:#1456a0;color:#fff}.danger{border:1px solid #9b2c2c;background:#fff;color:#9b2c2c}.back{display:inline-block;margin-bottom:14px;color:#1456a0;text-decoration:none;font-weight:700}
</style>
</head>
<body>
<?php pascco_member_header('MFA Settings'); ?>
<main class="pascco-settings-reveal mfa-page member-content">
<a class="back settings-back" href="settings.php">← Back to Settings</a>
<section class="mfa-card">
<h1>Authenticator App</h1>
<p>Use a time-based authenticator app as an additional sign-in factor. Your authenticator secret is encrypted before it is stored by PASCCO.</p>
<?php if ($message): ?><div class="status ok" role="status"><?php echo mfa_settings_escape($message); ?></div><?php endif; ?>
<?php if ($error): ?><div class="status error" role="alert"><?php echo mfa_settings_escape($error); ?></div><?php endif; ?>
<?php if ($enabled): ?>
<div class="status ok"><strong>Enabled.</strong> Authenticator-app MFA is active on this member account.</div>
<form class="pascco-settings-form" method="post">
<input type="hidden" name="csrf_token" value="<?php echo mfa_settings_escape($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="disable">
<div class="form-row"><label for="disable-password">Current password</label><input id="disable-password" type="password" name="current_password" autocomplete="current-password" required></div>
<div class="form-row"><label for="disable-otp">Current authenticator code</label><input id="disable-otp" type="text" name="otp" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required></div>
<button class="danger" type="submit">Disable authenticator MFA</button>
</form>
<?php elseif ($enrollmentSecret !== ''): ?>
<h2>Finish enrollment</h2>
<p>Open your authenticator app, add a new time-based account named <strong>PASCCO</strong>, and enter this setup key:</p>
<code class="setup-key"><?php echo mfa_settings_escape($enrollmentSecret); ?></code>
<p>This setup key is shown only during this enrollment session. Never share it with another person.</p>
<form class="pascco-settings-form" method="post">
<input type="hidden" name="csrf_token" value="<?php echo mfa_settings_escape($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="finish_enrollment">
<div class="form-row"><label for="finish-password">Current password</label><input id="finish-password" type="password" name="current_password" autocomplete="current-password" required></div>
<div class="form-row"><label for="finish-otp">Authenticator code</label><input id="finish-otp" type="text" name="otp" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required></div>
<button class="primary" type="submit">Enable authenticator MFA</button>
</form>
<?php else: ?>
<div class="status"><strong>Not enabled.</strong> Your member account currently uses the existing email verification step during sign-in.</div>
<form class="pascco-settings-form" method="post">
<input type="hidden" name="csrf_token" value="<?php echo mfa_settings_escape($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="start_enrollment">
<div class="form-row"><label for="start-password">Current password</label><input id="start-password" type="password" name="current_password" autocomplete="current-password" required></div>
<button class="primary" type="submit">Set up authenticator app</button>
</form>
<?php endif; ?>
</section>
</main>
<?php pascco_global_footer(); ?>
</body></html>
