<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member' || empty($_SESSION['email_otp_verified'])) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 25;
$offset = ($page - 1) * $perPage;
$events = [
    'login',
    'password_verified',
    'member_otp_sent',
    'member_otp_resent',
    'member_otp_failed',
    'member_mfa_verified',
    'member_mfa_failed',
    'password_change',
    'password_reset',
    'password_change_failed',
    'session_revoked',
    'sessions_revoked_others',
];

function login_history_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$placeholders = implode(',', array_fill(0, count($events), '?'));
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM audit_logs WHERE user_id = ? AND action IN ($placeholders)");
$countStmt->execute(array_merge([$userId], $events));
$total = (int) $countStmt->fetchColumn();
$totalPages = max(1, (int) ceil($total / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $perPage;
}

$listStmt = $pdo->prepare(
    "SELECT action, description, ip_address, status, created_at
     FROM audit_logs
     WHERE user_id = ? AND action IN ($placeholders)
     ORDER BY created_at DESC, id DESC
     LIMIT $perPage OFFSET $offset"
);
$listStmt->execute(array_merge([$userId], $events));
$rows = $listStmt->fetchAll();

function login_history_event_label(string $action): string
{
    return match ($action) {
        'login' => 'Login',
        'password_verified' => 'Password verified',
        'member_otp_sent' => 'Email verification sent',
        'member_otp_resent' => 'Email verification resent',
        'member_otp_failed' => 'Email verification failed',
        'member_mfa_verified' => 'Authenticator verified',
        'member_mfa_failed' => 'Authenticator verification failed',
        'password_change' => 'Password changed',
        'password_reset' => 'Password reset',
        'password_change_failed' => 'Password change failed',
        'session_revoked' => 'Session signed out',
        'sessions_revoked_others' => 'Other sessions signed out',
        default => ucwords(str_replace('_', ' ', $action)),
    };
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
<title>Login History | PASCCO</title>
<style>
body{margin:0;background:#f4f7fb;color:#182a45;font-family:Georgia,'Times New Roman',serif}.history-page{max-width:1000px;margin:0 auto;padding:36px 22px 64px}.back{display:inline-block;margin-bottom:14px;color:#1456a0;text-decoration:none;font-weight:700}.heading h1{margin:0 0 8px;color:#071d49}.heading p{margin:0;color:#617187;line-height:1.6}.card{background:#fff;border:1px solid #dbe3ef;border-radius:12px;padding:22px;box-shadow:0 5px 18px rgba(7,29,73,.04);margin-top:18px}.table-wrap{overflow-x:auto}.history-table{width:100%;border-collapse:collapse;min-width:760px}.history-table th,.history-table td{text-align:left;padding:14px 12px;border-bottom:1px solid #e5ebf2;vertical-align:top}.history-table th{font:700 12px Arial,sans-serif;text-transform:uppercase;letter-spacing:.04em;color:#617187;background:#f8fafc}.event{font-weight:700;color:#071d49}.desc{margin-top:4px;color:#617187;font-size:13px;line-height:1.45}.status{font:700 12px Arial,sans-serif}.success{color:#28734a}.failed{color:#a33a3a}.ip{font:13px Arial,sans-serif;color:#334a68}.time{white-space:nowrap;font:13px Arial,sans-serif;color:#334a68}.empty{color:#617187}.pager{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:18px;font:13px Arial,sans-serif}.pager a{color:#1456a0;text-decoration:none;font-weight:700}.note{margin-top:16px;font:12px/1.6 Arial,sans-serif;color:#6b7789}@media(max-width:650px){.history-page{padding:26px 16px 44px}.card{padding:14px}.pager{flex-direction:column;align-items:stretch}.pager a{text-align:center;padding:10px;border:1px solid #c5d1df;border-radius:7px}}
</style>
</head>
<body>
<?php pascco_member_header('Login History'); ?>
<main class="pascco-settings-reveal history-page member-content">
<a class="back settings-back" href="settings.php">← Back to Settings</a>
<section class="heading"><h1>Login History</h1><p>Review recent sign-in and security events associated with your PASCCO account.</p></section>
<section class="card pascco-settings-stagger">
<?php if (!$rows): ?><p class="empty">No login or security history is available yet.</p><?php else: ?>
<div class="table-wrap"><table class="history-table"><thead><tr><th>Event</th><th>Status</th><th>IP Address</th><th>Date &amp; Time</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td><div class="event"><?php echo login_history_escape(login_history_event_label((string)$row['action'])); ?></div><div class="desc"><?php echo login_history_escape($row['description']); ?></div></td><td class="status <?php echo $row['status'] === 'success' ? 'success' : 'failed'; ?>"><?php echo login_history_escape(ucfirst((string)$row['status'])); ?></td><td class="ip"><?php echo login_history_escape($row['ip_address'] ?: 'Unavailable'); ?></td><td class="time"><?php echo login_history_escape($row['created_at']); ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<div class="pager"><span>Page <?php echo $page; ?> of <?php echo $totalPages; ?> · <?php echo $total; ?> event(s)</span><span><?php if($page>1): ?><a href="?page=<?php echo $page-1; ?>">← Newer</a><?php endif; ?><?php if($page>1 && $page<$totalPages): ?> &nbsp;·&nbsp; <?php endif; ?><?php if($page<$totalPages): ?><a href="?page=<?php echo $page+1; ?>">Older →</a><?php endif; ?></span></div>
<?php endif; ?>
<p class="note">PASCCO records the IP address supplied by the connection. Geographic location is not shown because the current audit system does not store a verified location and the system will not guess one from an IP address.</p>
</section>
</main>
</body></html>
