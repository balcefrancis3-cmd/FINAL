<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$message = '';
$error = '';

function profile_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function load_member_profile(PDO $pdo, int $userId): ?array
{
    $stmt = $pdo->prepare(
        'SELECT u.username, m.first_name, m.last_name, m.email, m.phone, m.member_number
         FROM users u
         JOIN members m ON m.user_id = u.id
         WHERE u.id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $profile = $stmt->fetch();
    return $profile ?: null;
}

$profile = load_member_profile($pdo, $userId);

if (!$profile) {
    http_response_code(404);
    exit('Member profile not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    if (($_POST['action'] ?? '') === 'profile') {
        $firstName = trim((string) ($_POST['first_name'] ?? ''));
        $lastName = trim((string) ($_POST['last_name'] ?? ''));
        $phone = trim((string) ($_POST['phone'] ?? ''));

        if ($firstName === '' || mb_strlen($firstName) > 100 || $lastName === '' || mb_strlen($lastName) > 100) {
            $error = 'Please provide valid first and last names.';
        } elseif ($phone === '' || mb_strlen($phone) > 30 || !preg_match('/^[0-9+()\-\s.]{7,30}$/', $phone)) {
            $error = 'Please provide a valid phone number.';
        } else {
            try {
                $pdo->beginTransaction();

                $update = $pdo->prepare(
                    'UPDATE members
                     SET first_name = ?, last_name = ?, phone = ?
                     WHERE user_id = ?'
                );
                $update->execute([$firstName, $lastName, $phone, $userId]);

                if ($update->rowCount() !== 1 && (
                    $firstName !== (string) $profile['first_name']
                    || $lastName !== (string) $profile['last_name']
                    || $phone !== (string) $profile['phone']
                )) {
                    throw new RuntimeException('Member profile update did not affect exactly one record.');
                }

                $pdo->commit();
                record_audit($pdo, $userId, 'profile_update', 'Updated member profile name/contact details.');
                $message = 'Your profile details were updated successfully.';
                $profile = load_member_profile($pdo, $userId);
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log('PASCCO member profile update failed: ' . $exception->getMessage());
                $error = 'Your profile could not be updated. No changes were saved.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
    <title>Account &amp; Profile | PASCCO</title>
    <style>
        body { background: #f4f7fb; color: #182a45; font-family: Georgia, 'Times New Roman', serif; margin: 0; }
        .profile-page { margin: 0 auto; max-width: 980px; padding: 42px 22px 70px; }
        .heading { margin-bottom: 24px; }
        .eyebrow { color: #9b7416; font: 700 12px/1.4 Arial, sans-serif; letter-spacing: .12em; text-transform: uppercase; }
        .heading h1 { color: #071d49; margin: 8px 0; font-size: clamp(28px, 4vw, 38px); }
        .heading p { color: #617187; line-height: 1.6; max-width: 720px; margin: 0; }
        .columns { display: grid; gap: 22px; grid-template-columns: minmax(0, 1.25fr) minmax(280px, .75fr); }
        .card { background: white; border: 1px solid #d8e0ee; border-top: 4px solid #1456a0; border-radius: 10px; padding: 24px; box-shadow: 0 5px 18px rgba(7,29,73,.04); }
        .card h2 { color: #071d49; margin: 0 0 6px; font-size: 20px; }
        .card-intro { color: #69788b; font: 14px/1.55 Arial, sans-serif; margin: 0 0 18px; }
        label { color: #071d49; display: block; font-weight: bold; margin: 14px 0 6px; }
        input { box-sizing: border-box; border: 1px solid #b8c8d9; border-radius: 5px; font: inherit; padding: 11px 12px; width: 100%; }
        input:focus { border-color: #1456a0; outline: 3px solid rgba(20,86,160,.13); }
        input[readonly] { background: #f3f6fa; color: #66758a; cursor: not-allowed; }
        button { background: #1456a0; border: 0; border-radius: 5px; color: white; cursor: pointer; font: inherit; font-weight: bold; margin-top: 18px; padding: 12px 16px; width: 100%; }
        button:hover { background: #0d4380; }
        .notice, .error { margin-bottom: 18px; padding: 12px 14px; border-radius: 6px; font: 14px/1.5 Arial, sans-serif; }
        .notice { background: #eef8f1; border-left: 4px solid #2f855a; color: #22543d; }
        .error { background: #f8d7da; border-left: 4px solid #dc3545; color: #721c24; }
        .readonly-note { margin: 8px 0 0; color: #6a7788; font: 12px/1.5 Arial, sans-serif; }
        .account-list { display: grid; gap: 14px; margin-top: 18px; }
        .account-item { padding-bottom: 14px; border-bottom: 1px solid #e4eaf2; }
        .account-item:last-child { border-bottom: 0; padding-bottom: 0; }
        .account-item small { display: block; color: #738196; font: 700 11px/1.4 Arial, sans-serif; letter-spacing: .04em; text-transform: uppercase; }
        .account-item strong { display: block; color: #1d2e47; margin-top: 3px; overflow-wrap: anywhere; }
        .security-note { margin-top: 18px; padding: 13px 14px; background: #f6f8fb; border-radius: 7px; color: #5e6e82; font: 13px/1.55 Arial, sans-serif; }
        @media (max-width: 760px) { .profile-page { padding: 28px 16px 50px; } .columns { grid-template-columns: 1fr; } }
    </style>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/member-panels.css?v=2">
</head>
<body>
<?php pascco_member_header('Account & Profile'); ?>
<main class="pascco-settings-reveal profile-page member-content">
<a class="settings-back" href="settings.php"><i class='bx bx-left-arrow-alt' aria-hidden="true"></i> Back to Settings</a>
    <section class="heading">
        <div class="eyebrow">Settings / Account</div>
        <h1>Account &amp; Profile</h1>
        <p>Keep your member information current. Changes are limited to profile details that can safely be updated from the member portal.</p>
    </section>

    <?php if ($message): ?><div class="notice" role="status"><?php echo profile_escape($message); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="error" role="alert"><?php echo profile_escape($error); ?></div><?php endif; ?>

    <div class="columns">
        <section class="card pascco-settings-stagger">
            <h2>Personal Information</h2>
            <p class="card-intro">Update your name and contact number. Your member number is assigned by PASCCO and cannot be changed here.</p>
            <form class="pascco-settings-form" method="POST" action="profile.php" autocomplete="on">
                <input type="hidden" name="csrf_token" value="<?php echo profile_escape($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="profile">

                <label for="member-number">Member Number</label>
                <input id="member-number" value="<?php echo profile_escape($profile['member_number']); ?>" readonly aria-readonly="true">

                <label for="first-name">First Name</label>
                <input id="first-name" name="first_name" maxlength="100" value="<?php echo profile_escape($profile['first_name']); ?>" autocomplete="given-name" required>

                <label for="last-name">Last Name</label>
                <input id="last-name" name="last_name" maxlength="100" value="<?php echo profile_escape($profile['last_name']); ?>" autocomplete="family-name" required>

                <label for="email">Login Email</label>
                <input id="email" type="email" value="<?php echo profile_escape($profile['email']); ?>" readonly aria-readonly="true">
                <p class="readonly-note">Email changes require a separate verification workflow and are not directly editable yet.</p>

                <label for="phone">Phone Number</label>
                <input id="phone" type="tel" name="phone" maxlength="30" value="<?php echo profile_escape($profile['phone']); ?>" autocomplete="tel" placeholder="09XX XXX XXXX" required>

                <button type="submit">Save Profile Changes</button>
            </form>
        </section>

        <aside class="card">
            <h2>Account Information</h2>
            <p class="card-intro">These identifiers help you recognize the account associated with your PASCCO membership.</p>
            <div class="account-list">
                <div class="account-item"><small>Member Number</small><strong><?php echo profile_escape($profile['member_number']); ?></strong></div>
                <div class="account-item"><small>Login Email</small><strong><?php echo profile_escape($profile['email']); ?></strong></div>
                <div class="account-item"><small>Username</small><strong><?php echo profile_escape($profile['username']); ?></strong></div>
            </div>
            <div class="security-note">
                For security, sensitive credential changes such as password and authentication settings are handled separately from profile information.
            </div>
        </aside>
    </div>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
