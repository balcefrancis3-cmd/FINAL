<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$message = '';
$error = '';

function notification_preferences_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function load_notification_preferences(PDO $pdo, int $userId): ?array
{
    $stmt = $pdo->prepare(
        'SELECT loan_payment_reminders, announcements, general_updates, email_notifications, created_at, updated_at
         FROM member_notification_preferences
         WHERE user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $preferences = $stmt->fetch(PDO::FETCH_ASSOC);
    return $preferences ?: null;
}

try {
    $createDefaults = $pdo->prepare('INSERT IGNORE INTO member_notification_preferences (user_id) VALUES (?)');
    $createDefaults->execute([$userId]);
    $preferences = load_notification_preferences($pdo, $userId);
    if (!$preferences) {
        throw new RuntimeException('Notification preference row was not available.');
    }
} catch (Throwable $exception) {
    error_log('PASCCO notification preferences could not be loaded: ' . $exception->getMessage());
    http_response_code(503);
    exit('Notification preferences are not ready yet. Please import database_migration_settings_phase7_notifications.sql and try again.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $loanPaymentReminders = isset($_POST['loan_payment_reminders']) ? 1 : 0;
    $announcements = isset($_POST['announcements']) ? 1 : 0;
    $generalUpdates = isset($_POST['general_updates']) ? 1 : 0;
    $emailNotifications = isset($_POST['email_notifications']) ? 1 : 0;

    try {
        $pdo->beginTransaction();

        $update = $pdo->prepare(
            'UPDATE member_notification_preferences
             SET loan_payment_reminders = ?, announcements = ?, general_updates = ?, email_notifications = ?
             WHERE user_id = ?'
        );
        $update->execute([$loanPaymentReminders, $announcements, $generalUpdates, $emailNotifications, $userId]);

        if ($update->rowCount() !== 1 && (
            (int) $preferences['loan_payment_reminders'] !== $loanPaymentReminders
            || (int) $preferences['announcements'] !== $announcements
            || (int) $preferences['general_updates'] !== $generalUpdates
        )) {
            throw new RuntimeException('Notification preference update did not affect exactly one record.');
        }

        $pdo->commit();
        record_audit($pdo, $userId, 'notification_preferences_update', 'Updated optional member notification preferences.');
        $message = 'Your notification preferences were updated successfully.';
        $preferences = load_notification_preferences($pdo, $userId);
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('PASCCO notification preference update failed: ' . $exception->getMessage());
        $error = 'Your notification preferences could not be updated. No changes were saved.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
    <title>Notification Preferences | PASCCO</title>
    <style>
        body { margin:0; background:#f4f7fb; color:#182a45; font-family:Georgia,'Times New Roman',serif; }
        .notification-page { max-width:980px; margin:0 auto; padding:36px 22px 64px; }
        .heading { margin-bottom:24px; }
        .eyebrow { color:#9b7416; font:700 12px/1.4 Arial,sans-serif; letter-spacing:.13em; text-transform:uppercase; }
        .heading h1 { margin:8px 0; color:#071d49; font-size:clamp(28px,4vw,38px); }
        .heading p { max-width:720px; color:#5c6c81; line-height:1.6; }
        .notice { margin-bottom:18px; padding:13px 15px; border-radius:8px; font:14px/1.5 Arial,sans-serif; }
        .success { background:#f0faf3; border:1px solid #d6e4d9; color:#22543d; }
        .error { background:#fff2f2; border:1px solid #efd0d0; color:#8a2c2c; }
        .card { background:#fff; border:1px solid #dbe3ef; border-radius:12px; box-shadow:0 5px 18px rgba(7,29,73,.04); overflow:hidden; }
        .card-head { padding:22px 24px; border-bottom:1px solid #e4eaf2; }
        .card-head h2 { margin:0 0 5px; color:#071d49; font-size:20px; }
        .card-head p { margin:0; color:#68788d; font:14px/1.55 Arial,sans-serif; }
        .option { display:flex; align-items:center; justify-content:space-between; gap:20px; padding:20px 24px; border-bottom:1px solid #edf1f6; }
        .option:last-of-type { border-bottom:0; }
        .option h3 { margin:0 0 5px; color:#071d49; font:700 16px Arial,sans-serif; }
        .option p { margin:0; max-width:700px; color:#647388; font:13px/1.55 Arial,sans-serif; }
        .mandatory { display:inline-block; margin-top:8px; padding:4px 8px; border-radius:999px; background:#eef3f9; color:#53667d; font:700 10px Arial,sans-serif; letter-spacing:.04em; text-transform:uppercase; }
        .switch { position:relative; flex:0 0 auto; }
        .switch input { position:absolute; opacity:0; width:1px; height:1px; }
        .switch label { display:block; width:50px; height:28px; border-radius:999px; background:#aeb9c7; cursor:pointer; transition:.15s ease; }
        .switch label:after { content:''; position:absolute; top:4px; left:4px; width:20px; height:20px; border-radius:50%; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,.2); transition:.15s ease; }
        .switch input:checked + label { background:#1456a0; }
        .switch input:checked + label:after { transform:translateX(22px); }
        .switch input:focus-visible + label { outline:3px solid #e7b84b; outline-offset:3px; }
        .switch input:disabled + label { background:#1456a0; cursor:not-allowed; opacity:.75; }
        .button-row { display:flex; justify-content:flex-end; padding:20px 24px; background:#fbfcfe; border-top:1px solid #e4eaf2; }
        button { border:0; border-radius:7px; background:#1456a0; color:#fff; cursor:pointer; font:700 14px Arial,sans-serif; padding:12px 18px; }
        button:hover { background:#0d4380; }
        .required-note { margin:18px 0 0; color:#66758a; font:12px/1.55 Arial,sans-serif; }
        @media(max-width:650px){ .notification-page{padding:26px 16px 44px}.option{align-items:flex-start;padding:18px}.button-row{padding:18px}.option h3{font-size:15px} }
    </style>
</head>
<body>
<?php pascco_member_header('Notification Preferences'); ?>
<main class="pascco-settings-reveal notification-page member-content">
<a class="settings-back" href="settings.php"><i class='bx bx-left-arrow-alt' aria-hidden="true"></i> Back to Settings</a>
    <header class="heading">
        <div class="eyebrow">Settings</div>
        <h1>Notification Preferences</h1>
        <p>Choose which optional PASCCO updates you would like to receive and which currently supported delivery channel to use. Security verification and required account or transaction communications cannot be disabled here.</p>
    </header>

    <?php if ($message !== ''): ?><div class="notice success" role="status"><?php echo notification_preferences_escape($message); ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="notice error" role="alert"><?php echo notification_preferences_escape($error); ?></div><?php endif; ?>

    <form class="pascco-settings-form card" method="post" action="notification_preferences.php">
        <input type="hidden" name="csrf_token" value="<?php echo notification_preferences_escape($_SESSION['csrf_token'] ?? ''); ?>">
        <div class="card-head">
            <h2>Optional notifications</h2>
            <p>These choices affect optional member communications. Changes apply to future notifications.</p>
        </div>

        <div class="option">
            <div>
                <h3>Email notifications</h3>
                <p>Use your registered PASCCO email address for optional notifications such as loan reminders, announcements, and general updates.</p>
            </div>
            <div class="switch">
                <input type="checkbox" id="email_notifications" name="email_notifications" <?php echo (int)$preferences['email_notifications'] === 1 ? 'checked' : ''; ?>>
                <label for="email_notifications" aria-label="Email notifications"></label>
            </div>
        </div>

        <div class="option">
            <div>
                <h3>Loan payment reminders</h3>
                <p>Receive scheduled email reminders about upcoming and overdue loan payments.</p>
            </div>
            <div class="switch">
                <input type="checkbox" id="loan_payment_reminders" name="loan_payment_reminders" <?php echo (int)$preferences['loan_payment_reminders'] === 1 ? 'checked' : ''; ?>>
                <label for="loan_payment_reminders" aria-label="Loan payment reminders"></label>
            </div>
        </div>

        <div class="option">
            <div>
                <h3>PASCCO announcements</h3>
                <p>Allow optional announcement and cooperative update notifications when supported by the notification channel.</p>
            </div>
            <div class="switch">
                <input type="checkbox" id="announcements" name="announcements" <?php echo (int)$preferences['announcements'] === 1 ? 'checked' : ''; ?>>
                <label for="announcements" aria-label="PASCCO announcements"></label>
            </div>
        </div>

        <div class="option">
            <div>
                <h3>General updates</h3>
                <p>Receive optional non-security cooperative updates and general information when this notification channel becomes available.</p>
            </div>
            <div class="switch">
                <input type="checkbox" id="general_updates" name="general_updates" <?php echo (int)$preferences['general_updates'] === 1 ? 'checked' : ''; ?>>
                <label for="general_updates" aria-label="General updates"></label>
            </div>
        </div>

        <div class="option">
            <div>
                <h3>In-app notifications</h3>
                <p>PASCCO does not currently have an in-app notification inbox. This channel will remain unavailable until that delivery system is implemented.</p>
                <span class="mandatory">Not available yet</span>
            </div>
            <div class="switch">
                <input type="checkbox" id="in_app_notifications" disabled>
                <label for="in_app_notifications" aria-label="In-app notifications unavailable"></label>
            </div>
        </div>

        <div class="option">
            <div>
                <h3>Security and required account notices</h3>
                <p>Authentication codes, password-reset messages, and other required security communications remain enabled to protect your account.</p>
                <span class="mandatory">Required</span>
            </div>
            <div class="switch">
                <input type="checkbox" id="required_security" checked disabled>
                <label for="required_security" aria-label="Required security notifications"></label>
            </div>
        </div>

        <div class="button-row">
            <button type="submit">Save notification preferences</button>
        </div>
    </form>

    <p class="required-note">Notification preferences do not change your account security requirements, authentication controls, or financial transaction rules.</p>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
