<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../security/auth.php';

if (
    empty($_SESSION['member_mfa_pending']) ||
    empty($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'member' ||
    empty($_SESSION['email_otp_verified'])
) {
    header('Location: /paco_cooperative/public/login.php'); exit;
}

$userId = (int) $_SESSION['user_id'];
$configKey = base64_decode($pascco_config['encryption_key'] ?? '', true);
$error = '';

if ($configKey === false || strlen($configKey) !== 32) { http_response_code(503); exit('PASCCO security configuration is not ready.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $allowed = pascco_take_attempt($pdo, 'member-mfa-user', (string) $userId, 8);
    $ipAllowed = pascco_take_attempt($pdo, 'member-mfa-ip', $_SERVER['REMOTE_ADDR'] ?? 'unknown', 30);
    if (!$allowed || !$ipAllowed) { http_response_code(429); header('Retry-After: 900'); $error = 'Too many verification attempts. Please sign in again later.'; }
    else {
        try {
            $stmt = $pdo->prepare('SELECT u.password, u.status, u.role, m.secret, m.last_step FROM users u INNER JOIN user_mfa m ON m.user_id = u.id WHERE u.id = ? LIMIT 1');
            $stmt->execute([$userId]); $user = $stmt->fetch();
            if (!$user || $user['status'] !== 'active' || $user['role'] !== 'member') throw new RuntimeException('Account is not available.');
            $secret = pascco_decrypt_secret((string) $user['secret'], $configKey);
            $step = pascco_totp_step($secret, trim((string) ($_POST['otp'] ?? '')), (int) $user['last_step']);
            if ($step === null) {
                record_audit($pdo, $userId, 'member_mfa_failed', 'Member authenticator verification failed during login.', 'failed');
                throw new RuntimeException('Invalid or already used authenticator code.');
            }
            $pdo->beginTransaction();
            $update = $pdo->prepare('UPDATE user_mfa SET last_step = ? WHERE user_id = ?');
            $update->execute([$step, $userId]);
            if ($update->rowCount() !== 1) throw new RuntimeException('Authenticator state could not be updated.');
            $pdo->commit();
            $_SESSION['member_mfa_verified'] = true;
            $_SESSION['member_mfa_version'] = hash('sha256', $user['secret']);
            unset($_SESSION['member_mfa_pending']);
            $_SESSION['authenticated_at'] = $_SESSION['last_activity'] = time();
            record_audit($pdo, $userId, 'member_mfa_verified', 'Member completed authenticator verification during login.', 'success');
            header('Location: /paco_cooperative/member/dashboard.php'); exit;
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $exception->getMessage() === 'Invalid or already used authenticator code.' ? $exception->getMessage() : 'Verification could not be completed. Please sign in again.';
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><?php pascco_global_styles(); ?><title>Authenticator Verification | PASCCO</title>
<style>body{margin:0;background:#f4f7fb;color:#071d49}.wrap{max-width:560px;margin:48px auto;padding:0 18px}.card{background:#fff;border:1px solid #dbe3ef;border-radius:12px;padding:28px;box-shadow:0 8px 24px rgba(7,29,73,.06)}h1{margin-top:0}.error{padding:12px;background:#fff1f1;color:#9b2c2c;border:1px solid #efcccc;border-radius:8px}label{display:block;font-weight:700;margin:18px 0 8px}input{width:100%;box-sizing:border-box;padding:13px;border:1px solid #c5d1df;border-radius:7px;font-size:18px;text-align:center;letter-spacing:.25em}button{margin-top:18px;width:100%;padding:13px;border:1px solid #1456a0;background:#1456a0;color:#fff;border-radius:7px;font-weight:700}</style></head><body><?php pascco_public_header('Back to login','/paco_cooperative/public/login.php'); ?><main class="wrap"><section class="card"><h1>Authenticator verification</h1><p>Enter the six-digit code from your authenticator app to complete sign-in.</p><?php if($error): ?><p class="error" role="alert"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></p><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><label for="otp">Authenticator code</label><input id="otp" name="otp" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required autofocus><button type="submit">Verify and continue</button></form></section></main></body></html>
