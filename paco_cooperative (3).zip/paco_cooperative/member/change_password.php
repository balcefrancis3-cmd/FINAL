<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member' || empty($_SESSION['email_otp_verified'])) {
    header('Location: /paco_cooperative/public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$message = '';
$error = '';

function password_page_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function validate_new_member_password(string $password, string $confirm): ?string
{
    if (strlen($password) < 12) {
        return 'Your new password must contain at least 12 characters.';
    }
    if (strlen($password) > 128) {
        return 'Your new password must not exceed 128 characters.';
    }
    if ($password !== $confirm) {
        return 'The passwords do not match.';
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $currentPassword = (string) ($_POST['current_password'] ?? '');
    $newPassword = (string) ($_POST['new_password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

    if ($currentPassword === '') {
        $error = 'Please enter your current password.';
    } elseif (($validationError = validate_new_member_password($newPassword, $confirmPassword)) !== null) {
        $error = $validationError;
    } else {
        try {
            $pdo->beginTransaction();

            $lock = $pdo->prepare(
                "SELECT id, password, status, role
                 FROM users
                 WHERE id = ? AND role = 'member'
                 LIMIT 1
                 FOR UPDATE"
            );
            $lock->execute([$userId]);
            $user = $lock->fetch();

            if (!$user || ($user['status'] ?? '') !== 'active') {
                throw new RuntimeException('Your member account is not available.');
            }

            if (!password_verify($currentPassword, (string) $user['password'])) {
                record_audit($pdo, $userId, 'password_change_failed', 'Member password change failed because the current password was incorrect.', 'failed');
                throw new RuntimeException('The current password is incorrect.');
            }

            if (password_verify($newPassword, (string) $user['password'])) {
                throw new RuntimeException('Your new password must be different from your current password.');
            }

            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            if ($newHash === false) {
                throw new RuntimeException('Unable to secure the new password.');
            }

            $update = $pdo->prepare(
                "UPDATE users
                 SET password = ?,
                     otp_code = NULL,
                     otp_expires_at = NULL,
                     otp_attempts = 0
                 WHERE id = ? AND role = 'member' AND status = 'active'"
            );
            $update->execute([$newHash, $userId]);

            if ($update->rowCount() !== 1) {
                throw new RuntimeException('Password update did not affect exactly one member account.');
            }

            $revokeSessions = $pdo->prepare(
                'UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ? AND session_hash <> ? AND revoked_at IS NULL'
            );
            $revokeSessions->execute([$userId, hash('sha256', session_id())]);

            $pdo->commit();

            // The credential hash is also the existing session-version value.
            // Update it before regenerating the session so the current member remains signed in.
            $_SESSION['credential_version'] = hash('sha256', $newHash);
            $_SESSION['authenticated_at'] = time();
            $_SESSION['last_activity'] = time();
            session_regenerate_id(true);

            record_audit($pdo, $userId, 'password_change', 'Member password changed successfully; existing authenticated sessions using the previous credential version are invalidated.', 'success');
            $message = 'Your password was changed successfully. Other sessions using your previous password version have been invalidated.';
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('PASCCO member password change failed: ' . $exception->getMessage());
            $error = $exception->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-settings-phase6.css?v=1">
    <title>Change Password | PASCCO</title>
    <style>
        body { margin: 0; background: #f4f7fb; color: #182a45; font-family: Georgia, 'Times New Roman', serif; }
        .password-page { max-width: 760px; margin: 0 auto; padding: 42px 22px 70px; }
        .heading { margin-bottom: 24px; }
        .eyebrow { color: #9b7416; font: 700 12px/1.4 Arial, sans-serif; letter-spacing: .12em; text-transform: uppercase; }
        h1 { color: #071d49; margin: 8px 0; font-size: clamp(28px, 4vw, 38px); }
        .intro { color: #617187; line-height: 1.6; max-width: 680px; margin: 0; }
        .card { background: #fff; border: 1px solid #d8e0ee; border-top: 4px solid #1456a0; border-radius: 10px; padding: 26px; box-shadow: 0 5px 18px rgba(7,29,73,.04); }
        label { display: block; color: #071d49; font: 700 14px/1.4 Arial, sans-serif; margin: 15px 0 7px; }
        input { width: 100%; box-sizing: border-box; border: 1px solid #b8c8d9; border-radius: 6px; padding: 12px 13px; font: 15px Arial, sans-serif; }
        input:focus { border-color: #1456a0; outline: 3px solid rgba(20,86,160,.13); }
        button { width: 100%; margin-top: 20px; border: 0; border-radius: 6px; padding: 12px 16px; background: #1456a0; color: #fff; font: 700 15px Arial, sans-serif; cursor: pointer; }
        button:hover { background: #0d4380; }
        .notice, .error { margin-bottom: 18px; padding: 12px 14px; border-radius: 6px; font: 14px/1.5 Arial, sans-serif; }
        .notice { background: #eef8f1; border-left: 4px solid #2f855a; color: #22543d; }
        .error { background: #fff0f0; border-left: 4px solid #dc3545; color: #721c24; }
        .rules { margin: 18px 0 0; padding: 15px 17px; border-radius: 8px; background: #f6f8fb; color: #5d6d81; font: 13px/1.6 Arial, sans-serif; }
        .rules strong { color: #25364e; }
        .rules ul { margin: 7px 0 0 18px; padding: 0; }
        .back { margin-top: 18px; text-align: center; font: 13px Arial, sans-serif; }
        .back a { color: #1456a0; font-weight: 700; text-decoration: none; }
        @media (max-width: 700px) { .password-page { padding: 28px 16px 50px; } .card { padding: 20px; } }
    </style>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/member-panels.css?v=2">
</head>
<body>
<?php pascco_member_header('Change Password'); ?>
<main class="pascco-settings-reveal password-page member-content">
    <section class="heading">
        <div class="eyebrow">Settings / Security</div>
        <h1>Change Password</h1>
        <p class="intro">Change the password used to sign in to your PASCCO member account. Your current password is required before a new one can be saved.</p>
    </section>

    <?php if ($message): ?><div class="notice" role="status"><?php echo password_page_escape($message); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="error" role="alert"><?php echo password_page_escape($error); ?></div><?php endif; ?>

    <section class="card pascco-settings-stagger">
        <form class="pascco-settings-form" method="POST" action="change_password.php" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?php echo password_page_escape($_SESSION['csrf_token']); ?>">

            <label for="current-password">Current Password</label>
            <input id="current-password" type="password" name="current_password" autocomplete="current-password" required>

            <label for="new-password">New Password</label>
            <input id="new-password" type="password" name="new_password" minlength="12" maxlength="128" autocomplete="new-password" required>

            <label for="confirm-password">Confirm New Password</label>
            <input id="confirm-password" type="password" name="confirm_password" minlength="12" maxlength="128" autocomplete="new-password" required>

            <div class="rules">
                <strong>Password requirements</strong>
                <ul>
                    <li>At least 12 characters.</li>
                    <li>No more than 128 characters.</li>
                    <li>Use a password that is different from your current password.</li>
                    <li>Long passphrases are allowed.</li>
                </ul>
            </div>

            <button type="submit">Change Password</button>
        </form>
        <div class="back"><a href="settings.php">Back to Settings</a></div>
    </section>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
