<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') { header("Location: /paco_cooperative/public/login.php"); exit; }

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';
$idempotency_key = bin2hex(random_bytes(32));

$account_stmt = $pdo->prepare("SELECT m.id AS member_id,m.first_name,m.last_name,m.member_number,a.id AS account_id,a.account_number,a.account_type,a.balance FROM members m JOIN accounts a ON m.id=a.member_id WHERE m.user_id=? AND a.status='active' ORDER BY a.id");
$account_stmt->execute([$user_id]);
$accounts = $account_stmt->fetchAll();

$selected_account_id = (int)($_POST['account_id'] ?? $_GET['account_id'] ?? ($accounts[0]['account_id'] ?? 0));
$account = null;

foreach ($accounts as $available_account) {
    if ((int)$available_account['account_id'] === $selected_account_id) {
        $account = $available_account;
        break;
    }
}

if (!$account && $accounts) {
    $account = $accounts[0];
    $selected_account_id = (int)$account['account_id'];
}

$active_loans = [];
$member_announcements = [];

$member_announcement_stmt = $pdo->query("SELECT id, title, body, image_path, published_at FROM announcements WHERE status = 'published' AND audience IN ('members', 'both') ORDER BY published_at DESC, id DESC LIMIT 5");
$member_announcements = $member_announcement_stmt->fetchAll();

if ($account) {
    $loan_stmt = $pdo->prepare("SELECT l.*, (SELECT COUNT(*) FROM loan_payments lp WHERE lp.loan_id = l.id) AS schedule_count, (SELECT MIN(lp.due_date) FROM loan_payments lp WHERE lp.loan_id = l.id AND lp.amount_paid < lp.amount_due AND lp.status <> 'waived') AS next_due_date FROM loans l WHERE l.member_id=? AND l.status IN ('approved','disbursed','active') AND l.remaining_balance>0");
    $loan_stmt->execute([$account['member_id']]);
    $active_loans = $loan_stmt->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'withdraw') {
    verify_csrf();

    $idempotency_key = trim((string) ($_POST['idempotency_key'] ?? ''));
    $raw_amount = trim((string) ($_POST['amount'] ?? ''));
    $amount_cents = pascco_money_input_to_cents($raw_amount);
    $amount = $amount_cents === null ? '0.00' : pascco_money_from_cents($amount_cents);
    $posted_account_id = (int) ($_POST['account_id'] ?? 0);
    $description = trim((string) ($_POST['description'] ?? ''));
    $custom_description = trim((string) ($_POST['custom_description'] ?? ''));
    $description_options = ['Counter Withdrawal', 'Other'];
    $desc = $description === 'Other' ? $custom_description : $description;

    if (!preg_match('/^[a-f0-9]{64}$/', $idempotency_key)) {
        $error = 'This withdrawal form is no longer valid. Please reload the page and try again.';
    } elseif (!$account || $posted_account_id !== (int) $account['account_id']) {
        $error = 'Please select a valid savings account.';
    } elseif ($amount_cents === null || $amount_cents <= 0) {
        $error = 'Enter a valid withdrawal amount with no more than two decimal places.';
    } elseif (!in_array($description, $description_options, true)) {
        $error = 'Please select a valid withdrawal description.';
    } elseif ($description === 'Other' && $custom_description === '') {
        $error = 'Please enter a description for the withdrawal.';
    } elseif (strlen($desc) > 255) {
        $error = 'The withdrawal description is too long.';
    } else {
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare("SELECT a.balance FROM accounts a JOIN members m ON m.id=a.member_id WHERE a.id=? AND m.user_id=? AND a.status='active' FOR UPDATE");
            $lock->execute([$posted_account_id, (int) $user_id]);
            $locked_account = $lock->fetch();
            if (!$locked_account) {
                throw new PasccoUserException('The selected savings account is no longer available.');
            }
            if ($amount_cents > pascco_money_to_cents((string) $locked_account['balance'])) {
                throw new PasccoUserException('The requested amount is greater than the current available balance.');
            }

            $existing = $pdo->prepare('SELECT id, status FROM withdrawal_requests WHERE idempotency_key = ? LIMIT 1 FOR UPDATE');
            $existing->execute([$idempotency_key]);
            $existing_request = $existing->fetch();
            if ($existing_request) {
                throw new PasccoUserException('This withdrawal request has already been submitted. Check your withdrawal requests before trying again.');
            }

            $member_stmt = $pdo->prepare('SELECT id FROM members WHERE user_id = ? LIMIT 1');
            $member_stmt->execute([(int) $user_id]);
            $member_id = (int) $member_stmt->fetchColumn();
            if ($member_id <= 0) {
                throw new PasccoUserException('Your member profile could not be verified.');
            }

            $insert = $pdo->prepare("INSERT INTO withdrawal_requests (account_id, member_id, amount, description, status, idempotency_key, created_at) VALUES (?, ?, ?, ?, 'pending', ?, NOW())");
            $insert->execute([$posted_account_id, $member_id, number_format($amount, 2, '.', ''), $desc, $idempotency_key]);
            $request_id = (int) $pdo->lastInsertId();
            $pdo->commit();

            record_audit($pdo, (int) $user_id, 'withdrawal_request', 'Submitted withdrawal request #' . $request_id, 'success');
            $message = 'Withdrawal request submitted for admin review. Your balance has not been deducted.';
            $idempotency_key = bin2hex(random_bytes(32));
        } catch (PasccoUserException $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $exception->getMessage();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            pascco_log_exception($exception, 'member_withdrawal_request');
            $error = 'We could not submit your withdrawal request. Please try again later.';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'repay_loan') {
    verify_csrf();

    $idempotency_key = trim($_POST['idempotency_key'] ?? '');
    if (!preg_match('/^[a-f0-9]{64}$/', $idempotency_key)) {
        $error = 'This loan payment form is no longer valid. Please reload the page and try again.';
    }

    $loan_id = (int) ($_POST['loan_id'] ?? 0);
    $raw_repay_amount = (string) ($_POST['repay_amount'] ?? '');
    $repay_amount_cents = pascco_money_input_to_cents($raw_repay_amount);
    $amount = $repay_amount_cents === null ? '0.00' : pascco_money_from_cents($repay_amount_cents);

    $l_check = $pdo->prepare("SELECT * FROM loans WHERE id=? AND member_id=?");
    $l_check->execute([$loan_id,$account['member_id']]);
    $selected_loan = $l_check->fetch();

    if ($error !== '') {
        // Idempotency validation already assigned an error.
    } elseif (!$selected_loan) {
        $error = "Invalid loan selected.";
    } elseif ($repay_amount_cents === null || $repay_amount_cents <= 0) {
        $error = "Enter a valid repayment amount with no more than two decimal places.";
    } elseif ($repay_amount_cents > pascco_money_to_cents((string) $account['balance'])) {
        $error = "Insufficient savings balance to cover this repayment!";
    } elseif ($repay_amount_cents > pascco_money_to_cents((string) $selected_loan['remaining_balance'])) {
        $error = "Payment amount exceeds the remaining loan balance of ₱" . number_format($selected_loan['remaining_balance'],2);
    } else {
        try {
            $pdo->beginTransaction();

            $lock_account = $pdo->prepare("SELECT a.balance FROM accounts a JOIN members m ON m.id=a.member_id WHERE a.id=? AND m.user_id=? AND a.status='active' FOR UPDATE");
            $lock_account->execute([(int)$account['account_id'], (int)$user_id]);
            $locked_account = $lock_account->fetch();

            $lock_loan = $pdo->prepare("SELECT remaining_balance FROM loans WHERE id=? AND member_id=? AND status IN ('approved','disbursed','active') FOR UPDATE");
            $lock_loan->execute([$loan_id,$account['member_id']]);
            $locked_loan = $lock_loan->fetch();

            if (!$locked_account || !$locked_loan || $repay_amount_cents > pascco_money_to_cents((string) $locked_account['balance']) || $repay_amount_cents > pascco_money_to_cents((string) $locked_loan['remaining_balance'])) {
                throw new PasccoUserException('The balance or loan amount changed. Please review the payment and try again.');
            }

            $existing = $pdo->prepare('SELECT reference_number FROM transactions WHERE idempotency_key = ? LIMIT 1');
            $existing->execute([$idempotency_key]);
            $existing_ref = $existing->fetchColumn();
            if ($existing_ref) {
                throw new PasccoUserException('This loan payment was already processed. Reference: ' . $existing_ref);
            }

            $ref_number = 'OR-' . date('YmdHis') . '-' . random_int(100000,999999);

            $tx = $pdo->prepare("INSERT INTO transactions (account_id,transaction_type,amount,recipient_account_id,description,status,reference_number,transaction_date,created_at,idempotency_key) VALUES (?,'withdrawal',?,NULL,'Loan Payment','completed',?,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),?)");
            $tx->execute([$account['account_id'],$amount,$ref_number,$idempotency_key]);

            $balance_update = $pdo->prepare("UPDATE accounts a JOIN members m ON m.id=a.member_id SET a.balance=a.balance-? WHERE a.id=? AND m.user_id=? AND a.status='active'");
            $balance_update->execute([$amount,(int)$account['account_id'],(int)$user_id]);
            if ($balance_update->rowCount() !== 1) {
                throw new PasccoUserException('The savings balance could not be updated. The loan payment was not finalized.');
            }

            pascco_apply_loan_payment($pdo, $loan_id, $amount, $ref_number, (int) $user_id);

            $loan_state = $pdo->prepare("SELECT l.remaining_balance, l.status FROM loans l JOIN members m ON m.id=l.member_id WHERE l.id=? AND m.user_id=? FOR UPDATE");
            $loan_state->execute([$loan_id, (int)$user_id]);
            $loan_after_payment = $loan_state->fetch();
            if (!$loan_after_payment) {
                throw new PasccoUserException('The loan could not be refreshed after payment.');
            }

            $pdo->commit();

            $message = "Loan payment of ₱" . number_format($repay_amount_cents / 100,2) . " successful!";

            $account_stmt->execute([$user_id]);
            $accounts = $account_stmt->fetchAll();

            foreach ($accounts as $available_account) {
                if ((int)$available_account['account_id'] === $selected_account_id) {
                    $account = $available_account;
                    break;
                }
            }

            $loan_stmt->execute([$account['member_id']]);
            $active_loans = $loan_stmt->fetchAll();
        } catch (PasccoUserException $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $exception->getMessage();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            pascco_log_exception($exception, 'member_loan_repayment');
            $error = 'We could not complete the loan payment. Please try again later.';
        }
    }
}

$total_savings_cents = 0;
foreach ($accounts as $available_account) {
    $total_savings_cents += pascco_money_to_cents((string) $available_account['balance']);
}
$total_savings = pascco_money_from_cents($total_savings_cents);

$total_loan_balance_cents = 0;
$next_loan_due = null;
foreach ($active_loans as $loan_summary) {
    $total_loan_balance_cents += pascco_money_to_cents((string) $loan_summary['remaining_balance']);
    if (!empty($loan_summary['next_due_date']) && ($next_loan_due === null || $loan_summary['next_due_date'] < $next_loan_due)) {
        $next_loan_due = $loan_summary['next_due_date'];
    }
}
$total_loan_balance = pascco_money_from_cents($total_loan_balance_cents);

$transactions = [];

if ($account) {
    $tx_stmt = $pdo->prepare("SELECT transaction_type,amount,description,reference_number,created_at FROM transactions WHERE account_id=? ORDER BY id DESC LIMIT 5");
    $tx_stmt->execute([$account['account_id']]);
    $transactions = $tx_stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Member Dashboard | PASCCO</title>
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="/paco_cooperative/assets/css/member-panels.css?v=2">
    <link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-member-dashboard-phase2.css?v=1">
</head>

<body>

<?php pascco_member_header('Member Dashboard'); ?>

<main class="member-content pascco-financial-page">

<?php if ($account): ?>

    <section class="dashboard-welcome pascco-dashboard-reveal">
        <div class="dashboard-welcome-text">
            <span class="dashboard-eyebrow">MEMBER DASHBOARD</span>
            <h1>Welcome, <?php echo htmlspecialchars($account['first_name'],ENT_QUOTES,'UTF-8'); ?>!</h1>
            <p>Member No. <?php echo htmlspecialchars($account['member_number'],ENT_QUOTES,'UTF-8'); ?></p>
        </div>

        <div class="dashboard-actions">
            <a href="/paco_cooperative/member/apply_loan.php" class="dashboard-action primary pascco-press"><i class="bx bx-money"></i>Apply for Loan</a>
            <a href="/paco_cooperative/member/deposit.php" class="dashboard-action pascco-press"><i class="bx bx-wallet"></i>Deposit Money</a>
            <a href="/paco_cooperative/member/transfer.php" class="dashboard-action pascco-press"><i class="bx bx-transfer"></i>Send Money</a>
        </div>
    </section>

    <section class="dashboard-stat-grid pascco-dashboard-reveal" aria-label="Financial summary">
        <article class="dashboard-stat-card pascco-dashboard-stagger">
            <div class="dashboard-stat-icon blue"><i class="bx bx-wallet"></i></div>
            <div class="dashboard-stat-copy">
                <span>Total Savings</span>
                <strong class="pascco-count-up" data-value="<?php echo htmlspecialchars(pascco_money_from_cents($total_savings_cents), ENT_QUOTES, "UTF-8"); ?>" data-prefix="₱">₱<?php echo pascco_money_display($total_savings); ?></strong>
                <small><?php echo count($accounts); ?> active account<?php echo count($accounts) === 1 ? '' : 's'; ?></small>
            </div>
        </article>

        <article class="dashboard-stat-card pascco-dashboard-stagger">
            <div class="dashboard-stat-icon gold"><i class="bx bx-credit-card"></i></div>
            <div class="dashboard-stat-copy">
                <span>Loan Balance</span>
                <strong class="pascco-count-up" data-value="<?php echo htmlspecialchars(pascco_money_from_cents($total_loan_balance_cents), ENT_QUOTES, "UTF-8"); ?>" data-prefix="₱">₱<?php echo pascco_money_display($total_loan_balance); ?></strong>
                <small><?php echo count($active_loans); ?> active loan<?php echo count($active_loans) === 1 ? '' : 's'; ?></small>
            </div>
        </article>

        <article class="dashboard-stat-card pascco-dashboard-stagger">
            <div class="dashboard-stat-icon slate"><i class="bx bx-calendar-check"></i></div>
            <div class="dashboard-stat-copy">
                <span>Next Loan Due</span>
                <strong><?php echo $next_loan_due ? date('M d, Y', strtotime($next_loan_due)) : 'No payment'; ?></strong>
                <small><?php echo $next_loan_due ? 'Scheduled repayment date' : 'No active repayment schedule'; ?></small>
            </div>
        </article>
    </section>

    <?php if ($message): ?>
        <div class="dashboard-alert success pascco-dashboard-reveal"><i class="bx bx-check-circle"></i><span><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></span></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="dashboard-alert danger pascco-dashboard-reveal"><i class="bx bx-error-circle"></i><span><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></span></div>
    <?php endif; ?>

    <section class="dashboard-top-grid pascco-dashboard-reveal">

        <article class="dashboard-balance-panel pascco-dashboard-stagger">
            <div class="panel-label"><i class="bx bx-wallet"></i>Available Balance</div>
            <div class="dashboard-balance pascco-count-up" data-value="<?php echo htmlspecialchars(number_format((float)$account['balance'], 2, ".", ""), ENT_QUOTES, "UTF-8"); ?>" data-prefix="₱">₱<?php echo number_format($account['balance'],2); ?></div>
            <div class="balance-account"><?php echo htmlspecialchars($account['account_type'],ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars($account['account_number'],ENT_QUOTES,'UTF-8'); ?></div>
            <a href="/paco_cooperative/member/member_savings.php?account_id=<?php echo (int)$account['account_id']; ?>" class="panel-link">View account history <i class="bx bx-right-arrow-alt"></i></a>
        </article>

        <article class="dashboard-info-panel pascco-dashboard-stagger">
            <div class="panel-heading">
                <div><span class="panel-eyebrow">YOUR ACCOUNT</span><h2>Account Overview</h2></div>
                <i class="bx bx-credit-card"></i>
            </div>
            <div class="account-mini-grid">
                <?php foreach ($accounts as $available_account): ?>
                    <div class="account-mini-card pascco-dashboard-stagger">
                        <div class="account-mini-icon"><i class="bx bx-wallet"></i></div>
                        <div class="account-mini-details">
                            <span><?php echo htmlspecialchars($available_account['account_type'],ENT_QUOTES,'UTF-8'); ?></span>
                            <small><?php echo htmlspecialchars($available_account['account_number'],ENT_QUOTES,'UTF-8'); ?></small>
                            <strong>₱<?php echo number_format($available_account['balance'],2); ?></strong>
                        </div>
                        <a href="/paco_cooperative/member/member_savings.php?account_id=<?php echo (int)$available_account['account_id']; ?>" aria-label="View account history"><i class="bx bx-chevron-right"></i></a>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

    </section>

    <?php if ($member_announcements): ?>
        <section class="dashboard-panel member-announcements-panel pascco-dashboard-reveal">
            <div class="panel-heading">
                <div><span class="panel-eyebrow">PASCCO UPDATES</span><h2>Announcements</h2><p>Important cooperative updates shared with members.</p></div>
                <div class="panel-heading-icon"><i class="bx bx-bell"></i></div>
            </div>
            <div class="member-announcement-list">
                <?php foreach ($member_announcements as $announcement): ?>
                    <article class="member-announcement-item pascco-dashboard-stagger">
                        <?php if (!empty($announcement['image_path'])): ?>
                            <img src="<?php echo htmlspecialchars($announcement['image_path'], ENT_QUOTES, 'UTF-8'); ?>" alt="Announcement image">
                        <?php endif; ?>
                        <div class="member-announcement-copy">
                            <time datetime="<?php echo htmlspecialchars(date('c', strtotime($announcement['published_at'])), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(date('M d, Y', strtotime($announcement['published_at'])), ENT_QUOTES, 'UTF-8'); ?></time>
                            <h3><?php echo htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                            <p><?php echo nl2br(htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8')); ?></p>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    $withdrawal_history_stmt = $pdo->prepare("SELECT id, amount, description, status, admin_notes, created_at, reviewed_at FROM withdrawal_requests WHERE member_id = ? ORDER BY id DESC LIMIT 5");
    $withdrawal_history_stmt->execute([(int) ($account['member_id'] ?? 0)]);
    $withdrawal_history = $account ? $withdrawal_history_stmt->fetchAll() : [];
    ?>
    <?php if ($withdrawal_history): ?>
    <section class="dashboard-panel pascco-dashboard-reveal" style="margin-bottom:20px;">
        <div class="panel-heading"><div><span class="panel-eyebrow">REQUEST TRACKING</span><h2>Recent Withdrawal Requests</h2><p>Requests remain pending until reviewed by the administrator.</p></div><div class="panel-heading-icon"><i class="bx bx-time-five"></i></div></div>
        <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;min-width:520px;"><thead><tr><th style="text-align:left;padding:12px;">Date</th><th style="text-align:left;padding:12px;">Description</th><th style="text-align:right;padding:12px;">Amount</th><th style="text-align:left;padding:12px;">Status</th></tr></thead><tbody>
        <?php foreach ($withdrawal_history as $request): ?><tr><td style="padding:12px;border-top:1px solid #e4ebf3;"><?php echo htmlspecialchars((string)$request['created_at'], ENT_QUOTES, 'UTF-8'); ?></td><td style="padding:12px;border-top:1px solid #e4ebf3;"><?php echo htmlspecialchars((string)$request['description'], ENT_QUOTES, 'UTF-8'); ?><?php if (!empty($request['admin_notes'])): ?><div style="font-size:.78rem;color:#68798d;margin-top:4px;">Admin note: <?php echo htmlspecialchars((string)$request['admin_notes'], ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?></td><td style="text-align:right;padding:12px;border-top:1px solid #e4ebf3;white-space:nowrap;">₱<?php echo number_format((float)$request['amount'], 2); ?></td><td style="padding:12px;border-top:1px solid #e4ebf3;"><strong><?php echo htmlspecialchars(strtoupper((string)$request['status']), ENT_QUOTES, 'UTF-8'); ?></strong></td></tr><?php endforeach; ?>
        </tbody></table></div>
    </section>
    <?php endif; ?>

    <section class="dashboard-panel quick-transaction-panel pascco-dashboard-reveal">
        <div class="panel-heading">
            <div><span class="panel-eyebrow">MONEY MANAGEMENT</span><h2>Quick Withdrawal</h2><p>Submit a withdrawal request from your active savings account. The admin reviews it before funds are deducted. Deposits use the secure deposit request process.</p></div>
            <div class="panel-heading-icon"><i class="bx bx-wallet"></i></div>
        </div>

        <div class="dashboard-form" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;align-items:end;">
            <div class="form-field">
                <label for="withdraw_account_id">Savings Account</label>
                <select id="withdraw_account_id" name="account_id" form="withdrawal-form" required>
                    <?php foreach ($accounts as $available_account): ?>
                        <option value="<?php echo (int) $available_account['account_id']; ?>" <?php echo (int) $available_account['account_id'] === $selected_account_id ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($available_account['account_type'].' - '.$available_account['account_number'].' (Balance: PHP '.number_format($available_account['balance'],2).')',ENT_QUOTES,'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-field">
                <label for="withdraw_amount">Amount</label>
                <input id="withdraw_amount" type="number" step="0.01" min="0.01" name="amount" form="withdrawal-form" placeholder="₱0.00" required>
            </div>

            <div class="form-field">
                <label for="withdraw_description">Description</label>
                <select id="withdraw_description" name="description" form="withdrawal-form" required>
                    <option value="">Select description</option>
                    <option value="Counter Withdrawal">Counter Withdrawal</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-field">
                <label for="withdraw_custom_description">Additional Description</label>
                <input id="withdraw_custom_description" type="text" name="custom_description" form="withdrawal-form" placeholder="If Other, enter description">
            </div>

            <div class="form-submit" style="grid-column:1/-1;">
                <form id="withdrawal-form" method="POST" action="/paco_cooperative/member/dashboard.php" class="pascco-financial-form">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>">
                    <input type="hidden" name="action" value="withdraw">
                    <input type="hidden" name="idempotency_key" value="<?php echo htmlspecialchars($idempotency_key, ENT_QUOTES, 'UTF-8'); ?>">
                    <button type="submit"><i class="bx bx-download"></i><span class="pascco-submit-label" data-processing="Processing…">Submit Withdrawal Request</span></button>
                </form>
                <a href="/paco_cooperative/member/deposit.php" class="dashboard-action primary pascco-press" style="margin-left:8px;"><i class="bx bx-wallet"></i>Submit Deposit Request</a>
            </div>
        </div>
    </section>

    <section class="dashboard-content-grid pascco-dashboard-reveal">

        <?php if (count($active_loans) > 0): ?>
            <article class="dashboard-panel loan-panel pascco-dashboard-stagger">
                <div class="panel-heading">
                    <div><span class="panel-eyebrow">LOAN MANAGEMENT</span><h2>Active Loans</h2></div>
                    <div class="panel-heading-icon loan"><i class="bx bx-money"></i></div>
                </div>

                <div class="loan-list">
                    <?php foreach ($active_loans as $ln): ?>
                        <div class="loan-item pascco-dashboard-stagger">
                            <div class="loan-item-header">
                                <div>
                                    <span class="loan-label">LOAN NUMBER</span>
                                    <strong><?php echo htmlspecialchars($ln['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong>
                                    <a href="/paco_cooperative/member/loan_details.php?loan_id=<?php echo (int)$ln['id']; ?>" class="loan-details-link">View schedule &amp; history</a>
                                </div>
                                <span class="loan-status">ACTIVE</span>
                            </div>

                            <div class="loan-details">
                                <div><span>Original Amount</span><strong>₱<?php echo number_format($ln['loan_amount'],2); ?></strong></div>
                                <div><span>Remaining Balance</span><strong>₱<?php echo number_format($ln['remaining_balance'],2); ?></strong></div>
                            </div>

                            <?php if ((int)$ln['schedule_count'] > 0): $loan_form_key = bin2hex(random_bytes(32)); ?>
                                <form method="POST" action="/paco_cooperative/member/dashboard.php" class="loan-repayment-form pascco-financial-form">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>">
                                    <input type="hidden" name="action" value="repay_loan">
                                    <input type="hidden" name="loan_id" value="<?php echo (int)$ln['id']; ?>">
                                    <input type="hidden" name="idempotency_key" value="<?php echo htmlspecialchars($loan_form_key, ENT_QUOTES, 'UTF-8'); ?>">
                                    <input type="number" step="0.01" min="0.01" name="repay_amount" placeholder="Repayment Amount (₱)" required>
                                    <button type="submit" class="pascco-press"><i class="bx bx-credit-card"></i><span class="pascco-submit-label" data-processing="Processing…">Make Repayment</span></button>
                                </form>
                            <?php else: ?>
                                <div class="loan-schedule-notice">This older loan does not have a repayment schedule yet. Please contact PASCCO administration before making a payment.</div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </article>
        <?php endif; ?>

        <article class="dashboard-panel transactions-panel pascco-dashboard-stagger <?php echo count($active_loans) === 0 ? 'full-width' : ''; ?>">
            <div class="panel-heading">
                <div><span class="panel-eyebrow">ACCOUNT ACTIVITY</span><h2>Recent Transactions</h2></div>
                <div class="panel-heading-icon"><i class="bx bx-history"></i></div>
            </div>

            <?php if (count($transactions) > 0): ?>
                <div class="transaction-table-wrap">
                    <table class="transaction-table">
                        <thead>
                            <tr><th>Reference</th><th>Type</th><th>Amount</th><th>Description</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $tx): ?>
                                <tr class="pascco-transaction-row">
                                    <td><span class="transaction-reference"><?php echo htmlspecialchars($tx['reference_number'],ENT_QUOTES,'UTF-8'); ?></span></td>
                                    <td><span class="transaction-type <?php echo htmlspecialchars($tx['transaction_type'],ENT_QUOTES,'UTF-8'); ?>"><?php echo strtoupper(htmlspecialchars($tx['transaction_type'],ENT_QUOTES,'UTF-8')); ?></span></td>
                                    <td class="transaction-amount">₱<?php echo number_format($tx['amount'],2); ?></td>
                                    <td><?php echo htmlspecialchars($tx['description'],ENT_QUOTES,'UTF-8'); ?></td>
                                    <td><?php echo date('M d, Y H:i',$tx['created_at']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state"><i class="bx bx-receipt"></i><strong>No transactions yet</strong><span>Your recent account activity will appear here.</span></div>
            <?php endif; ?>
        </article>

    </section>

<?php else: ?>

    <section class="dashboard-panel empty-dashboard">
        <div class="empty-state">
            <i class="bx bx-user-x"></i>
            <h2>Member Account Not Found</h2>
            <p>We could not find an active savings account associated with your account.</p>
        </div>
    </section>

<?php endif; ?>

</main>

<?php pascco_global_footer(); ?>
<script src="/paco_cooperative/assets/js/pascco-member-dashboard-phase2.js?v=1"></script>

</body>
</html>