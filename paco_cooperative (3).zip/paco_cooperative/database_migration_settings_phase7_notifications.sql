-- PASCCO Settings Phase 7 - Notification Preferences
-- Import once into the existing paco_cooperative database.
-- Safe to re-run: CREATE TABLE IF NOT EXISTS and INSERT IGNORE are used.

CREATE TABLE IF NOT EXISTS member_notification_preferences (
    user_id INT UNSIGNED NOT NULL,
    loan_payment_reminders TINYINT(1) NOT NULL DEFAULT 1,
    announcements TINYINT(1) NOT NULL DEFAULT 1,
    general_updates TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_member_notification_preferences_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO member_notification_preferences (user_id)
SELECT id FROM users;
