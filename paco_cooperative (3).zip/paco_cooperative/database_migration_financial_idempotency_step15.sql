-- PASCCO Step 15 - Financial Action Idempotency
-- Prevents repeated browser submissions from creating duplicate financial effects.
-- Run this AFTER Step 14 and after taking a database backup.

START TRANSACTION;

ALTER TABLE transactions
    ADD COLUMN IF NOT EXISTS idempotency_key CHAR(64) NULL;

ALTER TABLE deposit_requests
    ADD COLUMN IF NOT EXISTS idempotency_key CHAR(64) NULL;

ALTER TABLE loan_payment_receipts
    ADD COLUMN IF NOT EXISTS idempotency_key CHAR(64) NULL;

SET @idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'transactions' AND INDEX_NAME = 'uq_transactions_idempotency_key'
);
SET @sql := IF(@idx_exists = 0,
    'ALTER TABLE transactions ADD UNIQUE KEY uq_transactions_idempotency_key (idempotency_key)',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'deposit_requests' AND INDEX_NAME = 'uq_deposit_requests_idempotency_key'
);
SET @sql := IF(@idx_exists = 0,
    'ALTER TABLE deposit_requests ADD UNIQUE KEY uq_deposit_requests_idempotency_key (idempotency_key)',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_payment_receipts' AND INDEX_NAME = 'uq_loan_receipts_idempotency_key'
);
SET @sql := IF(@idx_exists = 0,
    'ALTER TABLE loan_payment_receipts ADD UNIQUE KEY uq_loan_receipts_idempotency_key (idempotency_key)',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

COMMIT;
