-- PASCCO Loan System - Step 1
-- Adds configurable loan products, loan brackets, and payment schedules.
-- Safe design: existing loans and existing loan_product text are preserved.
-- Run this AFTER backing up the database.

START TRANSACTION;

CREATE TABLE IF NOT EXISTS loan_products (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(120) NOT NULL,
    description VARCHAR(500) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_products_name (name),
    KEY idx_loan_products_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS loan_brackets (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_product_id INT UNSIGNED NOT NULL,
    bracket_name VARCHAR(80) NOT NULL,
    minimum_amount DECIMAL(15,2) NOT NULL,
    maximum_amount DECIMAL(15,2) NOT NULL,
    minimum_income DECIMAL(15,2) DEFAULT NULL,
    maximum_income DECIMAL(15,2) DEFAULT NULL,
    term_months INT UNSIGNED NOT NULL,
    interest_rate DECIMAL(7,4) NOT NULL DEFAULT 0.0000,
    interest_method ENUM('flat','reducing_balance') NOT NULL DEFAULT 'flat',
    required_savings DECIMAL(15,2) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_bracket_name (loan_product_id, bracket_name),
    KEY idx_loan_brackets_product_status (loan_product_id, status),
    CONSTRAINT fk_loan_brackets_product
        FOREIGN KEY (loan_product_id) REFERENCES loan_products(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_loan_bracket_amounts CHECK (minimum_amount > 0 AND maximum_amount >= minimum_amount),
    CONSTRAINT chk_loan_bracket_term CHECK (term_months > 0),
    CONSTRAINT chk_loan_bracket_interest CHECK (interest_rate >= 0),
    CONSTRAINT chk_loan_bracket_income CHECK (
        maximum_income IS NULL OR minimum_income IS NULL OR maximum_income >= minimum_income
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Keep the old loan_product text column for backward compatibility, while storing
-- the exact product/bracket used by a new application.
ALTER TABLE loans
    ADD COLUMN IF NOT EXISTS loan_product_id INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS loan_bracket_id INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS interest_rate DECIMAL(7,4) NULL,
    ADD COLUMN IF NOT EXISTS interest_amount DECIMAL(15,2) NULL,
    ADD COLUMN IF NOT EXISTS total_payable DECIMAL(15,2) NULL,
    ADD COLUMN IF NOT EXISTS monthly_payment DECIMAL(15,2) NULL,
    ADD COLUMN IF NOT EXISTS approval_date DATETIME NULL,
    ADD COLUMN IF NOT EXISTS approved_by INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS rejection_reason VARCHAR(500) NULL,
    ADD COLUMN IF NOT EXISTS disbursement_date DATETIME NULL,
    ADD COLUMN IF NOT EXISTS maturity_date DATE NULL;

ALTER TABLE loans
    MODIFY COLUMN status ENUM('pending','under_review','approved','disbursed','active','rejected','paid') NOT NULL DEFAULT 'pending';

SET @loan_product_fk_exists := (
    SELECT COUNT(*)
    FROM information_schema.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND TABLE_NAME = 'loans'
      AND CONSTRAINT_NAME = 'fk_loans_product'
      AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(
    @loan_product_fk_exists = 0,
    'ALTER TABLE loans ADD CONSTRAINT fk_loans_product FOREIGN KEY (loan_product_id) REFERENCES loan_products(id) ON UPDATE CASCADE ON DELETE RESTRICT',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @loan_bracket_fk_exists := (
    SELECT COUNT(*)
    FROM information_schema.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND TABLE_NAME = 'loans'
      AND CONSTRAINT_NAME = 'fk_loans_bracket'
      AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(
    @loan_bracket_fk_exists = 0,
    'ALTER TABLE loans ADD CONSTRAINT fk_loans_bracket FOREIGN KEY (loan_bracket_id) REFERENCES loan_brackets(id) ON UPDATE CASCADE ON DELETE RESTRICT',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @loan_approved_by_fk_exists := (
    SELECT COUNT(*)
    FROM information_schema.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND TABLE_NAME = 'loans'
      AND CONSTRAINT_NAME = 'fk_loans_approved_by'
      AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(
    @loan_approved_by_fk_exists = 0,
    'ALTER TABLE loans ADD CONSTRAINT fk_loans_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON UPDATE CASCADE ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @loan_product_idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loans' AND INDEX_NAME = 'idx_loans_product'
);
SET @sql := IF(
    @loan_product_idx_exists = 0,
    'ALTER TABLE loans ADD INDEX idx_loans_product (loan_product_id)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @loan_bracket_idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loans' AND INDEX_NAME = 'idx_loans_bracket'
);
SET @sql := IF(
    @loan_bracket_idx_exists = 0,
    'ALTER TABLE loans ADD INDEX idx_loans_bracket (loan_bracket_id)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS loan_payments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id INT(11) NOT NULL,
    payment_number INT UNSIGNED NOT NULL,
    due_date DATE NOT NULL,
    amount_due DECIMAL(15,2) NOT NULL,
    amount_paid DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    payment_date DATETIME DEFAULT NULL,
    status ENUM('scheduled','partial','paid','overdue','waived') NOT NULL DEFAULT 'scheduled',
    reference_number VARCHAR(60) DEFAULT NULL,
    notes VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_payment_number (loan_id, payment_number),
    UNIQUE KEY uq_loan_payment_reference (reference_number),
    KEY idx_loan_payments_due (loan_id, due_date, status),
    CONSTRAINT fk_loan_payments_loan
        FOREIGN KEY (loan_id) REFERENCES loans(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_loan_payment_amounts CHECK (amount_due > 0 AND amount_paid >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed only the product names already supported by the current application.
-- No financial bracket values are invented here; Step 2 will configure them.
INSERT INTO loan_products (name, status)
VALUES
('Business Loan','active'),
('Special Promo Loan','active'),
('Livelihood Loan','active'),
('Quick Loan - Productive','active'),
('Collateralized Loan','active'),
('Calamity Loan','active'),
('Educational / Tuition Loan','active'),
('Medical / Dental Loan','active'),
('Quick Loan - Providential','active'),
('Minor Home Improvement Loan','active'),
('Petty Cash Loan','active'),
('Multipurpose Loan','active'),
('Easyoperability Gadgets Loan','active'),
('Easyoperability BHK Loan','active'),
('Easyoperability Optical Loan','active'),
('Health & Wellness Loan','active'),
('Memorial Plan','active'),
('Personal Accident Insurance','active'),
('Manila North Green Park','active'),
('Special Loan','active')
ON DUPLICATE KEY UPDATE status = VALUES(status);

COMMIT;

-- IMPORTANT:
-- Do not fill loan brackets until the cooperative's actual rules are known.
-- Step 2 will add the approved amount ranges, income requirements, terms,
-- interest rates, and savings requirements for each loan product.
