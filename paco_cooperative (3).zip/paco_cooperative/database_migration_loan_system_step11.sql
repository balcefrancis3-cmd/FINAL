-- PASCCO Loan System Step 11
-- Controlled loan restructuring request and review workflow.
-- This migration does NOT modify loan balances, repayment schedules, interest, or status.

CREATE TABLE IF NOT EXISTS loan_restructuring_requests (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id INT UNSIGNED NOT NULL,
    requested_by INT UNSIGNED NOT NULL,
    reason VARCHAR(500) NOT NULL,
    proposed_term_months INT UNSIGNED NULL,
    proposed_monthly_payment DECIMAL(15,2) NULL,
    proposed_total_payable DECIMAL(15,2) NULL,
    proposed_effective_date DATE NULL,
    status ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    completed_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_restructure_loan_status (loan_id, status),
    KEY idx_restructure_status_date (status, submitted_at),
    CONSTRAINT fk_restructure_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE,
    CONSTRAINT fk_restructure_requested_by FOREIGN KEY (requested_by) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_restructure_completed_by FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS loan_restructuring_reviews (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    restructuring_request_id INT UNSIGNED NOT NULL,
    reviewer_id INT UNSIGNED NOT NULL,
    decision ENUM('approved','rejected') NOT NULL,
    notes VARCHAR(500) NULL,
    reviewed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_restructure_reviewer (restructuring_request_id, reviewer_id),
    KEY idx_restructure_reviews_request_decision (restructuring_request_id, decision),
    CONSTRAINT fk_restructure_review_request FOREIGN KEY (restructuring_request_id) REFERENCES loan_restructuring_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_restructure_review_user FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
