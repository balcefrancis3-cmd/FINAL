<?php
require_once __DIR__ . '/money.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/auth.php';
// Keep credentials outside htdocs. The setup utility writes this file here.
$configPath = getenv('PASCCO_CONFIG_PATH') ?: 'C:/xampp/pascco-private/config.php';
if (!is_file($configPath)) {
    error_log('PASCCO database unavailable: private configuration file is missing at ' . $configPath);
    http_response_code(503);
    exit('PASCCO setup is incomplete: the private database configuration is missing. Ask the local administrator to create C:/xampp/pascco-private/config.php using the documented security setup. No account or database data was changed.');
}
$pascco_config = require $configPath;
if (!is_array($pascco_config) || empty($pascco_config['db_password'])) {
    error_log('PASCCO database unavailable: private configuration is invalid or db_password is missing.');
    http_response_code(503);
    exit('PASCCO setup is incomplete: the private database configuration is invalid. Ask the local administrator to check C:/xampp/pascco-private/config.php.');
}
try {
    $pdo = new PDO(
        'mysql:host=127.0.0.1;dbname=paco_cooperative;charset=utf8mb4',
        'pascco_app',
        (string) $pascco_config['db_password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5
        ]
    );
} catch (PDOException $exception) {
    // Keep detailed diagnostics in the PHP error log, never in the browser.
    error_log('PASCCO database connection failed: [' . $exception->getCode() . '] ' . $exception->getMessage());
    http_response_code(503);
    exit('Database connection failed. Check that MySQL is running, database paco_cooperative exists, and the pascco_app account/password in C:/xampp/pascco-private/config.php match. See the PHP error log for the exact cause.');
}
if (isset($_SESSION['user_id'])) {
    $check = $pdo->prepare('SELECT u.password, u.status, u.role, m.secret FROM users u LEFT JOIN user_mfa m ON m.user_id = u.id WHERE u.id = ?');
    $check->execute([(int) $_SESSION['user_id']]);
    $currentUser = $check->fetch();

    $validSession = $currentUser
        && $currentUser['status'] === 'active'
        && $currentUser['role'] === ($_SESSION['role'] ?? '')
        && hash_equals(
            $_SESSION['credential_version'] ?? '',
            hash('sha256', $currentUser['password'])
        );

    if ($validSession && $currentUser['role'] === 'admin') {
        // Keep the existing administrator authenticator
        $validSession = !empty($currentUser['secret'])
            && !empty($_SESSION['mfa_verified'])
            && hash_equals(
                $_SESSION['mfa_version'] ?? '',
                hash('sha256', $currentUser['secret'])
            );
    } elseif ($validSession && $currentUser['role'] === 'member') {
        // Members always require email OTP; if authenticator MFA is enrolled, require it too.
        $validSession = !empty($_SESSION['email_otp_verified']);
        if ($validSession && !empty($currentUser['secret'])) {
            $mfaPendingEndpoint = basename(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '') === 'mfa_verify.php';
            $validSession = $mfaPendingEndpoint && !empty($_SESSION['member_mfa_pending'])
                ? true
                : (!empty($_SESSION['member_mfa_verified'])
                    && !empty($_SESSION['member_mfa_version'])
                    && hash_equals(
                        $_SESSION['member_mfa_version'],
                        hash('sha256', $currentUser['secret'])
                    ));
        }
    }

    if (!$validSession) {
        $_SESSION = [];
        session_regenerate_id(true);
        header('Location: /paco_cooperative/public/login.php');
        exit;
    }

    // Phase 5: enforce remote session revocation and register the current member session.
    // Only a SHA-256 hash of the PHP session ID is stored in the database.
    $sessionHash = hash('sha256', session_id());
    if (($currentUser['role'] ?? '') === 'member') {
        $sessionCheck = $pdo->prepare('SELECT revoked_at FROM user_sessions WHERE session_hash = ? AND user_id = ? LIMIT 1');
        $sessionCheck->execute([$sessionHash, (int) $_SESSION['user_id']]);
        $sessionRecord = $sessionCheck->fetch();
        if ($sessionRecord && !empty($sessionRecord['revoked_at'])) {
            $_SESSION = [];
            session_regenerate_id(true);
            header('Location: /paco_cooperative/public/login.php');
            exit;
        }

        $sessionUpsert = $pdo->prepare(
            'INSERT INTO user_sessions (user_id, session_hash, role, ip_address, user_agent)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE last_activity_at = NOW(), ip_address = VALUES(ip_address), user_agent = VALUES(user_agent)'
        );
        $sessionUpsert->execute([
            (int) $_SESSION['user_id'],
            $sessionHash,
            'member',
            substr((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45),
            substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown browser'), 0, 500)
        ]);
    }
}

// Generate CSRF token if one does not exist
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!class_exists('PasccoUserException')) {
    class PasccoUserException extends RuntimeException {}
}

// Helper function to verify CSRF token on POST requests
function require_admin(): void
{
    if (
        !isset($_SESSION['user_id'])
        || ($_SESSION['role'] ?? '') !== 'admin'
        || empty($_SESSION['mfa_verified'])
        || empty($_SESSION['mfa_version'])
    ) {
        http_response_code(403);
        exit('Forbidden. Administrator authentication is required.');
    }
}

function verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $submitted_token = (string) ($_POST['csrf_token'] ?? '');
        $session_token = (string) ($_SESSION['csrf_token'] ?? '');
        if ($session_token === '' || $submitted_token === '' || !hash_equals($session_token, $submitted_token)) {
            http_response_code(403);
            die("Security Error: Invalid or missing CSRF token. Request blocked.");
        }
    }
}



function pascco_log_exception(Throwable $exception, string $context): void
{
    error_log('[PASCCO][' . preg_replace('/[^a-zA-Z0-9_. -]/', '', $context) . '] ' . get_class($exception) . ': ' . $exception->getMessage());
}

function record_audit(PDO $pdo, ?int $user_id, string $action, string $description, string $status = 'success'): void
{
    try {
        $stmt = $pdo->prepare('INSERT INTO audit_logs (user_id, action, description, ip_address, status) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$user_id, $action, substr($description, 0, 255), $_SERVER['REMOTE_ADDR'] ?? 'unknown', $status]);
    } catch (Throwable $exception) {
        pascco_log_exception($exception, 'audit_log_write');
    }
}
?>
