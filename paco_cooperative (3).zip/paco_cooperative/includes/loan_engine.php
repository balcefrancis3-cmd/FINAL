<?php
/**
 * PASCCO loan calculation and servicing helpers.
 */
require_once __DIR__ . '/money.php';

function pascco_calculate_loan(string|int|float $principal, int $termMonths, float $annualOrTermRate, string $interestMethod, string $rateBasis = 'annual'): array
{
    $principalCents = pascco_money_to_cents($principal);
    if ($principalCents <= 0 || $termMonths <= 0 || !is_finite($annualOrTermRate) || $annualOrTermRate < 0) {
        throw new InvalidArgumentException('Invalid loan calculation values.');
    }

    $interestMethod = $interestMethod === 'reducing_balance' ? 'reducing_balance' : 'flat';
    $rateBasis = $rateBasis === 'term' ? 'term' : 'annual';
    if ($interestMethod === 'reducing_balance' && $rateBasis !== 'annual') {
        throw new InvalidArgumentException('Reducing-balance loans require an annual interest-rate basis.');
    }

    // Rates use floating point for exponentiation, but all monetary results are
    // immediately rounded to integer centavos and remain integer cents after that.
    if ($interestMethod === 'flat') {
        $rateMultiplier = $rateBasis === 'annual'
            ? ($annualOrTermRate / 100) * ($termMonths / 12)
            : ($annualOrTermRate / 100);
        $interestCents = (int) round($principalCents * $rateMultiplier, 0, PHP_ROUND_HALF_UP);
        $totalCents = $principalCents + $interestCents;
        $monthlyCents = pascco_money_round_divide($totalCents, $termMonths);
    } else {
        $monthlyRate = ($annualOrTermRate / 100) / 12;
        if ($monthlyRate == 0.0) {
            $monthlyCents = pascco_money_round_divide($principalCents, $termMonths);
        } else {
            $factor = pow(1 + $monthlyRate, $termMonths);
            $paymentCents = ($principalCents * ($monthlyRate * $factor) / ($factor - 1));
            $monthlyCents = (int) round($paymentCents, 0, PHP_ROUND_HALF_UP);
        }
        // Keep the principal fully repayable even when centavo rounding makes
        // monthlyPayment * term one centavo lower than principal. The schedule
        // adjusts the final installment to the exact configured total.
        $totalCents = max($principalCents, $monthlyCents * $termMonths);
        $interestCents = max(0, $totalCents - $principalCents);
    }

    return [
        'interest_amount' => pascco_money_from_cents($interestCents),
        'total_payable' => pascco_money_from_cents($totalCents),
        'monthly_payment' => pascco_money_from_cents($monthlyCents),
    ];
}

function pascco_generate_loan_payment_schedule(PDO $pdo, int $loanId, string $firstDueDate, int $termMonths, string|int|float $monthlyPayment, string|int|float $totalPayable): void
{
    $paymentCents = pascco_money_to_cents($monthlyPayment);
    $totalCents = pascco_money_to_cents($totalPayable);
    if ($loanId <= 0 || $termMonths <= 0 || $paymentCents <= 0 || $totalCents <= 0) {
        throw new InvalidArgumentException('Invalid payment schedule values.');
    }

    $existing = $pdo->prepare('SELECT COUNT(*) FROM loan_payments WHERE loan_id = ?');
    $existing->execute([$loanId]);
    if ((int) $existing->fetchColumn() > 0) return;

    $scheduledCents = 0;
    $insert = $pdo->prepare("INSERT INTO loan_payments (loan_id, payment_number, due_date, amount_due, amount_paid, status) VALUES (?, ?, ?, ?, 0.00, 'scheduled')");
    for ($number = 1; $number <= $termMonths; $number++) {
        $dueDate = (new DateTimeImmutable($firstDueDate))->modify('+' . $number . ' month');
        $remainingCents = $totalCents - $scheduledCents;
        $amountDueCents = $number === $termMonths ? $remainingCents : min($paymentCents, $remainingCents);
        if ($amountDueCents <= 0) break;
        $insert->execute([$loanId, $number, $dueDate->format('Y-m-d'), pascco_money_from_cents($amountDueCents)]);
        $scheduledCents += $amountDueCents;
    }
    if ($scheduledCents !== $totalCents) {
        throw new RuntimeException('The repayment schedule does not equal the configured total payable.');
    }
    pascco_refresh_loan_schedule_state($pdo, $loanId);
}

function pascco_refresh_overdue_loan_payments(PDO $pdo): int
{
    $stmt = $pdo->prepare("UPDATE loan_payments SET status = 'overdue' WHERE due_date < CURDATE() AND amount_paid < amount_due AND status IN ('scheduled','partial')");
    $stmt->execute();
    return $stmt->rowCount();
}

function pascco_refresh_loan_schedule_state(PDO $pdo, int $loanId): void
{
    if ($loanId <= 0) {
        return;
    }

    $next = $pdo->prepare("SELECT MIN(due_date) FROM loan_payments WHERE loan_id = ? AND amount_paid < amount_due AND status <> 'waived'");
    $next->execute([$loanId]);
    $nextDue = $next->fetchColumn();

    $update = $pdo->prepare("UPDATE loans SET next_due_date = ? WHERE id = ?");
    $update->execute([$nextDue ?: null, $loanId]);
}

function pascco_apply_loan_payment(PDO $pdo, int $loanId, string|int|float $paymentAmount, string $referenceNumber, ?int $processedBy = null): void
{
    if (!$pdo->inTransaction()) throw new RuntimeException('Loan payments must be processed inside a database transaction.');
    $paymentCents = pascco_money_to_cents($paymentAmount);
    if ($loanId <= 0 || $paymentCents <= 0 || $referenceNumber === '') throw new InvalidArgumentException('Invalid loan payment values.');

    $existingAllocation = $pdo->prepare('SELECT id FROM loan_payment_allocations WHERE reference_number = ? LIMIT 1');
    $existingAllocation->execute([$referenceNumber]);
    if ($existingAllocation->fetchColumn()) throw new RuntimeException('This loan payment was already applied.');

    $remainingCents = $paymentCents;
    $stmt = $pdo->prepare("SELECT id, payment_number, amount_due, amount_paid FROM loan_payments WHERE loan_id = ? AND status IN ('scheduled','partial','overdue') AND amount_paid < amount_due ORDER BY payment_number FOR UPDATE");
    $stmt->execute([$loanId]);
    $rows = $stmt->fetchAll();
    if (!$rows) throw new RuntimeException('This loan has no remaining scheduled payment to apply.');

    $allocationInsert = $pdo->prepare('INSERT INTO loan_payment_allocations (loan_id, loan_payment_id, reference_number, amount, payment_date, processed_by) VALUES (?, ?, ?, ?, NOW(), ?)');
    foreach ($rows as $row) {
        if ($remainingCents <= 0) break;
        $dueCents = pascco_money_to_cents((string) $row['amount_due']);
        $paidCents = pascco_money_to_cents((string) $row['amount_paid']);
        $unpaidCents = $dueCents - $paidCents;
        if ($unpaidCents <= 0) continue;

        $allocationCents = min($remainingCents, $unpaidCents);
        $newPaidCents = $paidCents + $allocationCents;
        $status = $newPaidCents >= $dueCents ? 'paid' : 'partial';
        $scheduleReference = $referenceNumber . '-P' . (int) $row['payment_number'];
        $update = $pdo->prepare('UPDATE loan_payments SET amount_paid = ?, payment_date = NOW(), status = ?, reference_number = ? WHERE id = ?');
        $update->execute([pascco_money_from_cents($newPaidCents), $status, $scheduleReference, (int) $row['id']]);
        $allocationInsert->execute([$loanId, (int) $row['id'], $scheduleReference, pascco_money_from_cents($allocationCents), $processedBy]);
        $remainingCents -= $allocationCents;
    }
    if ($remainingCents > 0) throw new RuntimeException('The loan payment exceeds the remaining scheduled amount.');

    $paidTotal = $pdo->prepare("SELECT COALESCE(SUM(amount_paid),0) FROM loan_payments WHERE loan_id = ?");
    $paidTotal->execute([$loanId]);
    $paidCents = pascco_money_to_cents((string) $paidTotal->fetchColumn());
    $unpaidCount = $pdo->prepare("SELECT COUNT(*) FROM loan_payments WHERE loan_id = ? AND amount_paid < amount_due AND status <> 'waived'");
    $unpaidCount->execute([$loanId]);
    $unpaid = (int) $unpaidCount->fetchColumn();

    $loanTotalStmt = $pdo->prepare('SELECT COALESCE(total_payable, loan_amount) FROM loans WHERE id = ? FOR UPDATE');
    $loanTotalStmt->execute([$loanId]);
    $totalCents = pascco_money_to_cents((string) $loanTotalStmt->fetchColumn());
    $remainingLoanCents = max(0, $totalCents - $paidCents);
    $loanUpdate = $pdo->prepare("UPDATE loans SET remaining_balance = ?, last_payment_date = NOW(), status = CASE WHEN ? = 0 THEN 'paid' ELSE 'active' END WHERE id = ? AND status IN ('approved','disbursed','active')");
    $loanUpdate->execute([pascco_money_from_cents($remainingLoanCents), $unpaid, $loanId]);
    if ($loanUpdate->rowCount() !== 1) throw new RuntimeException('The loan balance could not be updated. The payment was not finalized.');
    pascco_refresh_loan_schedule_state($pdo, $loanId);
}

function pascco_finalize_loan_committee_approval(PDO $pdo, int $loanId, int $requiredApprovals = 1, ?int $approvedBy = null): void
{
    if (!$pdo->inTransaction()) {
        throw new RuntimeException('Loan disbursement must be processed inside a database transaction.');
    }

    if ($loanId <= 0) {
        throw new InvalidArgumentException('Invalid loan ID.');
    }

    // PASCCO currently operates with one authorized administrator.
    $requiredApprovals = 1;

    $loanStmt = $pdo->prepare("SELECT l.*, m.id AS verified_member_id FROM loans l JOIN members m ON m.id = l.member_id WHERE l.id = ? AND l.status = 'under_review' FOR UPDATE");
    $loanStmt->execute([$loanId]);
    $loan = $loanStmt->fetch(PDO::FETCH_ASSOC);
    if (!$loan) {
        throw new RuntimeException('This loan is not awaiting committee approval.');
    }

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM loan_approval_reviews WHERE loan_id = ? AND decision = 'approved'");
    $countStmt->execute([$loanId]);
    $approvalCount = (int) $countStmt->fetchColumn();
    if ($approvalCount < $requiredApprovals) {
        throw new RuntimeException('The required number of committee approvals has not been reached.');
    }

    $termMonths = (int) preg_replace('/[^0-9]/', '', (string) $loan['loan_term']);
    if ($termMonths <= 0 && !empty($loan['loan_bracket_id'])) {
        $termStmt = $pdo->prepare('SELECT term_months FROM loan_brackets WHERE id = ? LIMIT 1');
        $termStmt->execute([(int) $loan['loan_bracket_id']]);
        $termMonths = (int) $termStmt->fetchColumn();
    }
    if ($termMonths <= 0) {
        throw new RuntimeException('The loan term is invalid; payment schedule could not be created.');
    }

    $totalPayableCents = pascco_money_to_cents((string) ($loan['total_payable'] ?? '0.00'));
    $monthlyPaymentCents = pascco_money_to_cents((string) ($loan['monthly_payment'] ?? '0.00'));
    if ($totalPayableCents <= 0) $totalPayableCents = pascco_money_to_cents((string) $loan['loan_amount']);
    if ($monthlyPaymentCents <= 0) $monthlyPaymentCents = pascco_money_round_divide($totalPayableCents, $termMonths);
    $totalPayable = pascco_money_from_cents($totalPayableCents);
    $monthlyPayment = pascco_money_from_cents($monthlyPaymentCents);

    $accStmt = $pdo->prepare("SELECT id, balance FROM accounts WHERE member_id = ? AND status = 'active' ORDER BY id LIMIT 1 FOR UPDATE");
    $accStmt->execute([(int) $loan['member_id']]);
    $acc = $accStmt->fetch(PDO::FETCH_ASSOC);
    if (!$acc) {
        throw new RuntimeException('The member has no active savings account.');
    }

    $refNumber = 'OR-' . date('YmdHis') . '-' . random_int(100000, 999999);
    $tx = $pdo->prepare("INSERT INTO transactions (account_id, transaction_type, amount, recipient_account_id, description, status, reference_number, transaction_date, created_at) VALUES (?, 'deposit', ?, NULL, 'Loan Disbursement', 'completed', ?, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())");
    $loanAmount = pascco_money_from_cents(pascco_money_to_cents((string) $loan['loan_amount']));
    $tx->execute([(int) $acc['id'], $loanAmount, $refNumber]);

    $balanceUpdate = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ? AND status = 'active'");
    $balanceUpdate->execute([$loanAmount, (int) $acc['id']]);
    if ($balanceUpdate->rowCount() !== 1) {
        throw new RuntimeException('The member savings account could not be updated.');
    }

    $maturityDate = (new DateTimeImmutable('today'))->modify('+' . $termMonths . ' month')->format('Y-m-d');
    $loanUpdate = $pdo->prepare("UPDATE loans SET status = 'active', remaining_balance = ?, total_payable = ?, monthly_payment = ?, approval_date = NOW(), approved_by = COALESCE(?, approved_by), disbursement_date = NOW(), maturity_date = ?, committee_completed_at = NOW(), required_approvals = ? WHERE id = ? AND status = 'under_review'");
    $loanUpdate->execute([$totalPayable, $totalPayable, $monthlyPayment, $approvedBy, $maturityDate, $requiredApprovals, $loanId]);
    if ($loanUpdate->rowCount() !== 1) {
        throw new RuntimeException('This loan was already finalized.');
    }

    pascco_generate_loan_payment_schedule($pdo, $loanId, date('Y-m-d'), $termMonths, $monthlyPayment, $totalPayable);
}

function pascco_record_external_loan_payment(PDO $pdo, int $loanId, string|int|float $amount, string $paymentMethod, string $receiptNumber, string $externalReference = '', string $notes = '', ?int $receivedBy = null, ?string $idempotencyKey = null): void
{
    if (!$pdo->inTransaction()) {
        throw new RuntimeException('External loan payments must be processed inside a database transaction.');
    }

    $amountCents = pascco_money_to_cents($amount);
    if ($loanId <= 0 || $amountCents <= 0 || trim($paymentMethod) === '' || trim($receiptNumber) === '') {
        throw new InvalidArgumentException('Invalid external loan payment details.');
    }

    $loanStmt = $pdo->prepare("SELECT id, remaining_balance, status FROM loans WHERE id = ? FOR UPDATE");
    $loanStmt->execute([$loanId]);
    $loan = $loanStmt->fetch();
    if (!$loan || !in_array($loan['status'], ['approved','disbursed','active'], true)) {
        throw new RuntimeException('This loan is not available for payment collection.');
    }

    if ($amountCents > pascco_money_to_cents((string) $loan['remaining_balance'])) {
        throw new RuntimeException('The payment exceeds the remaining loan balance.');
    }

    if ($idempotencyKey !== null) {
        if (!preg_match('/^[a-f0-9]{64}$/', $idempotencyKey)) {
            throw new InvalidArgumentException('Invalid payment idempotency key.');
        }
        $existing = $pdo->prepare('SELECT id FROM loan_payment_receipts WHERE idempotency_key = ? LIMIT 1');
        $existing->execute([$idempotencyKey]);
        if ($existing->fetchColumn()) {
            throw new RuntimeException('This external loan payment was already recorded.');
        }
    }

    $receiptStmt = $pdo->prepare('INSERT INTO loan_payment_receipts (loan_id, receipt_number, amount, payment_method, external_reference, notes, received_by, received_at, idempotency_key) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)');
    $receiptStmt->execute([
        $loanId,
        trim($receiptNumber),
        pascco_money_from_cents($amountCents),
        trim($paymentMethod),
        trim($externalReference) !== '' ? trim($externalReference) : null,
        trim($notes) !== '' ? trim($notes) : null,
        $receivedBy,
        $idempotencyKey
    ]);

    pascco_apply_loan_payment($pdo, $loanId, $amount, trim($receiptNumber), $receivedBy);
}

function pascco_close_paid_loan(PDO $pdo, int $loanId, string $closureReference, ?string $notes = null, ?int $clearedBy = null): void
{
    if ($loanId <= 0 || trim($closureReference) === '' || !$clearedBy) {
        throw new InvalidArgumentException('Invalid loan closure details.');
    }

    $loanStmt = $pdo->prepare("SELECT id, loan_number, status, remaining_balance, total_payable, loan_amount FROM loans WHERE id = ? FOR UPDATE");
    $loanStmt->execute([$loanId]);
    $loan = $loanStmt->fetch(PDO::FETCH_ASSOC);
    if (!$loan) {
        throw new RuntimeException('Loan not found.');
    }

    if ($loan['status'] !== 'paid' || pascco_money_to_cents((string) $loan['remaining_balance']) > 0) {
        throw new RuntimeException('Only a fully paid loan can be cleared.');
    }

    $unpaidStmt = $pdo->prepare("SELECT COUNT(*) FROM loan_payments WHERE loan_id = ? AND amount_paid < amount_due AND status <> 'waived'");
    $unpaidStmt->execute([$loanId]);
    if ((int) $unpaidStmt->fetchColumn() > 0) {
        throw new RuntimeException('The repayment schedule still has an unpaid balance.');
    }

    $existingStmt = $pdo->prepare('SELECT closure_reference FROM loan_closures WHERE loan_id = ? LIMIT 1');
    $existingStmt->execute([$loanId]);
    if ($existingStmt->fetchColumn()) {
        throw new RuntimeException('This loan has already been cleared.');
    }

    $insert = $pdo->prepare('INSERT INTO loan_closures (loan_id, closure_reference, cleared_by, cleared_at, notes) VALUES (?, ?, ?, NOW(), ?)');
    $insert->execute([
        $loanId,
        trim($closureReference),
        $clearedBy,
        trim((string) $notes) !== '' ? trim((string) $notes) : null,
    ]);
}


function pascco_execute_loan_restructuring(PDO $pdo, int $requestId, int $executedBy): array
{
    if ($requestId <= 0 || $executedBy <= 0) {
        throw new InvalidArgumentException('Invalid restructuring execution details.');
    }

    $reqStmt = $pdo->prepare("SELECT r.*, l.loan_number, l.status AS loan_status, l.loan_amount, l.total_payable AS current_total_payable, l.remaining_balance AS current_remaining_balance, l.monthly_payment AS current_monthly_payment, l.loan_term AS current_term, l.interest_amount AS current_interest_amount FROM loan_restructuring_requests r JOIN loans l ON l.id = r.loan_id WHERE r.id = ? FOR UPDATE");
    $reqStmt->execute([$requestId]);
    $request = $reqStmt->fetch(PDO::FETCH_ASSOC);
    if (!$request) {
        throw new RuntimeException('Restructuring request not found.');
    }
    if ($request['status'] !== 'approved') {
        throw new RuntimeException('Only an approved restructuring request can be executed.');
    }
    if (!in_array($request['loan_status'], ['active','approved','disbursed'], true)) {
        throw new RuntimeException('The loan is no longer eligible for restructuring execution.');
    }

    $existing = $pdo->prepare('SELECT id, execution_reference FROM loan_restructuring_executions WHERE restructuring_request_id = ? LIMIT 1');
    $existing->execute([$requestId]);
    if ($existing->fetch(PDO::FETCH_ASSOC)) {
        throw new RuntimeException('This restructuring request has already been executed.');
    }

    $term = (int) ($request['proposed_term_months'] ?? 0);
    $effectiveDate = trim((string) ($request['proposed_effective_date'] ?? ''));
    $proposedRemainingCents = pascco_money_to_cents((string) ($request['proposed_total_payable'] ?? '0.00'));
    $proposedMonthlyCents = pascco_money_to_cents((string) ($request['proposed_monthly_payment'] ?? '0.00'));
    if ($term <= 0 || $effectiveDate === '') {
        throw new RuntimeException('An approved restructuring must include a term and effective date before it can be executed.');
    }
    if ($proposedRemainingCents <= 0 && $proposedMonthlyCents <= 0) {
        throw new RuntimeException('An approved restructuring must include a proposed remaining payable amount or monthly payment.');
    }
    if ($proposedRemainingCents <= 0) $proposedRemainingCents = $proposedMonthlyCents * $term;
    if ($proposedMonthlyCents <= 0) $proposedMonthlyCents = pascco_money_round_divide($proposedRemainingCents, $term);
    if ($proposedRemainingCents <= 0 || $proposedMonthlyCents <= 0) {
        throw new RuntimeException('The proposed restructuring values are invalid.');
    }
    if (abs(($proposedMonthlyCents * $term) - $proposedRemainingCents) > 1) {
        throw new RuntimeException('The approved monthly payment, term, and total payable do not agree.');
    }
    if ($proposedRemainingCents < pascco_money_to_cents((string) $request['current_remaining_balance'])) {
        throw new RuntimeException('The approved proposal is below the current remaining balance.');
    }

    $dateCheck = DateTimeImmutable::createFromFormat('!Y-m-d', $effectiveDate);
    if (!$dateCheck || $dateCheck->format('Y-m-d') !== $effectiveDate) {
        throw new RuntimeException('The restructuring effective date is invalid.');
    }

    $paidStmt = $pdo->prepare("SELECT COALESCE(SUM(amount_paid),0) FROM loan_payments WHERE loan_id = ?");
    $paidStmt->execute([(int) $request['loan_id']]);
    $paidToDateCents = pascco_money_to_cents((string) $paidStmt->fetchColumn());
    $proposedRemaining = pascco_money_from_cents($proposedRemainingCents);
    $proposedMonthly = pascco_money_from_cents($proposedMonthlyCents);
    $paidToDateCents = max(0, $paidToDateCents);
    $newTotalPayable = pascco_money_from_cents($paidToDateCents + $proposedRemainingCents);
    $maturityDate = $dateCheck->modify('+' . $term . ' month')->format('Y-m-d');
    $executionReference = 'RESTR-' . date('YmdHis') . '-' . random_int(100000, 999999);

    $insert = $pdo->prepare('INSERT INTO loan_restructuring_executions (restructuring_request_id, loan_id, execution_reference, executed_by, effective_date, previous_total_payable, previous_remaining_balance, previous_monthly_payment, previous_term_months, new_total_payable, new_remaining_balance, new_monthly_payment, new_term_months, new_maturity_date, executed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())');
    $insert->execute([
        $requestId,
        (int) $request['loan_id'],
        $executionReference,
        $executedBy,
        $effectiveDate,
        $request['current_total_payable'] !== null ? pascco_money_from_cents(pascco_money_to_cents((string) $request['current_total_payable'])) : null,
        pascco_money_from_cents(pascco_money_to_cents((string) $request['current_remaining_balance'])),
        $request['current_monthly_payment'] !== null ? pascco_money_from_cents(pascco_money_to_cents((string) $request['current_monthly_payment'])) : null,
        $request['current_term'] !== null ? (int) $request['current_term'] : null,
        $newTotalPayable,
        $proposedRemaining,
        $proposedMonthly,
        $term,
        $maturityDate,
    ]);

    $waive = $pdo->prepare("UPDATE loan_payments SET status = 'waived', notes = CONCAT(CASE WHEN notes IS NULL OR notes = '' THEN '' ELSE CONCAT(notes, ' | ') END, 'Replaced by restructuring ', ?) WHERE loan_id = ? AND amount_paid < amount_due AND status <> 'waived'");
    $waive->execute([$executionReference, (int) $request['loan_id']]);

    $loanUpdate = $pdo->prepare("UPDATE loans SET total_payable = ?, remaining_balance = ?, monthly_payment = ?, loan_term = ?, maturity_date = ?, status = 'active' WHERE id = ? AND status IN ('active','approved','disbursed')");
    $loanUpdate->execute([$newTotalPayable, $proposedRemaining, $proposedMonthly, $term, $maturityDate, (int) $request['loan_id']]);
    if ($loanUpdate->rowCount() !== 1) {
        throw new RuntimeException('The loan could not be updated for restructuring.');
    }

    $maxStmt = $pdo->prepare('SELECT COALESCE(MAX(payment_number), 0) FROM loan_payments WHERE loan_id = ?');
    $maxStmt->execute([(int) $request['loan_id']]);
    $startNumber = (int) $maxStmt->fetchColumn() + 1;

    $scheduledCents = 0;
    $paymentCents = $proposedMonthlyCents;
    $insertPayment = $pdo->prepare("INSERT INTO loan_payments (loan_id, payment_number, due_date, amount_due, amount_paid, status, notes) VALUES (?, ?, ?, ?, 0.00, 'scheduled', ?)");
    for ($i = 1; $i <= $term; $i++) {
        $dueDate = $dateCheck->modify('+' . $i . ' month')->format('Y-m-d');
        $remainingCents = $proposedRemainingCents - $scheduledCents;
        $amountDueCents = $i === $term ? $remainingCents : min($paymentCents, $remainingCents);
        if ($amountDueCents <= 0) break;
        $insertPayment->execute([(int) $request['loan_id'], $startNumber + $i - 1, $dueDate, pascco_money_from_cents($amountDueCents), 'Restructured under ' . $executionReference]);
        $scheduledCents += $amountDueCents;
    }
    if ($scheduledCents !== $proposedRemainingCents) {
        throw new RuntimeException('The replacement repayment schedule could not be generated exactly.');
    }

    $pdo->prepare('UPDATE loan_restructuring_requests SET updated_at = NOW() WHERE id = ?')->execute([$requestId]);
    pascco_refresh_loan_schedule_state($pdo, (int) $request['loan_id']);

    return [
        'loan_id' => (int) $request['loan_id'],
        'loan_number' => $request['loan_number'],
        'execution_reference' => $executionReference,
        'remaining_balance' => $proposedRemaining,
        'monthly_payment' => $proposedMonthly,
        'term_months' => $term,
        'maturity_date' => $maturityDate,
    ];
}
