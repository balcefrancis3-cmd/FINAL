<?php
/**
 * PASCCO loan notification helpers.
 * Notifications are informational only and never change loan balances or schedules.
 */

require_once __DIR__ . '/mail_config.php';

function pascco_loan_notification_candidates(PDO $pdo): array
{
    $sql = "SELECT l.id AS loan_id, l.loan_number, l.loan_product, l.remaining_balance,
                   l.next_due_date, m.id AS member_id, m.first_name, m.last_name, m.email
            FROM loans l
            JOIN members m ON m.id = l.member_id
            WHERE l.status IN ('approved','disbursed','active')
              AND l.remaining_balance > 0
              AND l.next_due_date IS NOT NULL
              AND m.email IS NOT NULL
              AND TRIM(m.email) <> ''
            ORDER BY l.next_due_date, l.id";
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

function pascco_loan_notification_type(int $daysUntilDue): ?string
{
    if ($daysUntilDue === 7) return 'due_7';
    if ($daysUntilDue === 3) return 'due_3';
    if ($daysUntilDue === 1) return 'due_1';
    if ($daysUntilDue === 0) return 'due_today';

    $daysOverdue = abs($daysUntilDue);
    if ($daysOverdue === 1) return 'overdue_1';
    if ($daysOverdue === 7) return 'overdue_7';
    if ($daysOverdue === 30) return 'overdue_30';

    return null;
}

function pascco_loan_notification_subject(string $type): string
{
    return match ($type) {
        'due_7' => 'PASCCO Loan Payment Reminder — 7 Days Before Due Date',
        'due_3' => 'PASCCO Loan Payment Reminder — 3 Days Before Due Date',
        'due_1' => 'PASCCO Loan Payment Reminder — Due Tomorrow',
        'due_today' => 'PASCCO Loan Payment Reminder — Payment Due Today',
        'overdue_1' => 'PASCCO Loan Payment Notice — Payment Overdue',
        'overdue_7' => 'PASCCO Loan Payment Notice — 7 Days Overdue',
        'overdue_30' => 'PASCCO Loan Payment Notice — 30 Days Overdue',
        default => 'PASCCO Loan Payment Notification',
    };
}

function pascco_loan_notification_message(string $type, string $firstName, string $loanNumber, string $dueDate, float $remainingBalance): array
{
    $safeName = htmlspecialchars($firstName, ENT_QUOTES, 'UTF-8');
    $safeLoan = htmlspecialchars($loanNumber, ENT_QUOTES, 'UTF-8');
    $safeDue = htmlspecialchars($dueDate, ENT_QUOTES, 'UTF-8');
    $safeBalance = htmlspecialchars(number_format($remainingBalance, 2), ENT_QUOTES, 'UTF-8');

    $isOverdue = str_starts_with($type, 'overdue_');
    $headline = $isOverdue ? 'Loan Payment Overdue' : 'Upcoming Loan Payment';
    $intro = $isOverdue
        ? 'Our records show that your next scheduled loan payment is overdue. Please contact PASCCO or make the payment through an available payment channel.'
        : 'This is a reminder that your next scheduled PASCCO loan payment is approaching.';

    $body = "
        <div style='margin:0;padding:0;background:#f4f7fb;font-family:Arial,sans-serif;color:#1f2a44;'>
            <div style='max-width:620px;margin:0 auto;padding:30px 18px;'>
                <div style='background:#0b2c6a;color:#ffffff;padding:22px 26px;border-radius:12px 12px 0 0;'>
                    <h2 style='margin:0;font-size:25px;'>PASCCO {$headline}</h2>
                </div>
                <div style='background:#ffffff;border:1px solid #d7e0ec;border-top:none;border-radius:0 0 12px 12px;padding:28px;'>
                    <p>Dear {$safeName},</p>
                    <p>{$intro}</p>
                    <p style='line-height:1.8;'>
                        <strong>Loan Number:</strong> {$safeLoan}<br>
                        <strong>Next Due Date:</strong> {$safeDue}<br>
                        <strong>Current Remaining Balance:</strong> ₱{$safeBalance}
                    </p>
                    <p>Please refer to your PASCCO Member Portal or contact the cooperative if you need assistance with your repayment schedule.</p>
                    <p>Thank you,<br><strong>Paco Savings and Credit Cooperative</strong></p>
                </div>
            </div>
        </div>
    ";

    $plain = "PASCCO {$headline}\n\nDear {$firstName},\n\n{$intro}\n\n" .
        "Loan Number: {$loanNumber}\nNext Due Date: {$dueDate}\nCurrent Remaining Balance: ₱" . number_format($remainingBalance, 2) .
        "\n\nPlease refer to your PASCCO Member Portal or contact the cooperative if you need assistance with your repayment schedule.\n\nThank you,\nPaco Savings and Credit Cooperative";

    return [$body, $plain];
}

function pascco_send_loan_notification_email(
    string $recipientEmail,
    string $recipientName,
    string $subject,
    string $htmlBody,
    string $plainBody
): bool {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        $config = pascco_get_mail_config();
        pascco_configure_mailer($mail, $config);
        $mail->setFrom($config['from_email'], $config['from_name'] ?? 'Paco Savings and Credit Cooperative');
        $mail->addAddress($recipientEmail, $recipientName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlBody;
        $mail->AltBody = $plainBody;
        $mail->send();
        return true;
    } catch (Throwable $exception) {
        error_log('PASCCO loan notification email error: ' . $exception->getMessage());
        return false;
    }
}

function pascco_process_loan_notifications(PDO $pdo, ?callable $logger = null): array
{
    $summary = ['checked' => 0, 'eligible' => 0, 'sent' => 0, 'failed' => 0, 'skipped' => 0];
    $today = new DateTimeImmutable('today');
    $candidates = pascco_loan_notification_candidates($pdo);
    $summary['checked'] = count($candidates);

    foreach ($candidates as $loan) {
        $due = new DateTimeImmutable($loan['next_due_date']);
        $daysUntilDue = (int)$today->diff($due)->format('%r%a');
        $type = pascco_loan_notification_type($daysUntilDue);
        if ($type === null) {
            continue;
        }
        $summary['eligible']++;

        $existing = $pdo->prepare('SELECT id, status FROM loan_notification_logs WHERE loan_id = ? AND notification_type = ? AND reference_date = ? LIMIT 1');
        $existing->execute([(int)$loan['loan_id'], $type, $loan['next_due_date']]);
        $existingRow = $existing->fetch(PDO::FETCH_ASSOC);
        if ($existingRow && $existingRow['status'] === 'sent') {
            $summary['skipped']++;
            continue;
        }

        [$html, $plain] = pascco_loan_notification_message(
            $type,
            (string)$loan['first_name'],
            (string)$loan['loan_number'],
            (string)$loan['next_due_date'],
            (float)$loan['remaining_balance']
        );

        $sent = pascco_send_loan_notification_email(
            trim((string)$loan['email']),
            trim((string)$loan['first_name'] . ' ' . (string)$loan['last_name']),
            pascco_loan_notification_subject($type),
            $html,
            $plain
        );

        $status = $sent ? 'sent' : 'failed';
        $errorMessage = $sent ? null : 'Email delivery failed. Check the PASCCO mail configuration and SMTP logs.';
        if ($existingRow) {
            $log = $pdo->prepare('UPDATE loan_notification_logs SET recipient_email = ?, status = ?, error_message = ?, sent_at = ? WHERE id = ?');
            $log->execute([
                trim((string)$loan['email']),
                $status,
                $errorMessage,
                $sent ? date('Y-m-d H:i:s') : null,
                (int)$existingRow['id']
            ]);
        } else {
            $log = $pdo->prepare('INSERT INTO loan_notification_logs (loan_id, member_id, notification_type, reference_date, recipient_email, status, error_message, sent_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $log->execute([
                (int)$loan['loan_id'],
                (int)$loan['member_id'],
                $type,
                $loan['next_due_date'],
                trim((string)$loan['email']),
                $status,
                $errorMessage,
                $sent ? date('Y-m-d H:i:s') : null
            ]);
        }

        if ($sent) $summary['sent']++;
        else $summary['failed']++;

        if ($logger) {
            $logger($sent ? 'sent' : 'failed', $loan, $type);
        }
    }

    return $summary;
}
