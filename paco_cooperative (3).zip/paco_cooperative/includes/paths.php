<?php
// PASCCO application URL helpers.
if (!defined('PASCCO_BASE_URL')) {
    define('PASCCO_BASE_URL', '/paco_cooperative');
}
function pascco_url(string $path = ''): string {
    return PASCCO_BASE_URL . '/' . ltrim($path, '/');
}
