<?php
/**
 * PASCCO monetary helpers.
 * Financial amounts are represented as integer centavos during arithmetic and
 * converted to fixed two-decimal strings only at database/UI boundaries.
 */

function pascco_money_to_cents(mixed $value, bool $allowNegative = false): int
{
    if (is_int($value)) {
        $raw = (string) $value;
    } elseif (is_string($value)) {
        $raw = trim($value);
    } elseif (is_float($value) && is_finite($value)) {
        // Compatibility path only. New financial inputs should remain strings.
        $raw = number_format($value, 2, '.', '');
    } else {
        throw new InvalidArgumentException('Invalid monetary value.');
    }

    $pattern = $allowNegative
        ? '/^-?\d{1,13}(?:\.\d{1,2})?$/D'
        : '/^\d{1,13}(?:\.\d{1,2})?$/D';
    if (!preg_match($pattern, $raw)) {
        throw new InvalidArgumentException('Money must be a decimal amount with no more than two decimal places.');
    }

    $negative = str_starts_with($raw, '-');
    if ($negative) {
        $raw = substr($raw, 1);
    }
    [$whole, $fraction] = array_pad(explode('.', $raw, 2), 2, '');
    $fraction = str_pad($fraction, 2, '0');
    $wholeCents = (int) $whole * 100;
    $fractionCents = (int) $fraction;
    $cents = $wholeCents + $fractionCents;
    return $negative ? -$cents : $cents;
}

function pascco_money_input_to_cents(mixed $value): ?int
{
    if (!is_string($value) && !is_int($value)) {
        return null;
    }
    $raw = trim((string) $value);
    if ($raw === '' || !preg_match('/^\d{1,13}(?:\.\d{1,2})?$/D', $raw)) {
        return null;
    }
    try {
        return pascco_money_to_cents($raw);
    } catch (InvalidArgumentException) {
        return null;
    }
}

function pascco_money_from_cents(int $cents): string
{
    $sign = $cents < 0 ? '-' : '';
    $absolute = abs($cents);
    return $sign . intdiv($absolute, 100) . '.' . str_pad((string) ($absolute % 100), 2, '0', STR_PAD_LEFT);
}

function pascco_money_round_divide(int $cents, int $divisor): int
{
    if ($divisor <= 0) {
        throw new InvalidArgumentException('Money divisor must be positive.');
    }
    $quotient = intdiv($cents, $divisor);
    $remainder = $cents % $divisor;
    if (abs($remainder) * 2 >= $divisor) {
        $quotient += $cents < 0 ? -1 : 1;
    }
    return $quotient;
}

function pascco_money_display(mixed $value): string
{
    return number_format(pascco_money_to_cents((string) $value) / 100, 2, '.', ',');
}
