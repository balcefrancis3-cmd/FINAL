-- PASCCO Announcement Audience Control
-- Adds a destination/audience to announcements so administrators can choose
-- whether an announcement is shown publicly, to members, or to both.
--
-- Run once on the existing paco_cooperative database. Back up first.
-- Safe to re-run: the column/index are checked before creation.

SET @column_exists := (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'announcements'
      AND COLUMN_NAME = 'audience'
);

SET @sql := IF(
    @column_exists = 0,
    "ALTER TABLE announcements ADD COLUMN audience ENUM('public','members','both') NOT NULL DEFAULT 'members' AFTER image_path",
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Preserve existing published announcements in both destinations so no
-- existing announcement disappears from either audience after the upgrade.
UPDATE announcements
SET audience = 'both'
WHERE status = 'published';

SET @index_exists := (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'announcements'
      AND INDEX_NAME = 'idx_announcements_audience_status_date'
);

SET @sql := IF(
    @index_exists = 0,
    'CREATE INDEX idx_announcements_audience_status_date ON announcements (audience, status, published_at)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
