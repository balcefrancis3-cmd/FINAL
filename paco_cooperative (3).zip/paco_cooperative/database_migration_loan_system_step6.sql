-- PASCCO Loan System Step 6
-- Loan due-date and overdue notification tracking.
-- This migration does not alter loan balances, rates, schedules, or payment amounts.

CREATE TABLE IF NOT EXISTS loan_notification_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    loan_id INT(11) NOT NULL,
    member_id INT UNSIGNED NOT NULL,
    notification_type VARCHAR(40) NOT NULL,
    reference_date DATE NOT NULL,
    recipient_email VARCHAR(150) NOT NULL,
    status ENUM('sent','failed') NOT NULL,
    error_message VARCHAR(500) DEFAULT NULL,
    sent_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_loan_notification (loan_id, notification_type, reference_date),
    INDEX idx_loan_notification_status_date (status, created_at),
    INDEX idx_loan_notification_member (member_id, created_at),
    CONSTRAINT fk_loan_notification_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE,
    CONSTRAINT fk_loan_notification_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

START TRANSACTION;

SET @idx_loans_notification_due_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loans' AND INDEX_NAME = 'idx_loans_notification_due'
);
SET @sql := IF(@idx_loans_notification_due_exists = 0,
    'CREATE INDEX idx_loans_notification_due ON loans(status, next_due_date, member_id)',
    'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

COMMIT;
