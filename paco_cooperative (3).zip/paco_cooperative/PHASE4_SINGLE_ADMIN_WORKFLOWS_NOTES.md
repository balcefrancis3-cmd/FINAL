# PASCCO Phase 4 — Single-Admin Workflows

This phase continues from the Phase 3 project and focuses on simulated deposit reviews, withdrawal reviews, and loan decisions for a single authorized administrator.

## Changes

- Deposit approval and rejection now use a database transaction and lock the pending request before making a decision.
- Deposit approval locks the active account, validates the amount in centavos, writes a completed simulated transaction with a deterministic request idempotency key, updates the balance, and marks the request approved in the same transaction.
- Deposit rejection now uses the same pending-request lock and conditional status transition. Rejections do not add simulated funds.
- Withdrawal approval continues to lock the pending request and account, recheck the latest balance, and commit the debit and request status atomically.
- Loan identity review and rejection now lock the pending loan and commit their status updates transactionally.
- Loan review and approval screens use single-administrator wording. The existing approval queue remains the point where the one administrator approves or rejects the loan; approval triggers simulated disbursement and schedule generation in a transaction.
- Unexpected exceptions in the reviewed workflows are logged server-side and replaced with generic user-facing messages. Expected validation errors remain readable.
- Added `tests/phase4_admin_workflow_tests.php` with static regression checks.

## Database

No new SQL migration is introduced in this phase. The workflow uses the existing `deposit_requests`, `withdrawal_requests`, `transactions`, `accounts`, `loans`, and `loan_approval_reviews` schema. Ensure the existing financial-idempotency migration is already applied, because deposit posting now uses `transactions.idempotency_key`.

## Verification limits

PHP syntax checks, JavaScript syntax checks, Phase 2 money tests, Phase 3 configuration tests, Phase 4 static checks, and ZIP integrity checks are performed during packaging. These do not substitute for a live XAMPP/MariaDB/browser integration test. Test only with simulation data after backing up the current project and database.
