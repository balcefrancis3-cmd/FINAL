# PASCCO Phase 4 — Certificates

## Included
- `admin/admin_certificates.php`: administrator-only searchable list of approved members with a View / Print action.
- `member/membership_certificate.php`: print-ready membership certificate; members can view only their own certificate, while an administrator may select a member by ID.
- Existing `member/loan_clearance.php` remains in place for loan clearance certificates.
- `tests/phase4_certificates_tests.php`: static checks for authorization, approved-status gating, escaping, and print support.

## Safety and data handling
- No database migration is included; certificates are rendered from existing approved membership and member records.
- No member, account, or financial records are created, deleted, or modified by opening/printing a certificate.
- Membership certificate reference is deterministically derived from the member number. It is an internal reference, not a claim of external legal registration.
- The certificate is available only where the linked membership application has `approved` status.
- Printing / Save as PDF uses the browser print dialog. It does not create a server-side PDF file.

## Verification limits
Static source checks and PHP syntax checks do not verify live database schema compatibility, browser rendering, or actual print output. Test in a separate XAMPP project copy before using it with the live simulation database.
