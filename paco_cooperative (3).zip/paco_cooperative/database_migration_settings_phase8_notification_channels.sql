-- PASCCO Settings Phase 8 - Notification Channels
-- Import once into the existing paco_cooperative database.
-- Safe to re-run.

ALTER TABLE member_notification_preferences
    ADD COLUMN IF NOT EXISTS email_notifications TINYINT(1) NOT NULL DEFAULT 1 AFTER general_updates;

-- Existing members remain opted in to the currently supported email channel.
UPDATE member_notification_preferences
SET email_notifications = 1
WHERE email_notifications IS NULL;
