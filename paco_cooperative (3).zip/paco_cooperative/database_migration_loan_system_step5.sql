-- PASCCO Loan System - Step 5
-- Reporting performance indexes only; no financial data or policy changes.
-- Run AFTER Steps 1 through 4 and after taking a database backup.

START TRANSACTION;

SET @idx_alloc_date_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_payment_allocations' AND INDEX_NAME = 'idx_loan_allocations_payment_date'
);
SET @sql := IF(@idx_alloc_date_exists = 0,
    'CREATE INDEX idx_loan_allocations_payment_date ON loan_payment_allocations(payment_date)',
    'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_receipt_date_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_payment_receipts' AND INDEX_NAME = 'idx_loan_receipts_received_at'
);
SET @sql := IF(@idx_receipt_date_exists = 0,
    'CREATE INDEX idx_loan_receipts_received_at ON loan_payment_receipts(received_at)',
    'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

COMMIT;

-- This migration does not alter loan balances, schedules, rates, or receipts.
