# PASCCO Phase 6 — Optional Production Preparation

## Scope
This phase adds a read-only deployment readiness inventory, baseline Apache protections, and additional response headers. It **does not** convert PASCCO into a production banking system, enable remote access, certify legal compliance, or connect to a real financial institution. The localhost-only guard is intentionally preserved.

## Run the readiness inventory
From the project directory in Command Prompt:

```bat
php tools\deployment_readiness.php
```

The tool is CLI-only and read-only. It does not connect to MySQL or change settings. `CHECK` and `MANUAL` items require a human review; even all `PASS` results would not constitute a security certification. Run it using the same PHP executable/configuration used by your XAMPP setup where possible.

## Apache protections
The root `.htaccess` disables directory indexes, denies HTTP access to common backup/config/schema artifacts, and blocks direct web access to `/tools` and `/tests`. Upload folders that contain private documents also need `Require all denied`. These rules assume Apache 2.4 with `mod_rewrite` enabled. If Apache reports a 500 error after adding `.htaccess`, check the Apache error log and module/AllowOverride configuration; do not remove the localhost-only access guard as a workaround.

The session bootstrap adds `Permissions-Policy` and `X-Permitted-Cross-Domain-Policies`. HSTS is sent only when PHP detects HTTPS. HSTS should not be enabled for plain HTTP localhost. A strict Content Security Policy is intentionally **not** forced in this phase because the current pages may rely on inline scripts/styles and third-party assets; inventory and test those dependencies before introducing CSP.

## Backups and recovery
The project already includes CLI backup-related scripts in `security/`. Before using them, read `security/README.md` and `security/backup.ps1` carefully and confirm their paths match your installation. Store encrypted backups outside `htdocs`, restrict Windows file permissions, and keep a separate offline copy. Do not place backup files in public or upload directories.

A backup is not proven useful until a restore drill succeeds. Restore to a **separate disposable database and folder**, verify the archive and encryption passphrase, confirm expected tables and account/loan records, verify uploaded documents, then test login and core workflows. Never test restore over the working database. Keep the encryption passphrase separately from the backup. A backup that includes `private/config.php` contains secrets once decrypted and must be treated as highly sensitive.

## Production blockers — resolve before any remote exposure
- Keep `security/session.php` localhost-only for this simulation. Do not relax it for LAN/internet access without a separate, reviewed deployment plan.
- Configure HTTPS/TLS at the real hosting layer and verify secure cookies, reverse-proxy behavior, and HSTS before enabling HSTS permanently.
- Review and test CSRF protection on every state-changing endpoint, authorization on every admin/member route, session revocation, MFA/OTP recovery, rate limits, and authentication logging.
- Review upload validation, private document serving, malware scanning, backup retention, and access permissions.
- Review privacy notice, lawful basis/consent, retention/deletion, incident handling, and applicable Philippine privacy/financial regulations with qualified professionals. This package does not claim compliance with the Data Privacy Act or banking regulations.
- Use least-privilege database accounts; a separate backup account may need different permissions than the app account. Never expose credentials in source control, web roots, screenshots, or logs.
- Perform browser-based functional tests, dependency review, security testing, and a full backup/restore drill in an isolated environment.

## Verification performed for this package
Static PHP/JavaScript syntax checks and existing CLI test suites are run during packaging. No live XAMPP/MariaDB, Apache-header, browser, restore, penetration, or regulatory-compliance testing is claimed.
