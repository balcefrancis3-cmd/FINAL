-- PASCCO Settings Phase 9 - Privacy Controls & Notice Acknowledgment
-- Import once after the Phase 7/8 notification migrations.

CREATE TABLE IF NOT EXISTS member_privacy_acknowledgments (
    user_id INT UNSIGNED NOT NULL,
    notice_version VARCHAR(40) NOT NULL,
    acknowledged_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_member_privacy_ack_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_member_privacy_ack_version (notice_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
