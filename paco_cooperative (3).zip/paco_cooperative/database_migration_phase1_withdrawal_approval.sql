-- PASCCO Phase 1: Withdrawal approval workflow for simulation mode
-- Back up the database before applying. Safe to re-run on MySQL/MariaDB versions
-- that support CREATE TABLE IF NOT EXISTS. Existing completed transactions are unchanged.

CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    account_id INT UNSIGNED NOT NULL,
    member_id INT UNSIGNED NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    description VARCHAR(255) NOT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    idempotency_key CHAR(64) NOT NULL,
    admin_notes VARCHAR(500) DEFAULT NULL,
    reviewed_by INT UNSIGNED DEFAULT NULL,
    reviewed_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_withdrawal_requests_idempotency_key (idempotency_key),
    INDEX idx_withdrawal_requests_status (status, created_at),
    INDEX idx_withdrawal_requests_member (member_id, created_at),
    CONSTRAINT fk_withdrawal_requests_account FOREIGN KEY (account_id) REFERENCES accounts(id),
    CONSTRAINT fk_withdrawal_requests_member FOREIGN KEY (member_id) REFERENCES members(id),
    CONSTRAINT fk_withdrawal_requests_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT chk_withdrawal_requests_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
