<?php
/** Static checks for Phase 5 tools. No database writes are performed. */
$root = dirname(__DIR__); $checks=0; $failures=[];
$assert=static function(bool $ok,string $label) use (&$checks,&$failures): void { $checks++; if(!$ok)$failures[]=$label; };
$reset=file_get_contents($root.'/tools/reset_simulation.php');
$tracker=file_get_contents($root.'/tools/migration_tracker.php');
$report=file_get_contents($root.'/admin/admin_simulation_reconciliation.php');
$shell=file_get_contents($root.'/includes/pascco_shell.php');
$migration=file_get_contents($root.'/database_migration_phase5_tracking.sql');
$assert(strpos($reset,"PHP_SAPI !== 'cli'")!==false,'Reset is CLI-only');
$assert(strpos($reset,'--execute')!==false && strpos($reset,'RESET-PASCCO-SIMULATION')!==false,'Reset requires explicit execution confirmation');
$assert(strpos($reset,'if (!$execute)')!==false,'Reset defaults to dry-run');
$assert(strpos($reset,"UPDATE accounts SET balance = 0.00")!==false,'Reset zeroes simulated account balances only on execute');
$assert(strpos($reset,"'users'")===false && strpos($reset,"'members'")===false,'Reset allowlist does not include users or members');
$assert(strpos($reset,"'loan_products'")===false && strpos($reset,"'loan_brackets'")===false,'Reset preserves loan configuration');
$assert(strpos($reset,'information_schema.KEY_COLUMN_USAGE')!==false,'Reset checks for external foreign-key references');
$assert(strpos($tracker,"PHP_SAPI !== 'cli'")!==false,'Migration tracker is CLI-only');
$assert(strpos($tracker,'never')!==false || strpos($tracker,'does not execute')!==false,'Migration tracker documents non-execution');
$assert(strpos($tracker,'hash_file(\'sha256\'')!==false,'Migration tracker checks file checksums');
$assert(strpos($report,'require_admin();')!==false,'Reconciliation report requires admin authorization');
$assert(stripos($report,'read-only')!==false,'Reconciliation report declares read-only behavior');
$assert(strpos($report,'ledger_net')!==false,'Reconciliation report calculates completed ledger net');
$assert(strpos($report,'opening balance')!==false,'Reconciliation warns about missing opening-balance baseline');
$assert(strpos($shell,'admin_simulation_reconciliation.php')!==false,'Reconciliation page is linked in admin navigation');
$assert(strpos($migration,'CREATE TABLE IF NOT EXISTS schema_migrations')!==false,'Migration tracking schema is included');
if($failures){fwrite(STDERR,count($failures)." failed out of {$checks} checks:\n- ".implode("\n- ",$failures)."\n");exit(1);} echo "{$checks} passed, 0 failed\n";
