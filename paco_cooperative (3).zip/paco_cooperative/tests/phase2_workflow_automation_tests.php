<?php
/**
 * Static regression checks for Phase 2 workflow automation.
 * These checks do not replace live database/browser integration tests.
 */
$root = dirname(__DIR__);
$loans = file_get_contents($root . '/admin/admin_loans.php');
$approval = file_get_contents($root . '/admin/admin_loan_committee.php');
$checks = [
    'Identity verification checks for required documents' => str_contains($loans, 'id_document_path') && str_contains($loans, 'proof_income_path') && str_contains($loans, 'Required identity or income documents are missing.'),
    'Active product and bracket are rechecked before routing' => str_contains($loans, "p.status = 'active' AND b.status = 'active'") && str_contains($loans, 'The selected loan product or bracket is no longer active.'),
    'Loan amount is rechecked against configured bracket limits' => str_contains($loans, '$amountCents < pascco_money_to_cents') && str_contains($loans, '$amountCents > pascco_money_to_cents'),
    'Income limits are rechecked before routing' => str_contains($loans, '$bracket[\'minimum_income\']') && str_contains($loans, '$bracket[\'maximum_income\']'),
    'Required savings are rechecked before routing' => str_contains($loans, '$bracket[\'required_savings\']') && str_contains($loans, "SUM(balance), 0) FROM accounts WHERE member_id = ? AND status = 'active'"),
    'Verified eligible application automatically enters approval queue' => str_contains($loans, "status = 'under_review', required_approvals = 1, committee_submitted_at = NOW()"),
    'Automatic routing does not disburse the loan' => str_contains($loans, 'no funds have been disbursed.'),
    'Audit event is written in the same transaction as routing' => str_contains($loans, "INSERT INTO audit_logs (user_id, action, description, ip_address, status)") && str_contains($loans, '$pdo->commit();'),
    'Single-admin approval queue still requires an explicit decision' => str_contains($approval, "['approve','reject']") && str_contains($approval, "status = 'under_review'"),
    'Eligibility is rechecked immediately before approval' => str_contains($approval, 'Recheck current eligibility immediately before final approval/disbursement') && str_contains($approval, 'The member no longer meets the required active-savings threshold.'),
];
$failed = 0;
foreach ($checks as $label => $passed) {
    echo ($passed ? 'PASS: ' : 'FAIL: ') . $label . PHP_EOL;
    if (!$passed) $failed++;
}
echo PHP_EOL . 'Summary: ' . (count($checks) - $failed) . ' passed, ' . $failed . ' failed' . PHP_EOL;
exit($failed === 0 ? 0 : 1);
