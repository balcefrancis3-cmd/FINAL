<?php
/**
 * Static regression checks for Phase 3 loan configuration safeguards.
 * These checks inspect source contracts; they do not replace live DB/browser tests.
 */
$root = dirname(__DIR__);
$admin = file_get_contents($root . '/admin/admin_loan_products.php');
$apply = file_get_contents($root . '/member/apply_loan.php');
$checks = [
    'Product edit action is available' => str_contains($admin, '?edit_product=') && str_contains($admin, "'Edit Loan Product'"),
    'Bracket edit action is available' => str_contains($admin, '?edit_bracket=') && str_contains($admin, "'Edit Loan Bracket'"),
    'Interest rates require a decimal format with at most four places' => str_contains($admin, '$interestRateRaw = trim') && str_contains($admin, 'Enter an interest rate using up to four decimal places'),
    'Active bracket amount ranges cannot overlap' => str_contains($admin, 'This active bracket overlaps another active bracket'),
    'Bracket activation checks parent product status' => str_contains($admin, 'Activate the loan product before activating its bracket.'),
    'Products without active brackets are visibly flagged' => str_contains($admin, 'Needs bracket setup'),
    'Application sums active savings accounts' => str_contains($apply, 'COALESCE(SUM(balance), 0)'),
    'Birth date rejects impossible/future dates' => str_contains($apply, 'birthDateObject > new DateTimeImmutable(\'today\')'),
    'Unexpected application exceptions are logged and hidden' => str_contains($apply, 'PASCCO loan application error:') && str_contains($apply, 'The loan application could not be completed.'),
];
$failed = 0;
foreach ($checks as $label => $passed) {
    echo ($passed ? 'PASS: ' : 'FAIL: ') . $label . PHP_EOL;
    if (!$passed) $failed++;
}
echo PHP_EOL . 'Summary: ' . (count($checks) - $failed) . ' passed, ' . $failed . ' failed' . PHP_EOL;
exit($failed === 0 ? 0 : 1);
