<?php
/**
 * Static regression checks for Phase 4 single-admin workflows.
 * These checks do not replace a live MySQL/browser integration test.
 */
$root = dirname(__DIR__);
$checks = 0;
$failures = [];
$assert = static function (bool $condition, string $name) use (&$checks, &$failures): void {
    $checks++;
    if (!$condition) $failures[] = $name;
};
$deposits = file_get_contents($root . '/admin/admin_deposits.php');
$withdrawals = file_get_contents($root . '/admin/admin_withdrawals.php');
$loans = file_get_contents($root . '/admin/admin_loans.php');
$approval = file_get_contents($root . '/admin/admin_loan_committee.php');
$engine = file_get_contents($root . '/includes/loan_engine.php');
$assert(strpos($deposits, "SELECT id, account_id, amount, status FROM deposit_requests WHERE id = ? AND status = 'pending' FOR UPDATE") !== false, 'Deposit requests are locked before review');
$assert(strpos($deposits, "UPDATE deposit_requests SET status = 'approved'") !== false, 'Deposit approval has conditional status update');
$assert(strpos($deposits, "UPDATE deposit_requests SET status = 'rejected'") !== false, 'Deposit rejection has conditional status update');
$assert(strpos($deposits, 'hash(\'sha256\', \'deposit-request:\' . $requestId)' ) !== false, 'Approved deposit transaction has deterministic idempotency key');
$assert(strpos($deposits, 'pascco_log_exception($exception, \'admin_deposit_review\')') !== false, 'Unexpected deposit errors are logged');
$assert(strpos($withdrawals, "SELECT id, account_id, member_id, amount, description FROM withdrawal_requests WHERE id = ? AND status = 'pending' FOR UPDATE") !== false, 'Withdrawal requests are locked before review');
$assert(strpos($loans, "status = 'under_review', required_approvals = 1, committee_submitted_at = NOW()") !== false, 'Verified eligible loan automatically routes to single-admin approval queue');
$assert(strpos($loans, 'pascco_log_exception($exception, \'admin_loan_review\')') !== false, 'Unexpected loan review errors are logged');
$assert(strpos($approval, 'Loan Approval Queue') !== false, 'Loan approval screen uses single-admin wording');
$assert(strpos($approval, 'pascco_log_exception($exception, \'admin_loan_approval\')') !== false, 'Unexpected approval/disbursement errors are logged');
$assert(strpos($engine, '$requiredApprovals = 1;') !== false, 'Loan finalization enforces one administrator approval');
if ($failures) {
    fwrite(STDERR, count($failures) . " failed out of $checks checks:\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}
echo "$checks passed, 0 failed\n";
