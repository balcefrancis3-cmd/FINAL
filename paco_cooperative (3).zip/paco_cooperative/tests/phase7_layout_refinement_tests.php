<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$checks = 0;
$failures = [];

$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    $checks++;
    if (!$condition) {
        $failures[] = $message;
    }
};

$cssPath = $root . '/assets/css/pascco-layout-refinement-phase7.css';
$publicPath = $root . '/includes/pascco_layout.php';
$shellPath = $root . '/includes/pascco_shell.php';

$assert(is_file($cssPath), 'Shared Phase 7 stylesheet exists.');
$assert(is_file($publicPath), 'Public layout include exists.');
$assert(is_file($shellPath), 'Member/admin shell include exists.');

$css = is_file($cssPath) ? (string) file_get_contents($cssPath) : '';
$public = is_file($publicPath) ? (string) file_get_contents($publicPath) : '';
$shell = is_file($shellPath) ? (string) file_get_contents($shellPath) : '';

$assert(str_contains($public, 'pascco-layout-refinement-phase7.css?v=1'), 'Public layout loads the shared refinement stylesheet.');
$assert(str_contains($shell, 'pascco-layout-refinement-phase7.css?v=1'), 'Member/admin shell loads the shared refinement stylesheet.');
$assert(str_contains($css, 'body.pascco-public-site .page-shell'), 'Public page spacing is explicitly normalized.');
$assert(str_contains($css, '.member-content') && str_contains($css, '.admin-wrap'), 'Member and admin content wrappers share the layout rules.');
$assert(str_contains($css, '@media (max-width: 760px)'), 'Mobile spacing rules are present.');
$assert(str_contains($css, '@media (max-width: 480px)'), 'Small-screen layout rules are present.');
$assert(str_contains($css, 'prefers-reduced-motion: reduce'), 'Reduced-motion preference is respected.');
$assert(!preg_match('/<\?php|\b(?:INSERT|UPDATE|DELETE|DROP)\s+/i', $css), 'Stylesheet contains no embedded PHP or SQL statements.');
$assert(str_contains($css, '--pascco-layout-gutter') && str_contains($css, '--pascco-layout-section-gap'), 'Shared spacing tokens are defined.');

if ($failures !== []) {
    fwrite(STDERR, "Phase 7 layout checks failed: " . count($failures) . " of {$checks}\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    exit(1);
}

echo "Phase 7 layout checks passed: {$checks}\n";
