<?php
$root = dirname(__DIR__);
$dashboard = file_get_contents($root . '/admin/admin_dashboard.php');
$css = file_get_contents($root . '/assets/css/pascco-admin-dashboard-phase4.css');
$checks = [];
$check = static function (bool $ok, string $label) use (&$checks): void { $checks[] = [$ok, $label]; echo ($ok ? 'PASS: ' : 'FAIL: ') . $label . PHP_EOL; };
$check(str_contains($dashboard, 'DATE_FORMAT(created_at'), 'Membership trend uses database registration timestamps');
$check(str_contains($dashboard, 'DATE_FORMAT(application_date'), 'Loan trend uses loan application timestamps');
$check(str_contains($dashboard, 'last 6 months'), 'Chart period is explained in dashboard labels');
$check(str_contains($dashboard, 'Monthly member registrations chart'), 'Membership chart includes accessible description');
$check(str_contains($dashboard, 'Monthly loan applications chart'), 'Loan chart includes accessible description');
$check(str_contains($dashboard, 'Loan status distribution'), 'Loan status distribution is displayed');
$check(str_contains($dashboard, 'pascco_log_exception'), 'Optional chart-query failures are logged without breaking page');
$check(str_contains($css, '.chart-grid') && str_contains($css, '@media(max-width:900px)'), 'Charts have responsive layout');
$check(!str_contains($dashboard, 'cdn.jsdelivr.net/npm/chart.js'), 'Charts do not depend on a third-party chart CDN');
$check(str_contains($dashboard, "a.status, u.username") && str_contains($dashboard, "'status'"), 'Audit activity query includes event result status');
$failed = count(array_filter($checks, static fn($item) => !$item[0]));
echo PHP_EOL . count($checks) . ' checks, ' . $failed . ' failed.' . PHP_EOL;
exit($failed === 0 ? 0 : 1);
