<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$checks = 0;
$failures = [];
$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    $checks++;
    if (!$condition) $failures[] = $message;
};

$cssPath = $root . '/assets/css/pascco-ui-cleanup-phase7.css';
$css = is_file($cssPath) ? (string) file_get_contents($cssPath) : '';
$shell = (string) file_get_contents($root . '/includes/pascco_shell.php');
$layout = (string) file_get_contents($root . '/includes/pascco_layout.php');
$assert(is_file($cssPath), 'Shared UI cleanup stylesheet exists.');
$assert(str_contains($shell, 'pascco-ui-cleanup-phase7.css?v=1'), 'Member/admin shell loads UI cleanup stylesheet.');
$assert(str_contains($layout, 'pascco-ui-cleanup-phase7.css?v=1'), 'Public layout loads UI cleanup stylesheet.');
$assert(strpos($shell, 'pascco-ui-cleanup-phase7.css?v=1') > strpos($shell, 'pascco-responsive-phase6.css?v=1'), 'Member/admin cleanup CSS loads after responsive CSS.');
$assert(strpos($layout, 'pascco-ui-cleanup-phase7.css?v=1') > strpos($layout, 'pascco-responsive-phase6.css?v=1'), 'Public cleanup CSS loads after responsive CSS.');
$assert(str_contains($css, ':focus-visible'), 'Keyboard focus remains visible.');
$assert(str_contains($css, 'prefers-reduced-motion: reduce'), 'Reduced-motion preferences are respected.');
$assert(str_contains($css, 'overflow-wrap: anywhere'), 'Long table values cannot force excessive horizontal overflow.');
$assert(!preg_match('/<\?php|\b(?:INSERT|UPDATE|DELETE|DROP)\s+/i', $css), 'Stylesheet contains no PHP or SQL operations.');

if ($failures !== []) {
    fwrite(STDERR, "Phase 7 UI cleanup checks failed: " . count($failures) . " of {$checks}\n");
    foreach ($failures as $failure) fwrite(STDERR, " - {$failure}\n");
    exit(1);
}
echo "Phase 7 UI cleanup checks passed: {$checks}\n";
