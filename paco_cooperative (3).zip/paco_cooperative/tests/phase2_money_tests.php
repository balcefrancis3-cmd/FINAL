<?php
// CLI-only regression tests for Phase 2 money arithmetic.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require_once __DIR__ . '/../includes/money.php';
require_once __DIR__ . '/../includes/loan_engine.php';

$passed = 0;
$failed = 0;
$assert = static function (bool $condition, string $label) use (&$passed, &$failed): void {
    if ($condition) {
        echo "PASS: {$label}\n";
        $passed++;
    } else {
        echo "FAIL: {$label}\n";
        $failed++;
    }
};

$assert(pascco_money_to_cents('0.10') + pascco_money_to_cents('0.20') === 30, '0.10 + 0.20 is exactly 30 centavos');
$assert(pascco_money_from_cents(123456) === '1234.56', 'centavos serialize to fixed two-decimal string');
$assert(pascco_money_from_cents(-123) === '-1.23', 'negative internal amount formats correctly');
$assert(pascco_money_input_to_cents('123.45') === 12345, 'valid user amount is parsed exactly');
$assert(pascco_money_input_to_cents('1.234') === null, 'more than two decimal places are rejected');
$assert(pascco_money_input_to_cents('1e3') === null, 'scientific notation is rejected');
$assert(pascco_money_input_to_cents('-1.00') === null, 'negative user amount is rejected');
$assert(pascco_money_round_divide(10000, 3) === 3333, 'centavo division rounds to nearest centavo');

$flat = pascco_calculate_loan('1000.00', 12, 12.0, 'flat', 'annual');
$assert($flat['interest_amount'] === '120.00', 'flat annual interest is calculated in centavos');
$assert($flat['total_payable'] === '1120.00', 'flat total payable remains exact');
$assert($flat['monthly_payment'] === '93.33', 'monthly installment is rounded to centavos');

$reducing = pascco_calculate_loan('20000.00', 12, 12.0, 'reducing_balance', 'annual');
$assert($reducing['monthly_payment'] === '1776.98', 'reducing-balance installment is rounded to centavos');
$assert($reducing['total_payable'] === '21323.76', 'reducing-balance total is derived from rounded installments');

$zeroRate = pascco_calculate_loan('100.00', 3, 0.0, 'reducing_balance', 'annual');
$assert($zeroRate['monthly_payment'] === '33.33', 'zero-interest reducing-balance payment rounds to centavos');
$assert($zeroRate['total_payable'] === '100.00', 'zero-rate total payable never falls below principal');

try {
    pascco_money_to_cents('12.345');
    $assert(false, 'strict parser rejects extra decimal places');
} catch (InvalidArgumentException) {
    $assert(true, 'strict parser rejects extra decimal places');
}

echo "\nSummary: {$passed} passed, {$failed} failed\n";
exit($failed === 0 ? 0 : 1);
