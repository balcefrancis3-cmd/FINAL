<?php
$root = dirname(__DIR__);
$admin = file_get_contents($root . '/admin/admin_certificates.php');
$certificate = file_get_contents($root . '/member/membership_certificate.php');
$checks = [
    'admin certificate page requires administrator access' => str_contains($admin, 'require_admin();'),
    'admin listing only includes approved applications' => str_contains($admin, "a.status='approved'"),
    'search values use prepared parameters' => str_contains($admin, '$stmt->execute($params);'),
    'admin certificate links use numeric member ID' => str_contains($admin, '(int)$member[\'id\']'),
    'certificate page requires a signed-in role' => str_contains($certificate, "['member', 'admin']"),
    'member can only access own member record' => str_contains($certificate, "WHERE m.user_id=?"),
    'admin must specify a member record' => str_contains($certificate, 'Select a valid member.'),
    'certificate only available for approved membership' => str_contains($certificate, "a.status='approved'"),
    'certificate text is HTML escaped' => str_contains($certificate, 'htmlspecialchars('),
    'certificate supports print or PDF via browser' => str_contains($certificate, 'window.print()'),
    'certificate response disables caching' => str_contains($certificate, 'Cache-Control: private, no-store'),
    'no certificate schema change required' => !file_exists($root . '/database_migration_certificates.sql'),
];
$failures = 0;
foreach ($checks as $name => $ok) { echo ($ok ? 'PASS' : 'FAIL') . " - $name\n"; if (!$ok) $failures++; }
echo 'Total: ' . count($checks) . '; Passed: ' . (count($checks)-$failures) . '; Failed: ' . $failures . "\n";
exit($failures ? 1 : 0);
