<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = 0;
$failures = [];
$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    $checks++;
    if (!$condition) $failures[] = $message;
};
$inventoryTool = (string) file_get_contents($root . '/tools/migration_tracker.php');
$auditToolPath = $root . '/tools/database_schema_audit.php';
$auditTool = is_file($auditToolPath) ? (string) file_get_contents($auditToolPath) : '';
$assert(is_file($auditToolPath), 'Read-only schema inventory tool exists.');
$assert(str_contains($auditTool, "if (PHP_SAPI !== 'cli')"), 'Schema inventory is CLI-only.');
$assert(str_contains($auditTool, 'information_schema.TABLES'), 'Schema inventory reads table metadata.');
$assert(str_contains($auditTool, 'information_schema.COLUMNS'), 'Schema inventory reads column metadata.');
$assert(str_contains($auditTool, 'information_schema.STATISTICS'), 'Schema inventory reads index metadata.');
$assert(str_contains($auditTool, 'KEY_COLUMN_USAGE'), 'Schema inventory reads foreign-key metadata.');
$assert(!preg_match('/\b(?:INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|DROP\s+TABLE|TRUNCATE\s+TABLE|ALTER\s+TABLE|CREATE\s+TABLE)\b/i', $auditTool), 'Schema inventory contains no schema/data mutation statements.');
$assert(str_contains($auditTool, 'does not inspect row contents'), 'Tool documents that it does not inspect data rows.');
$assert(str_contains($inventoryTool, 'hash_file'), 'Migration tracker computes file checksums.');
$assert(str_contains($inventoryTool, 'files are NOT executed'), 'Migration tracker does not execute migration files.');
$assert(str_contains($inventoryTool, 'CHECKSUM CHANGED'), 'Migration tracker can flag migration file drift.');
$sqlFiles = glob($root . '/database_migration*.sql') ?: [];
$assert(count($sqlFiles) >= 20, 'Incremental migration inventory is present for review.');
$baseMigration = (string) file_get_contents($root . '/database_migration.sql');
$securitySchema = (string) file_get_contents($root . '/security/schema.sql');
$assert(str_contains($baseMigration, 'CREATE TABLE IF NOT EXISTS deposit_requests'), 'Legacy migration defines deposit_requests.');
$assert(str_contains($securitySchema, 'CREATE TABLE IF NOT EXISTS deposit_requests'), 'Security schema also defines deposit_requests; review for schema drift before importing both.');
$assert(str_contains($baseMigration, 'CREATE TABLE IF NOT EXISTS password_reset_tokens'), 'Legacy migration defines password_reset_tokens.');
$assert(str_contains($securitySchema, 'CREATE TABLE IF NOT EXISTS password_reset_tokens'), 'Security schema also defines password_reset_tokens; review for schema drift before importing both.');
$allSql = array_merge($sqlFiles, [$root . '/security/schema.sql']);
$destructive = [];
foreach ($allSql as $path) {
    $sql = (string) file_get_contents($path);
    if (preg_match('/^\s*(?:DROP\s+TABLE|TRUNCATE\s+TABLE|DELETE\s+FROM)\b/im', $sql)) $destructive[] = basename($path);
}
$assert($destructive === [], 'No top-level DROP TABLE, TRUNCATE TABLE, or DELETE FROM found in migration SQL.');
if ($failures !== []) {
    fwrite(STDERR, "Phase 8 database review checks failed: " . count($failures) . " of {$checks}\n");
    foreach ($failures as $failure) fwrite(STDERR, " - {$failure}\n");
    exit(1);
}
echo "Phase 8 database review checks passed: {$checks}\n";
