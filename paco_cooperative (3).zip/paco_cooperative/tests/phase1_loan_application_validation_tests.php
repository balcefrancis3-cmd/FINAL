<?php
/**
 * Phase 1 static regression checks for loan application validation.
 * These checks inspect source contracts; live database/browser tests remain required.
 */
$root = dirname(__DIR__);
$apply = file_get_contents($root . '/member/apply_loan.php');
$engine = file_get_contents($root . '/includes/loan_engine.php');
$checks = [
    'Loan bracket is resolved from active server-side catalog' => str_contains($apply, "WHERE p.status = 'active' AND b.status = 'active'"),
    'Loan amount is parsed into exact centavos' => str_contains($apply, 'pascco_money_input_to_cents($loan_amount_input)'),
    'Requested amount is checked against selected bracket' => str_contains($apply, '$amount_cents < pascco_money_to_cents') && str_contains($apply, '$amount_cents > pascco_money_to_cents'),
    'Monthly income range is enforced' => str_contains($apply, '$selected_bracket[\'minimum_income\']') && str_contains($apply, '$selected_bracket[\'maximum_income\']'),
    'Required savings is checked against active accounts' => str_contains($apply, "SUM(balance), 0) FROM accounts WHERE member_id = ? AND status = 'active'"),
    'Required documents are enforced and MIME-checked' => str_contains($apply, "throw new RuntimeException(\$label . ' is required.')") && str_contains($apply, 'FILEINFO_MIME_TYPE'),
    'Application form has one-time replay nonce' => str_contains($apply, 'application_nonce') && str_contains($apply, 'hash_equals($expectedNonce, $submittedNonce)'),
    'Loan row and audit event use a database transaction' => str_contains($apply, '$pdo->beginTransaction();') && str_contains($apply, '$pdo->commit();') && str_contains($apply, '$pdo->rollBack();'),
    'Loan calculation uses configured term and interest rules' => str_contains($apply, 'pascco_calculate_loan(') && str_contains($apply, '$selected_bracket[\'interest_rate_basis\']'),
    'Unexpected exceptions are logged without exposing internals' => str_contains($apply, 'PASCCO loan application error:') && str_contains($apply, 'The loan application could not be completed.'),
];
$failed = 0;
foreach ($checks as $label => $passed) {
    echo ($passed ? 'PASS: ' : 'FAIL: ') . $label . PHP_EOL;
    if (!$passed) $failed++;
}
echo PHP_EOL . 'Summary: ' . (count($checks) - $failed) . ' passed, ' . $failed . ' failed' . PHP_EOL;
exit($failed === 0 ? 0 : 1);
