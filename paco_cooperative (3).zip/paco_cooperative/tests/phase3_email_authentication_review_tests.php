<?php
$root = dirname(__DIR__);
$checks = [];
function checkPhase3(bool $condition, string $label): void {
    global $checks;
    $checks[] = [$label, $condition];
}
$mail = file_get_contents($root . '/includes/mail_config.php');
$loanMail = file_get_contents($root . '/includes/loan_notifications.php');
$example = file_get_contents($root . '/security/mail-config.example.php');
$memberOtp = file_get_contents($root . '/public/member_otp_verify.php');
$adminOtp = file_get_contents($root . '/public/otp_verify.php');
checkPhase3(str_contains($mail, 'function pascco_configure_mailer'), 'Shared SMTP setup helper exists');
checkPhase3(str_contains($mail, "['encryption'], ['tls', 'ssl', 'none']"), 'SMTP encryption values are allow-listed');
checkPhase3(str_contains($mail, 'SMTPDebug = 0'), 'SMTP protocol debugging is disabled');
checkPhase3(str_contains($mail, 'max(5, min(30'), 'SMTP timeout is bounded');
checkPhase3(!str_contains($mail, "echo 'Mailer Error:'"), 'SMTP errors are not echoed to visitors');
checkPhase3(!str_contains($mail, "Host = 'smtp.gmail.com'"), 'Individual mail functions do not hardcode SMTP host');
checkPhase3(str_contains($loanMail, 'pascco_configure_mailer($mail, $config)'), 'Loan reminders use shared SMTP settings');
checkPhase3(str_contains($example, "'host' => 'smtp.gmail.com'") && str_contains($example, "'encryption' => 'tls'"), 'Private config template documents transport settings');
checkPhase3(str_contains($memberOtp, 'password_verify($otp') && str_contains($memberOtp, 'otp_expires_at'), 'Member email OTP retains hash and expiry validation');
checkPhase3(str_contains($adminOtp, 'pascco_totp') || str_contains($adminOtp, 'pascco_totp_step'), 'Administrator authenticator verification remains present');
$failed = 0;
foreach ($checks as [$label, $passed]) {
    echo ($passed ? 'PASS' : 'FAIL') . " | {$label}\n";
    if (!$passed) $failed++;
}
echo 'TOTAL: ' . count($checks) . ' | PASSED: ' . (count($checks)-$failed) . ' | FAILED: ' . $failed . PHP_EOL;
exit($failed ? 1 : 0);
