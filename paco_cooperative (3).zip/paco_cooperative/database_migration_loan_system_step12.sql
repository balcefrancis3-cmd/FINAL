-- PASCCO Loan System Step 12
-- Controlled execution of an approved restructuring proposal.
-- This creates an immutable execution snapshot and replaces only unpaid schedule rows.
-- Import AFTER Step 11 and only after taking a database backup.

START TRANSACTION;

CREATE TABLE IF NOT EXISTS loan_restructuring_executions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    restructuring_request_id INT UNSIGNED NOT NULL,
    loan_id INT UNSIGNED NOT NULL,
    execution_reference VARCHAR(80) NOT NULL,
    executed_by INT UNSIGNED NOT NULL,
    effective_date DATE NOT NULL,
    previous_total_payable DECIMAL(15,2) NULL,
    previous_remaining_balance DECIMAL(15,2) NOT NULL,
    previous_monthly_payment DECIMAL(15,2) NULL,
    previous_term_months INT UNSIGNED NULL,
    new_total_payable DECIMAL(15,2) NOT NULL,
    new_remaining_balance DECIMAL(15,2) NOT NULL,
    new_monthly_payment DECIMAL(15,2) NOT NULL,
    new_term_months INT UNSIGNED NOT NULL,
    new_maturity_date DATE NOT NULL,
    executed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_restructure_execution_request (restructuring_request_id),
    UNIQUE KEY uq_restructure_execution_reference (execution_reference),
    KEY idx_restructure_execution_loan (loan_id, executed_at),
    CONSTRAINT fk_restructure_execution_request FOREIGN KEY (restructuring_request_id) REFERENCES loan_restructuring_requests(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_restructure_execution_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_restructure_execution_user FOREIGN KEY (executed_by) REFERENCES users(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @restructure_idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_payments' AND INDEX_NAME = 'idx_loan_payments_restructure'
);
SET @sql := IF(
    @restructure_idx_exists = 0,
    'CREATE INDEX idx_loan_payments_restructure ON loan_payments(loan_id, status, payment_number)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

COMMIT;

-- Step 12 does not invent rates, fees, waivers, or restructuring policy.
-- The approved Step 11 proposal supplies the new remaining payable, term, monthly payment, and effective date.
