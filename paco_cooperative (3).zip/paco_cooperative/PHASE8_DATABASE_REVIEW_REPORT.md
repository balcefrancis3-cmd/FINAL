# PASCCO Phase 8 — Database Review

## Scope and safety
- Inventoried the SQL migration files and reviewed the existing migration tracker.
- Added `tools/database_schema_audit.php`, a CLI-only, read-only schema inventory. It reads `information_schema` metadata (tables, columns, indexes, and foreign keys) and does not inspect member or financial row contents.
- Added `tests/phase8_database_review_tests.php` for static checks.
- No migration was executed and no existing database, account, or financial record was changed.

## Findings from static inspection

1. **There is not one authoritative migration file.** The project contains a sequence of loan-system steps, separate settings/security migrations, and later hardening migrations. Apply only the migrations that match the actual database state; do not import every SQL file blindly or assume filenames alone prove application order.
2. **Overlapping table definitions exist.** Both `database_migration.sql` and `security/schema.sql` declare `deposit_requests` and `password_reset_tokens`. Both use `CREATE TABLE IF NOT EXISTS`, which does not reconcile a pre-existing table with a different definition. Compare the live table definitions before applying either file to an existing installation.
3. **The migration tracker is a manual ledger, not a migration runner.** `tools/migration_tracker.php` hashes migration files and can report untracked/changed files, but it cannot prove that the recorded SQL effects exist in the database. Record a migration only after manually applying and verifying it.
4. **Uniqueness hardening needs pre-flight checks.** Step 16 checks for duplicate normalized email values before adding unique keys. If duplicate rows are returned, resolve the records deliberately and back up first; do not delete or merge accounts automatically.
5. **Compatibility must be checked against the installed MariaDB/MySQL version.** Several migrations use `ADD COLUMN IF NOT EXISTS`, `CHECK` constraints, JSON columns, and prepared dynamic DDL. Confirm support in the local server before applying a migration.
6. **No destructive top-level migration statements were found** in the reviewed SQL files for `DROP TABLE`, `TRUNCATE TABLE`, or `DELETE FROM`. This static scan is not a guarantee that a migration is compatible or risk-free.

## Recommended procedure before any schema changes

1. Back up the existing `paco_cooperative` database and verify that the backup can be read.
2. Run `php tools/migration_tracker.php list` from the project directory to see tracked, untracked, and checksum-changed files. Treat it as an inventory only.
3. Run `php tools/database_schema_audit.php` to capture the live table/column/index/foreign-key inventory. This requires the existing private config at `C:/xampp/pascco-private/config.php` and a working local database.
4. Compare the inventory with the intended migration and read that SQL file in full. Resolve duplicate email pre-flight results before Step 16.
5. Apply one migration at a time in a test copy, verify its schema effects, and only then mark it in `schema_migrations`.
6. Do not reset the database, drop/recreate tables, or import the whole migration folder as a batch.

## Verification limits

The static checks can run without the user's local database. The read-only inventory tool was syntax-checked but not run against the user's XAMPP/MariaDB database in this environment. No live schema compatibility or row-level integrity claims are made.
