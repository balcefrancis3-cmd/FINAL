-- PASCCO Settings Foundation - Phase 1
-- Import this migration once into the existing paco_cooperative database.
-- Safe to re-run: CREATE TABLE IF NOT EXISTS and INSERT IGNORE are used.

CREATE TABLE IF NOT EXISTS member_settings (
    user_id INT UNSIGNED NOT NULL,
    theme ENUM('light', 'dark', 'system') NOT NULL DEFAULT 'light',
    text_size ENUM('small', 'medium', 'large') NOT NULL DEFAULT 'medium',
    language_code VARCHAR(10) NOT NULL DEFAULT 'en',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_member_settings_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed settings for existing accounts. New member rows are created lazily by settings.php.
INSERT IGNORE INTO member_settings (user_id)
SELECT id FROM users;
