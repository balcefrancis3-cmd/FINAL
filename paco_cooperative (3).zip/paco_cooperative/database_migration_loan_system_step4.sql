-- PASCCO Loan System - Step 4
-- Controlled recording of external/manual loan payments.
-- Run AFTER Step 1, Step 2, and Step 3, and only after taking a database backup.

START TRANSACTION;

CREATE TABLE IF NOT EXISTS loan_payment_receipts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id INT(11) NOT NULL,
    receipt_number VARCHAR(60) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    external_reference VARCHAR(100) DEFAULT NULL,
    notes VARCHAR(500) DEFAULT NULL,
    received_by INT UNSIGNED DEFAULT NULL,
    received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_receipt_number (receipt_number),
    KEY idx_loan_receipts_loan (loan_id, received_at),
    KEY idx_loan_receipts_reference (external_reference),
    CONSTRAINT chk_loan_receipt_amount CHECK (amount > 0),
    CONSTRAINT fk_loan_receipts_loan
        FOREIGN KEY (loan_id) REFERENCES loans(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_loan_receipts_user
        FOREIGN KEY (received_by) REFERENCES users(id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;

-- Step 4 intentionally does not seed financial values or alter PASCCO rates.
