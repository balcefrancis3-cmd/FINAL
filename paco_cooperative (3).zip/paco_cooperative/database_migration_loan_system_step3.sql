-- PASCCO Loan System - Step 3
-- Loan servicing: payment allocation history and reliable overdue tracking.
-- Run AFTER Step 1 and Step 2, and only after taking a database backup.

START TRANSACTION;

CREATE TABLE IF NOT EXISTS loan_payment_allocations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id INT(11) NOT NULL,
    loan_payment_id BIGINT UNSIGNED NOT NULL,
    reference_number VARCHAR(60) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_by INT UNSIGNED DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_loan_allocations_loan (loan_id, payment_date),
    KEY idx_loan_allocations_schedule (loan_payment_id, payment_date),
    KEY idx_loan_allocations_reference (reference_number),
    CONSTRAINT chk_loan_allocation_amount CHECK (amount > 0),
    CONSTRAINT fk_loan_allocations_loan
        FOREIGN KEY (loan_id) REFERENCES loans(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_loan_allocations_payment
        FOREIGN KEY (loan_payment_id) REFERENCES loan_payments(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_loan_allocations_user
        FOREIGN KEY (processed_by) REFERENCES users(id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE loans
    ADD COLUMN IF NOT EXISTS last_payment_date DATETIME NULL,
    ADD COLUMN IF NOT EXISTS next_due_date DATE NULL;

SET @loan_due_idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loans' AND INDEX_NAME = 'idx_loans_status_due'
);
SET @sql := IF(
    @loan_due_idx_exists = 0,
    'CREATE INDEX idx_loans_status_due ON loans(status, next_due_date)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

COMMIT;

-- Step 3 intentionally does not seed financial values or alter PASCCO rates.
