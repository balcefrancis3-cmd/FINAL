<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

require_admin();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_collection_note') {
    verify_csrf();
    $loanId = (int) ($_POST['loan_id'] ?? 0);
    $contactDate = trim($_POST['contact_date'] ?? '');
    $method = trim($_POST['contact_method'] ?? '');
    $outcome = trim($_POST['outcome'] ?? '');
    $promiseDate = trim($_POST['promise_date'] ?? '');
    $promiseAmount = trim($_POST['promise_amount'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($loanId <= 0 || $contactDate === '' || $method === '' || $outcome === '') {
        $error = 'Loan, contact date, contact method, and outcome are required.';
    } elseif ($promiseAmount !== '' && (($promiseAmountCents = pascco_money_input_to_cents($promiseAmount)) === null || $promiseAmountCents <= 0)) {
        $error = 'Promise amount must be a positive number when provided.';
    } else {
        try {
            $loanCheck = $pdo->prepare("SELECT id, status, remaining_balance FROM loans WHERE id = ? LIMIT 1");
            $loanCheck->execute([$loanId]);
            $loan = $loanCheck->fetch(PDO::FETCH_ASSOC);
            if (!$loan) {
                throw new RuntimeException('Loan not found.');
            }
            if (pascco_money_to_cents((string) $loan['remaining_balance']) <= 0 || $loan['status'] === 'paid') {
                throw new RuntimeException('Collection notes can only be added to a loan with an outstanding balance.');
            }

            $insert = $pdo->prepare('INSERT INTO loan_collection_notes (loan_id, contact_date, contact_method, outcome, promise_date, promise_amount, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $insert->execute([
                $loanId,
                $contactDate,
                $method,
                $outcome,
                $promiseDate !== '' ? $promiseDate : null,
                $promiseAmount !== '' ? pascco_money_from_cents($promiseAmountCents) : null,
                $notes !== '' ? $notes : null,
                (int) $_SESSION['user_id'],
            ]);
            record_audit($pdo, (int) $_SESSION['user_id'], 'loan_collection_note', 'Added collection follow-up note for loan ' . $loanId, 'success');
            $message = 'Collection follow-up recorded successfully.';
        } catch (Throwable $exception) {
            $error = $exception->getMessage();
        }
    }
}

pascco_refresh_overdue_loan_payments($pdo);

$loansStmt = $pdo->query("SELECT l.id, l.loan_number, l.loan_product, l.loan_amount, l.remaining_balance, l.next_due_date, l.last_payment_date, l.status, m.first_name, m.last_name, m.member_number, (SELECT COUNT(*) FROM loan_payments lp WHERE lp.loan_id = l.id AND lp.status = 'overdue') AS overdue_installments, (SELECT MAX(n.contact_date) FROM loan_collection_notes n WHERE n.loan_id = l.id) AS last_contact_date, (SELECT COUNT(*) FROM loan_collection_notes n WHERE n.loan_id = l.id) AS contact_count FROM loans l JOIN members m ON m.id = l.member_id WHERE l.status IN ('active','approved','disbursed') AND l.remaining_balance > 0 AND EXISTS (SELECT 1 FROM loan_payments lp WHERE lp.loan_id = l.id AND lp.amount_paid < lp.amount_due AND lp.status = 'overdue') ORDER BY l.next_due_date ASC, l.id DESC");
$loans = $loansStmt->fetchAll(PDO::FETCH_ASSOC);

$notesStmt = $pdo->query("SELECT n.*, l.loan_number, m.first_name, m.last_name, u.username FROM loan_collection_notes n JOIN loans l ON l.id = n.loan_id JOIN members m ON m.id = l.member_id JOIN users u ON u.id = n.created_by ORDER BY n.id DESC LIMIT 50");
$notesRows = $notesStmt->fetchAll(PDO::FETCH_ASSOC);

$today = new DateTimeImmutable('today');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Loan Collections | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
:root{--navy:#071d49;--blue:#1456a0;--bg:#f4f7fb;--line:#d8e0ee;--muted:#6e7e93;--danger:#a52f37;--green:#247748;--gold:#e7b84b}body{margin:0;background:var(--bg);color:#18324f;font-family:Poppins,Arial,sans-serif}.wrap{width:min(1240px,calc(100% - 32px));margin:30px auto 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}.eyebrow{color:var(--blue);font-size:.73rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.head h1{margin:7px 0;color:var(--navy);font-size:clamp(2rem,4vw,2.7rem)}.head p{margin:0;color:var(--muted);line-height:1.5}.back,.button{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);background:#fff;color:var(--navy);padding:9px 12px;border-radius:9px;text-decoration:none;font-weight:800}.button.primary{background:var(--blue);border-color:var(--blue);color:#fff;cursor:pointer}.msg{padding:12px 14px;border-radius:10px;margin-bottom:16px;font-weight:700}.success{background:#e7f5ec;color:#17673b}.error{background:#fde7e7;color:#9d2933}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:18px}.stat,.panel{background:#fff;border:1px solid var(--line);border-radius:15px}.stat{padding:16px}.stat span{display:block;color:var(--muted);font-size:.7rem;font-weight:800;text-transform:uppercase}.stat strong{display:block;margin-top:7px;color:var(--navy);font-size:1.35rem}.panel{overflow:hidden;margin-bottom:18px}.panel-title{padding:16px 18px;border-bottom:1px solid var(--line);font-weight:900;color:var(--navy)}.table-wrap{overflow:auto}.table{width:100%;min-width:1100px;border-collapse:collapse}.table th,.table td{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.78rem}.table th{background:#eef4fb;color:var(--navy);font-weight:900}.sub{display:block;color:#8794a4;font-size:.69rem;margin-top:3px}.money{color:var(--blue);font-weight:900;white-space:nowrap}.badge{display:inline-block;padding:4px 7px;border-radius:999px;background:#fde7e7;color:var(--danger);font-size:.66rem;font-weight:900;text-transform:uppercase}.actions{display:flex;gap:7px;flex-wrap:wrap}.empty{text-align:center;color:var(--muted);padding:28px}.modal{display:none;position:fixed;inset:0;background:rgba(7,29,73,.45);align-items:center;justify-content:center;padding:20px;z-index:9999}.modal:target{display:flex}.dialog{width:min(620px,100%);max-height:90vh;overflow:auto;background:#fff;border-radius:16px;padding:20px;box-shadow:0 20px 60px rgba(0,0,0,.18)}.dialog h2{margin:0 0 8px;color:var(--navy)}.field{margin:11px 0}.field label{display:block;margin-bottom:6px;color:var(--navy);font-weight:800;font-size:.78rem}.field input,.field select,.field textarea{width:100%;box-sizing:border-box;padding:10px;border:1px solid #cbd7e4;border-radius:9px;font:inherit}.field textarea{min-height:80px;resize:vertical}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}.modal-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:15px}.close{padding:9px 12px;border:1px solid var(--line);border-radius:9px;color:var(--navy);text-decoration:none;font-weight:800}.footnote{color:var(--muted);font-size:.76rem;line-height:1.5}@media(max-width:850px){.head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr}.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>
<?php pascco_admin_header(); ?>
<main class="wrap">
<header class="head"><div><div class="eyebrow">Credit recovery</div><h1>Loan Collections</h1><p>Track overdue loans and record collection follow-ups without changing the financial records.</p></div><a class="back" href="/paco_cooperative/admin/admin_loan_servicing.php"><i class="bx bx-arrow-back"></i> Loan Servicing</a></header>
<?php if($message): ?><div class="msg success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<?php if($error): ?><div class="msg error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<section class="stats"><div class="stat"><span>Overdue Loans</span><strong><?php echo number_format(count($loans)); ?></strong></div><div class="stat"><span>Total Outstanding on Overdue Loans</span><strong>₱<?php echo number_format(array_sum(array_map(fn($r)=>(float)$r['remaining_balance'],$loans)),2); ?></strong></div><div class="stat"><span>Follow-ups Recorded</span><strong><?php echo number_format(count($notesRows)); ?></strong></div></section>
<section class="panel"><div class="panel-title">Overdue Loan Queue</div><div class="table-wrap"><table class="table"><thead><tr><th>Loan</th><th>Member</th><th>Outstanding</th><th>Next Due</th><th>Days Overdue</th><th>Overdue Installments</th><th>Last Contact</th><th>Action</th></tr></thead><tbody>
<?php if($loans): foreach($loans as $loan): $next=$loan['next_due_date']?new DateTimeImmutable($loan['next_due_date']):null; $days=$next?max(0,(int)$next->diff($today)->format('%r%a')):0; ?><tr><td><strong><?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['loan_product'] ?: 'Loan',ENT_QUOTES,'UTF-8'); ?></span></td><td><strong><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['member_number'],ENT_QUOTES,'UTF-8'); ?></span></td><td class="money">₱<?php echo number_format((float)$loan['remaining_balance'],2); ?></td><td><?php echo htmlspecialchars($loan['next_due_date'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td><td><span class="badge"><?php echo number_format($days); ?> day<?php echo $days===1?'':'s'; ?></span></td><td><?php echo number_format((int)$loan['overdue_installments']); ?></td><td><?php echo htmlspecialchars($loan['last_contact_date'] ?: 'No contact recorded',ENT_QUOTES,'UTF-8'); ?><span class="sub"><?php echo number_format((int)$loan['contact_count']); ?> follow-up(s)</span></td><td class="actions"><a class="button" href="/paco_cooperative/member/loan_details.php?loan_id=<?php echo (int)$loan['id']; ?>" target="_blank" rel="noopener">Loan</a><a class="button primary" href="#note-<?php echo (int)$loan['id']; ?>">Add Follow-up</a></td></tr><?php endforeach; else: ?><tr><td colspan="8" class="empty">No overdue loans currently require collection follow-up.</td></tr><?php endif; ?>
</tbody></table></div></section>
<section class="panel"><div class="panel-title">Recent Collection Follow-ups</div><div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Loan</th><th>Method</th><th>Outcome</th><th>Promise</th><th>Notes</th><th>Recorded By</th></tr></thead><tbody><?php if($notesRows): foreach($notesRows as $n): ?><tr><td><?php echo htmlspecialchars($n['contact_date'],ENT_QUOTES,'UTF-8'); ?></td><td><strong><?php echo htmlspecialchars($n['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($n['first_name'].' '.$n['last_name'],ENT_QUOTES,'UTF-8'); ?></span></td><td><?php echo htmlspecialchars($n['contact_method'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($n['outcome'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo $n['promise_date']?htmlspecialchars($n['promise_date'],ENT_QUOTES,'UTF-8'):'—'; ?><?php if($n['promise_amount']!==null): ?><span class="sub">₱<?php echo number_format((float)$n['promise_amount'],2); ?></span><?php endif; ?></td><td><?php echo htmlspecialchars($n['notes'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($n['username'],ENT_QUOTES,'UTF-8'); ?><span class="sub"><?php echo htmlspecialchars($n['created_at'],ENT_QUOTES,'UTF-8'); ?></span></td></tr><?php endforeach; else: ?><tr><td colspan="7" class="empty">No collection follow-ups have been recorded yet.</td></tr><?php endif; ?></tbody></table></div></section>
<p class="footnote">Collection notes are operational records. They do not waive, change, settle, or otherwise modify a loan balance, repayment schedule, interest calculation, or payment status.</p>
</main>
<?php foreach($loans as $loan): ?><div class="modal" id="note-<?php echo (int)$loan['id']; ?>"><div class="dialog"><h2>Follow-up: <?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?></h2><p class="sub">Member: <?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?></p><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="action" value="add_collection_note"><input type="hidden" name="loan_id" value="<?php echo (int)$loan['id']; ?>"><div class="grid2"><div class="field"><label>Contact Date</label><input type="date" name="contact_date" value="<?php echo date('Y-m-d'); ?>" required></div><div class="field"><label>Contact Method</label><select name="contact_method" required><option value="Phone">Phone</option><option value="Email">Email</option><option value="SMS">SMS</option><option value="In Person">In Person</option><option value="Letter">Letter</option><option value="Other">Other</option></select></div></div><div class="field"><label>Outcome</label><input name="outcome" maxlength="100" placeholder="e.g. Contacted member; no answer; payment promised" required></div><div class="grid2"><div class="field"><label>Promise Date</label><input type="date" name="promise_date"></div><div class="field"><label>Promise Amount</label><input type="number" name="promise_amount" step="0.01" min="0.01" placeholder="Optional"></div></div><div class="field"><label>Notes</label><textarea name="notes" maxlength="1000" placeholder="Record the follow-up details"></textarea></div><div class="modal-actions"><a class="close" href="#">Cancel</a><button class="button primary" type="submit">Save Follow-up</button></div></form></div></div><?php endforeach; ?>
</body></html>
