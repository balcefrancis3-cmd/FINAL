<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_admin();

$message = '';
$message_type = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $request_id = (int) ($_POST['request_id'] ?? 0);
    $action = (string) ($_POST['action'] ?? '');
    $notes = trim((string) ($_POST['admin_notes'] ?? ''));

    if ($request_id <= 0 || !in_array($action, ['approve', 'reject'], true)) {
        $message = 'Invalid withdrawal review request.';
        $message_type = 'error';
    } elseif ($action === 'reject' && $notes === '') {
        $message = 'Add a note explaining why the withdrawal was rejected.';
        $message_type = 'error';
    } else {
        try {
            $pdo->beginTransaction();
            $request_stmt = $pdo->prepare("SELECT id, account_id, member_id, amount, description FROM withdrawal_requests WHERE id = ? AND status = 'pending' FOR UPDATE");
            $request_stmt->execute([$request_id]);
            $request = $request_stmt->fetch();
            if (!$request) {
                throw new PasccoUserException('This withdrawal request was already reviewed or could not be found.');
            }

            if ($action === 'reject') {
                $update = $pdo->prepare("UPDATE withdrawal_requests SET status='rejected', admin_notes=?, reviewed_by=?, reviewed_at=NOW() WHERE id=? AND status='pending'");
                $update->execute([substr($notes, 0, 500), (int) $_SESSION['user_id'], $request_id]);
                if ($update->rowCount() !== 1) throw new PasccoUserException('The withdrawal request could not be rejected.');
                $pdo->commit();
                record_audit($pdo, (int) $_SESSION['user_id'], 'withdrawal_rejection', 'Rejected withdrawal request #' . $request_id, 'success');
                $message = 'Withdrawal request rejected. No balance was deducted.';
            } else {
                // Lock account and recheck balance at approval time; pending requests do not reserve funds.
                $account_stmt = $pdo->prepare("SELECT a.balance FROM accounts a JOIN members m ON m.id=a.member_id WHERE a.id=? AND m.id=? AND a.status='active' FOR UPDATE");
                $account_stmt->execute([(int) $request['account_id'], (int) $request['member_id']]);
                $account = $account_stmt->fetch();
                if (!$account) throw new PasccoUserException('The member savings account is no longer active.');
                $withdrawal_cents = pascco_money_to_cents((string) $request['amount']);
                if ($withdrawal_cents > pascco_money_to_cents((string) $account['balance'])) {
                    throw new PasccoUserException('Insufficient available balance. The request remains pending until it can be reviewed or rejected.');
                }

                $reference = 'WDR-' . date('YmdHis') . '-' . bin2hex(random_bytes(4));
                $insert = $pdo->prepare("INSERT INTO transactions (account_id, transaction_type, amount, recipient_account_id, description, status, reference_number, transaction_date, created_at, idempotency_key) VALUES (?, 'withdrawal', ?, NULL, ?, 'completed', ?, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), ?)");
                $tx_key = hash('sha256', 'withdrawal-request:' . $request_id);
                $insert->execute([(int) $request['account_id'], pascco_money_from_cents($withdrawal_cents), (string) $request['description'], $reference, $tx_key]);

                $debit = $pdo->prepare("UPDATE accounts SET balance=balance-? WHERE id=? AND status='active' AND balance >= ?");
                $debit->execute([pascco_money_from_cents($withdrawal_cents), (int) $request['account_id'], pascco_money_from_cents($withdrawal_cents)]);
                if ($debit->rowCount() !== 1) throw new PasccoUserException('The account balance could not be updated. No withdrawal was completed.');

                $update = $pdo->prepare("UPDATE withdrawal_requests SET status='approved', admin_notes=?, reviewed_by=?, reviewed_at=NOW() WHERE id=? AND status='pending'");
                $update->execute([substr($notes, 0, 500), (int) $_SESSION['user_id'], $request_id]);
                if ($update->rowCount() !== 1) throw new PasccoUserException('The request could not be finalized. No withdrawal was completed.');
                $pdo->commit();
                record_audit($pdo, (int) $_SESSION['user_id'], 'withdrawal_approval', 'Approved withdrawal request #' . $request_id . ' reference ' . $reference, 'success');
                $message = 'Withdrawal approved and deducted from the simulated account balance.';
            }
        } catch (PasccoUserException $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $message = $exception->getMessage();
            $message_type = 'error';
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            pascco_log_exception($exception, 'admin_withdrawal_review');
            $message = 'The withdrawal review could not be completed. Please try again later.';
            $message_type = 'error';
        }
    }
}

$requests_stmt = $pdo->query("SELECT w.*, a.account_number, m.first_name, m.last_name, m.member_number FROM withdrawal_requests w JOIN accounts a ON a.id=w.account_id JOIN members m ON m.id=w.member_id ORDER BY (w.status='pending') DESC, w.created_at DESC LIMIT 200");
$requests = $requests_stmt->fetchAll();
?>
<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><?php pascco_global_styles(); ?><title>Withdrawal Reviews | PASCCO Admin</title>
<style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb}body{margin:0;background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Arial,sans-serif}.wrap{width:min(100% - 32px,1180px);margin:0 auto;padding:32px 0 56px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:22px}.head h1{margin:6px 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem)}.head p{margin:0;color:var(--muted)}.panel{background:#fff;border:1px solid #e0e7f0;border-radius:18px;padding:20px;box-shadow:0 14px 36px rgba(7,29,73,.06)}.notice{padding:13px 15px;border-radius:10px;margin-bottom:16px;font-weight:700}.success{background:#eaf8f0;color:#176b3a}.error{background:#fff0f0;color:#a73535}.request{padding:17px 0;border-bottom:1px solid var(--line)}.request:last-child{border-bottom:0}.top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.top h2{font-size:1rem;margin:0;color:var(--navy)}.meta{color:var(--muted);font-size:.8rem;margin-top:5px}.amount{font-weight:800;color:var(--blue);white-space:nowrap}.status{display:inline-block;padding:5px 9px;border-radius:99px;font-size:.72rem;font-weight:800;background:#fff0bf;color:#8a6500}.status.approved{background:#e4f6ea;color:#17673b}.status.rejected{background:#fde7e7;color:#a52f37}.details{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:15px 0}.details small{display:block;color:var(--muted);font-size:.73rem}.details strong{display:block;margin-top:4px;overflow-wrap:anywhere}.form{display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end}.form textarea{flex:1;min-width:220px;min-height:42px;padding:10px;border:1px solid #cbd6e3;border-radius:9px;font:inherit}.form button,.back{border:0;border-radius:9px;padding:11px 14px;font-weight:800;cursor:pointer;text-decoration:none}.approve{background:#267748;color:#fff}.reject{background:#b8323b;color:#fff}.back{display:inline-block;background:#fff;border:1px solid var(--line);color:var(--navy)}.empty{padding:28px;text-align:center;color:var(--muted);background:#f8fbff;border-radius:12px}@media(max-width:650px){.head,.top{align-items:flex-start;flex-direction:column}.details{grid-template-columns:1fr}.form{align-items:stretch;flex-direction:column}.form textarea{min-width:0}}
</style></head><body><?php pascco_admin_header(); ?><main class="wrap"><section class="head"><div><div style="color:var(--blue);font-weight:800;letter-spacing:.12em;font-size:.75rem">SIMULATION TRANSACTIONS</div><h1>Withdrawal Reviews</h1><p>Review requests before simulated funds are deducted from member balances.</p></div><a class="back" href="/paco_cooperative/admin/admin_dashboard.php">← Dashboard</a></section>
<?php if($message!==''): ?><div class="notice <?php echo $message_type==='error'?'error':'success'; ?>"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<section class="panel"><h2 style="margin:0 0 6px;color:var(--navy)">Withdrawal request queue</h2><p style="margin:0 0 18px;color:var(--muted);font-size:.88rem">Pending requests appear first. Approval rechecks the latest available balance.</p>
<?php if($requests): foreach($requests as $request): ?><article class="request"><div class="top"><div><h2><?php echo htmlspecialchars($request['first_name'].' '.$request['last_name'],ENT_QUOTES,'UTF-8'); ?></h2><div class="meta">Request #<?php echo (int)$request['id']; ?> · <?php echo htmlspecialchars($request['member_number'],ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars((string)$request['created_at'],ENT_QUOTES,'UTF-8'); ?></div></div><div class="amount">₱<?php echo number_format((float)$request['amount'],2); ?><div style="text-align:right;margin-top:7px"><span class="status <?php echo htmlspecialchars($request['status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo strtoupper(htmlspecialchars($request['status'],ENT_QUOTES,'UTF-8')); ?></span></div></div></div><div class="details"><div><small>Account</small><strong><?php echo htmlspecialchars($request['account_number'],ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Description</small><strong><?php echo htmlspecialchars($request['description'],ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Submitted</small><strong><?php echo htmlspecialchars((string)$request['created_at'],ENT_QUOTES,'UTF-8'); ?></strong></div></div>
<?php if($request['status']==='pending'): ?><form method="post" class="form"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars((string)($_SESSION['csrf_token']??''),ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="request_id" value="<?php echo (int)$request['id']; ?>"><textarea name="admin_notes" maxlength="500" placeholder="Optional approval note; required if rejecting"></textarea><button class="approve" type="submit" name="action" value="approve">Approve & Deduct</button><button class="reject" type="submit" name="action" value="reject">Reject Request</button></form><?php else: ?><div class="meta">Reviewed <?php echo htmlspecialchars((string)($request['reviewed_at']??''),ENT_QUOTES,'UTF-8'); ?><?php if(!empty($request['admin_notes'])): ?> · Note: <?php echo htmlspecialchars($request['admin_notes'],ENT_QUOTES,'UTF-8'); ?><?php endif; ?></div><?php endif; ?></article><?php endforeach; else: ?><div class="empty">No withdrawal requests yet.</div><?php endif; ?></section></main><?php pascco_global_footer(); ?></body></html>
