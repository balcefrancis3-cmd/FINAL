<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

require_admin();

$message = '';
$messageType = 'success';
$adminId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    verify_csrf();
    $loanId = (int) ($_POST['loan_id'] ?? 0);
    $action = $_POST['action'];
    $notes = trim($_POST['notes'] ?? '');

    try {
        $pdo->beginTransaction();
        $loanStmt = $pdo->prepare("SELECT l.id, l.loan_number, l.status, l.required_approvals, l.loan_amount, l.remaining_balance, l.member_id, l.loan_product_id, l.loan_bracket_id, l.monthly_income, m.first_name, m.last_name FROM loans l JOIN members m ON m.id = l.member_id WHERE l.id = ? AND l.status = 'under_review' FOR UPDATE");
        $loanStmt->execute([$loanId]);
        $loan = $loanStmt->fetch(PDO::FETCH_ASSOC);
        if (!$loan) {
            throw new PasccoUserException('This loan is not currently awaiting administrator approval.');
        }

        $existingStmt = $pdo->prepare("SELECT id, decision FROM loan_approval_reviews WHERE loan_id = ? AND reviewer_id = ? LIMIT 1");
        $existingStmt->execute([$loanId, $adminId]);
        if ($existingStmt->fetch(PDO::FETCH_ASSOC)) {
            throw new PasccoUserException('A decision has already been recorded for this loan.');
        }

        if (!in_array($action, ['approve','reject'], true)) {
            throw new PasccoUserException('Invalid loan approval action.');
        }
        if ($action === 'reject' && $notes === '') {
            throw new PasccoUserException('A rejection reason is required.');
        }

        // Recheck current eligibility immediately before final approval/disbursement.
        // The member's savings or active bracket may have changed since application review.
        if ($action === 'approve') {
            if (empty($loan['loan_product_id']) || empty($loan['loan_bracket_id'])) {
                throw new PasccoUserException('This loan has no configured bracket. It cannot be approved until its configuration is reviewed.');
            }
            $bracketStmt = $pdo->prepare("SELECT b.minimum_amount, b.maximum_amount, b.minimum_income, b.maximum_income, b.required_savings FROM loan_products p JOIN loan_brackets b ON b.loan_product_id = p.id WHERE p.id = ? AND b.id = ? AND p.status = 'active' AND b.status = 'active' LIMIT 1");
            $bracketStmt->execute([(int)$loan['loan_product_id'], (int)$loan['loan_bracket_id']]);
            $bracket = $bracketStmt->fetch(PDO::FETCH_ASSOC);
            if (!$bracket) {
                throw new PasccoUserException('The loan product or bracket is no longer active. Review the configuration before approval.');
            }
            $amountCents = pascco_money_to_cents((string)$loan['loan_amount']);
            if ($amountCents === null || $amountCents < pascco_money_to_cents((string)$bracket['minimum_amount']) || $amountCents > pascco_money_to_cents((string)$bracket['maximum_amount'])) {
                throw new PasccoUserException('The requested amount no longer satisfies the configured loan bracket.');
            }
            $incomeCents = pascco_money_to_cents((string)$loan['monthly_income']);
            if ($incomeCents === null || ($bracket['minimum_income'] !== null && $incomeCents < pascco_money_to_cents((string)$bracket['minimum_income'])) || ($bracket['maximum_income'] !== null && $incomeCents > pascco_money_to_cents((string)$bracket['maximum_income']))) {
                throw new PasccoUserException('The declared income no longer satisfies the configured loan bracket.');
            }
            if ($bracket['required_savings'] !== null) {
                $savingsStmt = $pdo->prepare("SELECT COALESCE(SUM(balance), 0) FROM accounts WHERE member_id = ? AND status = 'active'");
                $savingsStmt->execute([(int)$loan['member_id']]);
                $savingsCents = pascco_money_to_cents((string)$savingsStmt->fetchColumn());
                if ($savingsCents === null || $savingsCents < pascco_money_to_cents((string)$bracket['required_savings'])) {
                    throw new PasccoUserException('The member no longer meets the required active-savings threshold.');
                }
            }
        }

        $decision = $action === 'approve' ? 'approved' : 'rejected';
        $insert = $pdo->prepare('INSERT INTO loan_approval_reviews (loan_id, reviewer_id, decision, notes, reviewed_at) VALUES (?, ?, ?, ?, NOW())');
        $insert->execute([$loanId, $adminId, $decision, $notes !== '' ? $notes : null]);

        if ($decision === 'rejected') {
            $update = $pdo->prepare("UPDATE loans SET status = 'rejected', rejection_reason = ?, committee_completed_at = NOW() WHERE id = ? AND status = 'under_review'");
            $update->execute([$notes, $loanId]);
            if ($update->rowCount() !== 1) {
                throw new RuntimeException('The loan status could not be updated.');
            }
            $pdo->commit();
            record_audit($pdo, $adminId, 'loan_committee_rejection', 'Rejected loan ' . $loanId . ' during committee review', 'success');
            $message = 'Loan application rejected by the administrator.';
        } else {
            $required = 1; // PASCCO currently has one authorized administrator.
            $countStmt = $pdo->prepare("SELECT COUNT(*) FROM loan_approval_reviews WHERE loan_id = ? AND decision = 'approved'");
            $countStmt->execute([$loanId]);
            $approvedCount = (int) $countStmt->fetchColumn();

            if ($approvedCount >= $required) {
                pascco_finalize_loan_committee_approval($pdo, $loanId, $required, $adminId);
                $pdo->commit();
                record_audit($pdo, $adminId, 'loan_committee_final_approval', 'Final administrator approval, disbursement, and scheduling for loan ' . $loanId, 'success');
                $message = 'Loan approved, simulated funds disbursed, and repayment schedule created.';
            } else {
                $pdo->commit();
                record_audit($pdo, $adminId, 'loan_committee_approval', 'Approved loan ' . $loanId . ' as the authorized administrator (' . $approvedCount . '/' . $required . ')', 'success');
                $message = 'Approval recorded. The loan remains in the queue until the required decision is completed.';
            }
        }
    } catch (PasccoUserException $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $message = $exception->getMessage();
        $messageType = 'error';
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        pascco_log_exception($exception, 'admin_loan_approval');
        $message = 'The loan decision could not be completed. Please try again later.';
        $messageType = 'error';
    }
}

$loanQuery = "SELECT l.id AS loan_id, l.loan_number, l.loan_product, l.loan_amount, l.remaining_balance, l.required_approvals, l.committee_submitted_at, l.identity_status, m.first_name, m.last_name, m.member_number, (SELECT COUNT(*) FROM loan_approval_reviews r WHERE r.loan_id = l.id AND r.decision = 'approved') AS approval_count FROM loans l JOIN members m ON m.id = l.member_id WHERE l.status = 'under_review' ORDER BY l.committee_submitted_at ASC, l.id ASC";
$loans = $pdo->query($loanQuery)->fetchAll(PDO::FETCH_ASSOC);

$reviewStmt = $pdo->prepare("SELECT r.loan_id, r.decision, r.notes, r.reviewed_at, u.username FROM loan_approval_reviews r JOIN users u ON u.id = r.reviewer_id WHERE r.loan_id = ? ORDER BY r.reviewed_at ASC, r.id ASC");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<?php pascco_global_styles(); ?>
<title>Loan Approval Queue | PASCCO Admin</title>
<style>
:root{--navy:#071d49;--blue:#1456a0;--blue2:#2b74c8;--gold:#e7b84b;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb;--success:#267748;--danger:#b8323b;--shadow:0 16px 40px rgba(7,29,73,.08)}
html,body{margin:0!important;padding:0!important;overflow-x:hidden}body{background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Poppins,Arial,sans-serif}.wrap{width:min(100% - 40px,1200px);margin:auto;padding:34px 0 58px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:22px}.eyebrow{display:inline-flex;gap:8px;color:var(--blue);font-size:.74rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.eyebrow:before{content:"";width:28px;height:3px;background:var(--gold);border-radius:99px}.head h1{margin:8px 0 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem)}.head p{margin:8px 0 0;color:var(--muted)}.button{display:inline-flex;align-items:center;gap:7px;padding:11px 15px;border-radius:11px;background:#fff;border:1px solid #cdd8e5;color:var(--navy);text-decoration:none;font-weight:800}.notice{padding:13px 15px;border-radius:12px;margin-bottom:18px;font-weight:700}.notice.success{background:#eaf8f0;border:1px solid #cfe9d9;color:#216c40}.notice.error{background:#fff0f0;border:1px solid #f0cfd0;color:#a52f37}.list{display:grid;gap:14px}.card{background:#fff;border:1px solid rgba(7,29,73,.08);border-radius:18px;box-shadow:var(--shadow);padding:20px}.top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.top h2{margin:0;color:var(--navy);font-size:1.1rem}.meta{margin:5px 0 0;color:var(--muted);font-size:.82rem}.amount{color:var(--blue);font-weight:800;white-space:nowrap}.progress{margin:16px 0}.progress-label{display:flex;justify-content:space-between;color:var(--muted);font-size:.78rem;font-weight:800}.bar{height:9px;background:#e7edf5;border-radius:99px;overflow:hidden;margin-top:7px}.bar span{display:block;height:100%;background:var(--blue);border-radius:99px}.details{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px}.detail{padding:12px;border:1px solid var(--line);border-radius:12px;background:#f8fbff}.detail small{display:block;color:#8190a2;font-size:.68rem}.detail strong{display:block;margin-top:4px;color:var(--navy);font-size:.82rem}.reviews{margin-top:14px;padding:14px;border:1px solid var(--line);border-radius:14px;background:#fbfdff}.reviews h3{margin:0 0 10px;color:var(--navy);font-size:.9rem}.review{padding:9px 0;border-top:1px solid var(--line);font-size:.8rem}.review:first-child{border-top:0}.review strong{color:var(--navy)}.review span{color:var(--muted)}.review p{margin:4px 0 0;color:var(--muted);white-space:pre-line}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:15px}.actions form{display:flex;gap:8px;flex:1;min-width:280px}.actions textarea{flex:1;min-height:44px;padding:10px;border:1px solid #cad6e3;border-radius:10px;font:inherit;resize:vertical}.btn{border:0;border-radius:10px;padding:10px 14px;font:inherit;font-weight:800;cursor:pointer}.approve{background:var(--success);color:#fff}.reject{background:var(--danger);color:#fff}.empty{padding:28px;text-align:center;color:var(--muted);background:#fff;border:1px dashed #cdd9e5;border-radius:15px}@media(max-width:800px){.wrap{width:min(100% - 28px,1200px);padding-top:24px}.head{align-items:flex-start;flex-direction:column}.details{grid-template-columns:1fr 1fr}.actions form{min-width:0;flex-direction:column}}@media(max-width:520px){.details{grid-template-columns:1fr}.top{flex-direction:column}.amount{white-space:normal}.actions form{width:100%}}
</style>
</head><body>
<?php pascco_admin_header(); ?>
<main class="wrap">
<section class="head"><div><div class="eyebrow">Credit governance</div><h1>Loan Approval Queue</h1><p>Review verified loan applications. PASCCO simulation uses one authorized administrator; approval triggers simulated disbursement and scheduling.</p></div><a class="button" href="/paco_cooperative/admin/admin_loans.php"><i class="bx bx-arrow-back"></i> Loan Approvals</a></section>
<?php if($message): ?><div class="notice <?php echo $messageType==='error'?'error':'success'; ?>"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<?php if(!$loans): ?><div class="empty">No loans are currently waiting for administrator approval.</div><?php else: ?><div class="list">
<?php foreach($loans as $loan): $required=1; $count=(int)$loan['approval_count']; $percent=min(100,(int)round(($count/$required)*100)); $reviewStmt->execute([(int)$loan['loan_id']]); $reviews=$reviewStmt->fetchAll(PDO::FETCH_ASSOC); ?>
<article class="card"><div class="top"><div><h2><?php echo htmlspecialchars($loan['loan_product'] ?: 'Loan',ENT_QUOTES,'UTF-8'); ?></h2><p class="meta"><?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars($loan['member_number'],ENT_QUOTES,'UTF-8'); ?></p></div><div class="amount">₱<?php echo number_format((float)$loan['loan_amount'],2); ?></div></div><div class="progress"><div class="progress-label"><span>Administrator approval</span><span><?php echo $count; ?>/<?php echo $required; ?></span></div><div class="bar"><span style="width:<?php echo $percent; ?>%"></span></div></div><div class="details"><div class="detail"><small>Member</small><strong><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?></strong></div><div class="detail"><small>Loan Amount</small><strong>₱<?php echo number_format((float)$loan['loan_amount'],2); ?></strong></div><div class="detail"><small>Submitted</small><strong><?php echo htmlspecialchars($loan['committee_submitted_at'] ?: '-',ENT_QUOTES,'UTF-8'); ?></strong></div><div class="detail"><small>Approvals Needed</small><strong><?php echo max(0,$required-$count); ?> more</strong></div></div><div class="reviews"><h3>Decision History</h3><?php if(!$reviews): ?><div class="review"><span>No administrator decision has been recorded yet.</span></div><?php else: foreach($reviews as $review): ?><div class="review"><strong><?php echo htmlspecialchars($review['username'],ENT_QUOTES,'UTF-8'); ?></strong> · <span><?php echo htmlspecialchars(strtoupper($review['decision']),ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars($review['reviewed_at'],ENT_QUOTES,'UTF-8'); ?></span><?php if($review['notes']): ?><p><?php echo htmlspecialchars($review['notes'],ENT_QUOTES,'UTF-8'); ?></p><?php endif; ?></div><?php endforeach; endif; ?></div><div class="actions"><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="loan_id" value="<?php echo (int)$loan['loan_id']; ?>"><textarea name="notes" placeholder="Optional approval note"></textarea><button class="btn approve" type="submit" name="action" value="approve"><i class="bx bx-check"></i> Approve</button></form><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="loan_id" value="<?php echo (int)$loan['loan_id']; ?>"><textarea name="notes" placeholder="Rejection reason (required)"></textarea><button class="btn reject" type="submit" name="action" value="reject"><i class="bx bx-x"></i> Reject</button></form></div></article>
<?php endforeach; ?></div><?php endif; ?>
</main>
<?php pascco_global_footer(); ?>
</body></html>
