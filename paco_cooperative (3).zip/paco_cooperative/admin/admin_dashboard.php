<?php

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

// Restrict access to Admin role only
require_admin();

// 1. Fetch Total Cooperative Savings
$savings_stmt = $pdo->query("SELECT SUM(balance) AS total_savings FROM accounts");
$total_savings = $savings_stmt->fetch()['total_savings'] ?? 0;

// 2. Fetch Total Outstanding Loans
$loans_stmt = $pdo->query("SELECT SUM(remaining_balance) AS total_loans FROM loans WHERE status IN ('approved','disbursed','active')");
$total_loans = $loans_stmt->fetch()['total_loans'] ?? 0;

// 3. Fetch Total Active Members
$members_stmt = $pdo->query("SELECT COUNT(*) AS total_members FROM members");
$total_members = $members_stmt->fetch()['total_members'] ?? 0;

// 4. Fetch Count of Pending Loan Applications
$pending_stmt = $pdo->query("SELECT COUNT(*) AS pending_count FROM loans WHERE status = 'pending'");
$pending_count = $pending_stmt->fetch()['pending_count'] ?? 0;
$committee_count = 0;
try {
    $committee_count = (int) $pdo->query("SELECT COUNT(*) FROM loans WHERE status = 'under_review'")->fetchColumn();
} catch (PDOException $exception) {
}
$pending_deposits = 0;
try {
    $pending_deposits = (int) $pdo->query("SELECT COUNT(*) FROM deposit_requests WHERE status = 'pending'")->fetchColumn();
} catch (PDOException $exception) {
}

$pending_withdrawals = 0;
try {
    $pending_withdrawals = (int) $pdo->query("SELECT COUNT(*) FROM withdrawal_requests WHERE status = 'pending'")->fetchColumn();
} catch (PDOException $exception) {
    pascco_log_exception($exception, 'admin_dashboard_pending_withdrawals');
}

$pending_account_requests = 0;
try {
    $pending_account_requests = (int) $pdo->query("SELECT COUNT(*) FROM account_requests WHERE status = 'pending'")->fetchColumn();
} catch (PDOException $exception) {
}

// 5. Fetch loan status summary for operational monitoring.
$loan_status_stmt = $pdo->query("SELECT status, COUNT(*) AS total FROM loans GROUP BY status");
$loan_status = ['pending' => 0, 'under_review' => 0, 'approved' => 0, 'disbursed' => 0, 'active' => 0, 'rejected' => 0, 'paid' => 0];
foreach ($loan_status_stmt->fetchAll() as $row) {
    $loan_status[$row['status']] = (int) $row['total'];
}

// 6. Fetch recent applications and newly registered members.
$recent_loans_stmt = $pdo->query("
    SELECT l.id AS loan_id, l.loan_number, l.loan_amount, l.status, l.application_date,
           m.first_name, m.last_name, m.member_number
    FROM loans l
    JOIN members m ON m.id = l.member_id
    ORDER BY l.id DESC LIMIT 6
");
$recent_loans = $recent_loans_stmt->fetchAll();

$recent_members_stmt = $pdo->query("
    SELECT member_number, first_name, last_name, email, created_at
    FROM members
    ORDER BY id DESC LIMIT 6
");
$recent_members = $recent_members_stmt->fetchAll();

$transaction_count = (int) $pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn();

$overdue_loans = 0;
try {
    require_once __DIR__ . '/../includes/loan_engine.php';
    pascco_refresh_overdue_loan_payments($pdo);
    $overdue_loans = (int) $pdo->query("SELECT COUNT(*) FROM loans WHERE status = 'active' AND EXISTS (SELECT 1 FROM loan_payments lp WHERE lp.loan_id = loans.id AND lp.status = 'overdue')")->fetchColumn();
} catch (Throwable $exception) {
    $overdue_loans = 0;
}

// Phase 5: chart summaries use live database data for the most recent six calendar months.
// Each chart query is isolated so an optional/missing schema element does not break the dashboard.
$chart_months = [];
for ($i = 5; $i >= 0; $i--) {
    $month = new DateTimeImmutable('first day of this month');
    $month = $month->modify('-' . $i . ' months');
    $key = $month->format('Y-m');
    $chart_months[$key] = ['label' => $month->format('M'), 'members' => 0, 'applications' => 0];
}
try {
    $memberTrend = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, COUNT(*) AS total FROM members WHERE created_at >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 5 MONTH) GROUP BY month_key")->fetchAll();
    foreach ($memberTrend as $trend) {
        if (isset($chart_months[$trend['month_key']])) $chart_months[$trend['month_key']]['members'] = (int) $trend['total'];
    }
} catch (Throwable $exception) {
    pascco_log_exception($exception, 'admin_dashboard_member_chart');
}
try {
    $loanTrend = $pdo->query("SELECT DATE_FORMAT(application_date, '%Y-%m') AS month_key, COUNT(*) AS total FROM loans WHERE application_date >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 5 MONTH) GROUP BY month_key")->fetchAll();
    foreach ($loanTrend as $trend) {
        if (isset($chart_months[$trend['month_key']])) $chart_months[$trend['month_key']]['applications'] = (int) $trend['total'];
    }
} catch (Throwable $exception) {
    pascco_log_exception($exception, 'admin_dashboard_loan_chart');
}
$member_chart_max = max(1, ...array_column($chart_months, 'members'));
$loan_chart_max = max(1, ...array_column($chart_months, 'applications'));
$loan_status_chart = array_filter($loan_status, static fn($count) => $count > 0);
$loan_status_chart_total = max(1, array_sum($loan_status_chart));

// Dashboard priority indicators use the same already-available counts.
$needs_attention = $pending_count + $pending_deposits + $pending_withdrawals + $pending_account_requests + $overdue_loans + $committee_count;

// 7. Fetch Recent Audit Logs
$audit_stmt = $pdo->query("
    SELECT a.action, a.description, a.ip_address, a.created_at, a.status, u.username 
    FROM audit_logs a 
    LEFT JOIN users u ON a.user_id = u.id 
    ORDER BY a.id DESC LIMIT 10
");
$audit_logs = $audit_stmt->fetchAll();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
<title>Admin Dashboard | PASCCO</title>

<link rel="stylesheet" href="../assets/css/pascco-admin-dashboard-phase4.css?v=2">
<link rel="stylesheet" href="../assets/css/pascco-admin-dashboard-phase3.css?v=1">


</head>
<body>
<?php pascco_admin_header(); ?>

<main class="admin-wrap pascco-admin-dashboard-phase3">
<section class="page-head pascco-admin-reveal"><div><div class="eyebrow">Administration</div><h1>Admin Dashboard</h1><p>Monitor cooperative activity, member services, approvals, and recent system activity from one place.</p></div><div class="head-actions"><a class="button secondary" href="/paco_cooperative/admin/admin_members.php"><i class="bx bx-group"></i> Members</a><a class="button secondary" href="/paco_cooperative/admin/admin_announcements.php"><i class="bx bx-megaphone"></i> Announcements</a></div></section>
<section class="priority-banner pascco-admin-reveal pascco-admin-priority">
    <div class="priority-copy">
        <span class="priority-kicker"><i class="bx bx-pulse"></i> Administration overview</span>
        <h2>Today at a glance</h2>
        <p><?php echo $needs_attention > 0 ? 'There are '.$needs_attention.' items that may need administrative attention.' : 'Everything is currently clear. There are no pending workflow items.'; ?></p>
    </div>
    <div class="priority-count <?php echo $needs_attention > 0 ? 'has-items' : 'clear'; ?>">
        <strong><?php echo number_format($needs_attention); ?></strong>
        <span>Needs attention</span>
    </div>
</section>

<section class="stat-grid pascco-admin-stagger-group">
<div class="stat gold pascco-admin-stagger-item"><div class="label">Total Member Savings</div><div class="value pascco-admin-count-up" data-value="<?php echo htmlspecialchars((string)(float)$total_savings, ENT_QUOTES, 'UTF-8'); ?>" data-prefix="₱" data-decimals="2">₱<?php echo number_format($total_savings,2); ?></div><span class="stat-note">Current account balances</span></div>
<div class="stat gold pascco-admin-stagger-item"><div class="label">Outstanding Loans</div><div class="value pascco-admin-count-up" data-value="<?php echo htmlspecialchars((string)(float)$total_loans, ENT_QUOTES, 'UTF-8'); ?>" data-prefix="₱" data-decimals="2">₱<?php echo number_format($total_loans,2); ?></div><span class="stat-note">Approved, disbursed &amp; active</span></div>
<div class="stat blue pascco-admin-stagger-item"><div class="label">Registered Members</div><div class="value pascco-admin-count-up" data-value="<?php echo (int)$total_members; ?>" data-prefix="" data-decimals="0"><?php echo number_format($total_members); ?></div><span class="stat-note">Cooperative membership</span></div>
<div class="stat blue pascco-admin-stagger-item"><div class="label">Transactions</div><div class="value pascco-admin-count-up" data-value="<?php echo (int)$transaction_count; ?>" data-prefix="" data-decimals="0"><?php echo number_format($transaction_count); ?></div><span class="stat-note">Recorded financial activity</span></div>
</section>

<section class="attention-grid pascco-admin-stagger-group">
    <a class="attention-card danger pascco-admin-stagger-item pascco-admin-attention-card <?php echo $overdue_loans > 0 ? 'has-attention' : ''; ?>" href="/paco_cooperative/admin/admin_loan_collections.php">
        <span class="attention-icon"><i class="bx bx-error-circle"></i></span>
        <span><strong><?php echo number_format($overdue_loans); ?></strong><small>Overdue loans</small></span>
        <i class="bx bx-chevron-right attention-arrow"></i>
    </a>
    <a class="attention-card warning pascco-admin-stagger-item pascco-admin-attention-card <?php echo $pending_count > 0 ? 'has-attention' : ''; ?>" href="/paco_cooperative/admin/admin_loans.php">
        <span class="attention-icon"><i class="bx bx-file"></i></span>
        <span><strong><?php echo number_format($pending_count); ?></strong><small>Pending loan requests</small></span>
        <i class="bx bx-chevron-right attention-arrow"></i>
    </a>
    <a class="attention-card warning pascco-admin-stagger-item pascco-admin-attention-card <?php echo $pending_deposits > 0 ? 'has-attention' : ''; ?>" href="/paco_cooperative/admin/admin_deposits.php">
        <span class="attention-icon"><i class="bx bx-wallet"></i></span>
        <span><strong><?php echo number_format($pending_deposits); ?></strong><small>Deposit reviews</small></span>
        <i class="bx bx-chevron-right attention-arrow"></i>
    </a>
    <a class="attention-card warning pascco-admin-stagger-item pascco-admin-attention-card <?php echo $pending_withdrawals > 0 ? 'has-attention' : ''; ?>" href="/paco_cooperative/admin/admin_withdrawals.php">
        <span class="attention-icon"><i class="bx bx-wallet"></i></span>
        <span><strong><?php echo number_format($pending_withdrawals); ?></strong><small>Withdrawal reviews</small></span>
        <i class="bx bx-chevron-right attention-arrow"></i>
    </a>
    <a class="attention-card warning pascco-admin-stagger-item pascco-admin-attention-card <?php echo $pending_account_requests > 0 ? 'has-attention' : ''; ?>" href="/paco_cooperative/admin/admin_account_requests.php">
        <span class="attention-icon"><i class="bx bx-user-plus"></i></span>
        <span><strong><?php echo number_format($pending_account_requests); ?></strong><small>Account requests</small></span>
        <i class="bx bx-chevron-right attention-arrow"></i>
    </a>
</section>
<section class="chart-grid pascco-admin-section-stagger" aria-label="Cooperative charts">
    <article class="surface chart-panel pascco-admin-reveal">
        <div class="surface-head"><div><h2>Membership registrations</h2><p>New member records by month · last 6 months</p></div><span class="chart-key"><i class="key-dot member-dot"></i> Members</span></div>
        <div class="surface-body"><div class="bar-chart" role="img" aria-label="Monthly member registrations chart">
        <?php foreach ($chart_months as $month): $height = max(2, (int) round(($month['members'] / $member_chart_max) * 100)); ?>
            <div class="bar-column"><div class="bar-value"><?php echo number_format($month['members']); ?></div><div class="bar-track"><div class="bar-fill member-fill" style="height:<?php echo $height; ?>%"></div></div><div class="bar-label"><?php echo htmlspecialchars($month['label'], ENT_QUOTES, 'UTF-8'); ?></div></div>
        <?php endforeach; ?>
        </div></div>
    </article>
    <article class="surface chart-panel pascco-admin-reveal">
        <div class="surface-head"><div><h2>Loan applications</h2><p>Applications submitted by month · last 6 months</p></div><span class="chart-key"><i class="key-dot loan-dot"></i> Applications</span></div>
        <div class="surface-body"><div class="bar-chart" role="img" aria-label="Monthly loan applications chart">
        <?php foreach ($chart_months as $month): $height = max(2, (int) round(($month['applications'] / $loan_chart_max) * 100)); ?>
            <div class="bar-column"><div class="bar-value"><?php echo number_format($month['applications']); ?></div><div class="bar-track"><div class="bar-fill loan-fill" style="height:<?php echo $height; ?>%"></div></div><div class="bar-label"><?php echo htmlspecialchars($month['label'], ENT_QUOTES, 'UTF-8'); ?></div></div>
        <?php endforeach; ?>
        </div></div>
    </article>
    <article class="surface chart-panel loan-status-chart pascco-admin-reveal">
        <div class="surface-head"><div><h2>Loan status distribution</h2><p>All recorded loan applications</p></div></div>
        <div class="surface-body">
        <?php if ($loan_status_chart): foreach ($loan_status_chart as $status => $count): $share = (int) round(($count / $loan_status_chart_total) * 100); ?>
            <div class="status-bar-row"><div class="status-bar-label"><span><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $status)), ENT_QUOTES, 'UTF-8'); ?></span><strong><?php echo number_format($count); ?> <small><?php echo $share; ?>%</small></strong></div><div class="status-bar-track"><div class="status-bar-fill status-<?php echo htmlspecialchars((string) $status, ENT_QUOTES, 'UTF-8'); ?>" style="width:<?php echo $share; ?>%"></div></div></div>
        <?php endforeach; else: ?><div class="empty">No loan records to chart yet.</div><?php endif; ?>
        </div>
    </article>
</section>

<div class="grid-2 pascco-admin-section-stagger">
<section class="surface pascco-admin-reveal"><div class="surface-head"><div><h2>Recent Loan Applications</h2><p>Newest loan requests requiring administrative attention.</p></div><a class="mini-link" href="/paco_cooperative/admin/admin_loans.php">View all</a></div><div class="surface-body"><div class="table-wrap"><?php if($recent_loans): ?><table class="admin-table"><thead><tr><th>Loan</th><th>Member</th><th>Amount</th><th>Status</th></tr></thead><tbody><?php foreach($recent_loans as $loan): ?><tr class="pascco-admin-table-row"><td><strong><?php echo htmlspecialchars($loan['loan_number']); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['application_date']); ?></span><a class="mini-link" href="/paco_cooperative/member/loan_application_print.php?loan_id=<?php echo (int)$loan['loan_id']; ?>" target="_blank" rel="noopener">View form</a></td><td><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name']); ?><span class="sub"><?php echo htmlspecialchars($loan['member_number']); ?></span></td><td class="amount">₱<?php echo number_format($loan['loan_amount'],2); ?></td><td><span class="badge <?php echo htmlspecialchars($loan['status']); ?>"><?php echo strtoupper(htmlspecialchars($loan['status'])); ?></span></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No loan applications found.</div><?php endif; ?></div></div></section>
<section class="surface pascco-admin-reveal"><div class="surface-head"><div><h2>Loan Status</h2><p>Current portfolio workflow.</p></div></div><div class="surface-body"><div class="status-grid"><div class="status-tile gold pascco-admin-status-tile"><span>Pending</span><strong><?php echo $loan_status['pending']; ?></strong></div><div class="status-tile pascco-admin-status-tile"><span>Awaiting Admin Approval</span><strong><?php echo $loan_status['under_review']; ?></strong></div><div class="status-tile green pascco-admin-status-tile"><span>Active</span><strong><?php echo $loan_status['active']; ?></strong></div><div class="status-tile pascco-admin-status-tile"><span>Paid</span><strong><?php echo $loan_status['paid']; ?></strong></div><div class="status-tile red pascco-admin-status-tile"><span>Rejected</span><strong><?php echo $loan_status['rejected']; ?></strong></div></div><a class="button mt" href="/paco_cooperative/admin/admin_loans.php"><i class="bx bx-right-arrow-alt"></i> Open Loan Approvals</a> <a class="button mt" href="/paco_cooperative/admin/admin_loan_servicing.php"><i class="bx bx-calendar-check"></i> Loan Servicing</a> <a class="button mt" href="/paco_cooperative/admin/admin_loan_payments.php"><i class="bx bx-money-withdraw"></i> Record Payment</a> <a class="button mt" href="/paco_cooperative/admin/admin_loan_committee.php"><i class="bx bx-group"></i> Loan Approval Queue</a> <a class="button mt" href="/paco_cooperative/admin/admin_loan_closures.php"><i class="bx bx-badge-check"></i> Loan Closures</a></div></section>
</div>
<section class="surface mt pascco-admin-reveal"><div class="surface-head"><div><h2>Recently Registered Members</h2><p>Latest member registrations in the cooperative.</p></div><a class="mini-link" href="/paco_cooperative/admin/admin_members.php">Search members</a></div><div class="surface-body"><div class="table-wrap"><?php if($recent_members): ?><table class="admin-table"><thead><tr><th>Member</th><th>Email</th><th>Registered</th></tr></thead><tbody><?php foreach($recent_members as $member): ?><tr class="pascco-admin-table-row"><td><strong><?php echo htmlspecialchars($member['first_name'].' '.$member['last_name']); ?></strong><span class="sub"><?php echo htmlspecialchars($member['member_number']); ?></span></td><td><?php echo htmlspecialchars($member['email']); ?></td><td><?php echo htmlspecialchars($member['created_at']); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No members found.</div><?php endif; ?></div></div></section>
<section class="surface mt pascco-admin-reveal"><div class="surface-head"><div><h2>System Audit Activity</h2><p>Recent administrative and member-system events.</p></div></div><div class="surface-body"><div class="table-wrap"><?php if($audit_logs): ?><table class="admin-table"><thead><tr><th>User</th><th>Action</th><th>Description</th><th>Result</th><th>IP Address</th><th>Timestamp</th></tr></thead><tbody><?php foreach($audit_logs as $log): ?><tr class="pascco-admin-table-row"><td><strong><?php echo htmlspecialchars($log['username']??'System'); ?></strong></td><td><code><?php echo htmlspecialchars($log['action']); ?></code></td><td><?php echo htmlspecialchars($log['description'], ENT_QUOTES, 'UTF-8'); ?></td><td><span class="badge <?php echo ($log['status'] ?? 'success') === 'success' ? 'approved' : 'rejected'; ?>"><?php echo htmlspecialchars(strtoupper((string)($log['status'] ?? 'unknown')), ENT_QUOTES, 'UTF-8'); ?></span></td><td><small><?php echo htmlspecialchars((string)($log['ip_address'] ?? 'unknown'), ENT_QUOTES, 'UTF-8'); ?></small></td><td><small><?php echo htmlspecialchars($log['created_at']); ?></small></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No audit log records found.</div><?php endif; ?></div></div></section>
</main>
<?php pascco_global_footer(); ?>
<script src="../assets/js/pascco-admin-dashboard-phase3.js?v=1"></script>
</body>
</html>
