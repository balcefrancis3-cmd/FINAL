<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

require_admin();

pascco_refresh_overdue_loan_payments($pdo);

$query = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? 'all';
$allowedStatuses = ['all','active','paid','overdue'];
if (!in_array($status, $allowedStatuses, true)) {
    $status = 'all';
}

$baseWhere = "l.status IN ('approved','disbursed','active','paid')";
$params = [];
if ($status === 'active') {
    $baseWhere = "l.status IN ('approved','disbursed','active')";
} elseif ($status === 'paid') {
    $baseWhere = "l.status = 'paid'";
} elseif ($status === 'overdue') {
    $baseWhere = "l.status IN ('approved','disbursed','active') AND EXISTS (SELECT 1 FROM loan_payments op WHERE op.loan_id = l.id AND op.status = 'overdue')";
}

if ($query !== '') {
    $baseWhere .= " AND (l.loan_number LIKE ? OR l.loan_product LIKE ? OR CONCAT(m.first_name, ' ', m.last_name) LIKE ? OR m.member_number LIKE ?)";
    $like = '%' . $query . '%';
    array_push($params, $like, $like, $like, $like);
}

$sql = "SELECT l.id AS loan_id, l.loan_number, l.loan_product, l.loan_amount, l.remaining_balance, l.total_payable, l.monthly_payment, l.status, l.next_due_date, l.last_payment_date, m.first_name, m.last_name, m.member_number, COALESCE((SELECT SUM(a.amount) FROM loan_payment_allocations a WHERE a.loan_id = l.id),0) AS total_paid, (SELECT COUNT(*) FROM loan_payments op WHERE op.loan_id = l.id AND op.status = 'overdue') AS overdue_count FROM loans l JOIN members m ON m.id = l.member_id WHERE {$baseWhere} ORDER BY CASE WHEN l.status IN ('approved','disbursed','active') THEN 0 ELSE 1 END, l.next_due_date IS NULL, l.next_due_date ASC, l.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$loans = $stmt->fetchAll();

$summary = ['active' => 0, 'paid' => 0, 'overdue' => 0];
$summaryStmt = $pdo->query("SELECT COUNT(CASE WHEN l.status IN ('approved','disbursed','active') THEN 1 END) AS active_count, COALESCE(SUM(CASE WHEN l.status IN ('approved','disbursed','active') THEN l.remaining_balance ELSE 0 END),0) AS outstanding, COALESCE(SUM(CASE WHEN l.status='paid' THEN 1 ELSE 0 END),0) AS paid_count, COALESCE(SUM(CASE WHEN l.status='active' AND EXISTS (SELECT 1 FROM loan_payments op WHERE op.loan_id=l.id AND op.status='overdue') THEN 1 ELSE 0 END),0) AS overdue_count FROM loans l");
$summaryRow = $summaryStmt->fetch() ?: [];
$summary['active'] = (int)($summaryRow['active_count'] ?? 0);
$summary['paid'] = (int)($summaryRow['paid_count'] ?? 0);
$summary['overdue'] = (int)($summaryRow['overdue_count'] ?? 0);
$outstanding = pascco_money_from_cents(pascco_money_to_cents((string) ($summaryRow['outstanding'] ?? '0.00')));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Loan Servicing | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--bg:#f4f7fb;--line:#d8e0ee;--muted:#6e7e93;--danger:#b52f38;--success:#267748}body{margin:0;background:var(--bg);color:#18324f;font-family:Poppins,Arial,sans-serif}.wrap{width:min(1200px,calc(100% - 32px));margin:32px auto 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:20px}.eyebrow{color:var(--blue);font-size:.73rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.head h1{margin:7px 0;color:var(--navy);font-size:clamp(2rem,4vw,2.8rem)}.head p{margin:0;color:var(--muted)}.button{display:inline-flex;align-items:center;gap:7px;padding:10px 14px;border-radius:10px;background:#fff;border:1px solid var(--line);color:var(--navy);font-weight:800;text-decoration:none}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:13px;margin-bottom:20px}.stat{background:#fff;border:1px solid var(--line);border-radius:15px;padding:17px}.stat span{display:block;color:var(--muted);font-size:.72rem;text-transform:uppercase;font-weight:800}.stat strong{display:block;margin-top:7px;color:var(--navy);font-size:1.4rem}.surface{background:#fff;border:1px solid var(--line);border-radius:18px;overflow:hidden}.toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:18px;border-bottom:1px solid var(--line);flex-wrap:wrap}.filters{display:flex;gap:8px;flex-wrap:wrap}.filters a{padding:8px 11px;border:1px solid var(--line);border-radius:9px;text-decoration:none;color:var(--navy);font-size:.78rem;font-weight:800}.filters a.active{background:var(--navy);color:#fff}.search{display:flex;gap:7px}.search input{padding:9px 11px;border:1px solid #cbd7e4;border-radius:9px;min-width:230px}.search button{padding:9px 12px;border:0;border-radius:9px;background:var(--blue);color:#fff;font-weight:800}.table-wrap{overflow:auto}.table{width:100%;min-width:950px;border-collapse:collapse}.table th,.table td{padding:12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.8rem}.table th{background:#eef4fb;color:var(--navy);font-weight:800}.sub{display:block;color:#8492a3;font-size:.7rem;margin-top:3px}.money{color:var(--blue);font-weight:800}.badge{display:inline-block;padding:5px 8px;border-radius:999px;background:#e9f3ff;color:#2966a8;font-size:.68rem;font-weight:800;text-transform:uppercase}.badge.overdue{background:#fde7e7;color:#a52f37}.badge.paid{background:#e4f6ea;color:#17673b}.detail{display:inline-block;margin-top:6px;color:var(--blue);font-weight:800;text-decoration:none;font-size:.75rem}.empty{padding:30px;text-align:center;color:var(--muted)}@media(max-width:800px){.head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr 1fr}.search{width:100%}.search input{flex:1;min-width:0}}@media(max-width:500px){.stats{grid-template-columns:1fr}}
</style>
</head>
<body>
<?php pascco_admin_header(); ?>
<main class="wrap">
<header class="head"><div><div class="eyebrow">Credit operations</div><h1>Loan Servicing</h1><p>Monitor active loans, scheduled repayments, overdue installments, and payment history.</p></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="button" href="/paco_cooperative/admin/admin_loan_payments.php"><i class="bx bx-money-withdraw"></i> Record Payment</a><a class="button" href="/paco_cooperative/admin/admin_loans.php"><i class="bx bx-arrow-back"></i> Loan Approvals</a></div></header>
<section class="stats"><div class="stat"><span>Active Loans</span><strong><?php echo number_format($summary['active']); ?></strong></div><div class="stat"><span>Outstanding Balance</span><strong>₱<?php echo pascco_money_display($outstanding); ?></strong></div><div class="stat"><span>Overdue Loans</span><strong><?php echo number_format($summary['overdue']); ?></strong></div><div class="stat"><span>Paid Loans</span><strong><?php echo number_format($summary['paid']); ?></strong></div></section>
<section class="surface"><div class="toolbar"><div class="filters"><a class="<?php echo $status==='all'?'active':''; ?>" href="?status=all">All</a><a class="<?php echo $status==='active'?'active':''; ?>" href="?status=active">Active</a><a class="<?php echo $status==='overdue'?'active':''; ?>" href="?status=overdue">Overdue</a><a class="<?php echo $status==='paid'?'active':''; ?>" href="?status=paid">Paid</a></div><form class="search" method="GET"><input type="hidden" name="status" value="<?php echo htmlspecialchars($status,ENT_QUOTES,'UTF-8'); ?>"><input name="q" value="<?php echo htmlspecialchars($query,ENT_QUOTES,'UTF-8'); ?>" placeholder="Search loan or member"><button type="submit"><i class="bx bx-search"></i> Search</button></form></div><div class="table-wrap"><table class="table"><thead><tr><th>Loan</th><th>Member</th><th>Principal</th><th>Paid</th><th>Remaining</th><th>Next Due</th><th>Last Payment</th><th>Status</th></tr></thead><tbody><?php if($loans): foreach($loans as $loan): ?><tr><td><strong><?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['loan_product'] ?: 'Loan',ENT_QUOTES,'UTF-8'); ?></span><a class="detail" href="/paco_cooperative/member/loan_details.php?loan_id=<?php echo (int)$loan['loan_id']; ?>" target="_blank" rel="noopener">Open schedule</a><a class="detail" href="/paco_cooperative/member/loan_statement.php?loan_id=<?php echo (int)$loan['loan_id']; ?>" target="_blank" rel="noopener">Statement</a></td><td><strong><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['member_number'],ENT_QUOTES,'UTF-8'); ?></span></td><td class="money">₱<?php echo number_format((float)$loan['loan_amount'],2); ?></td><td>₱<?php echo number_format((float)$loan['total_paid'],2); ?></td><td class="money">₱<?php echo number_format((float)$loan['remaining_balance'],2); ?></td><td><?php echo htmlspecialchars($loan['next_due_date'] ?: '—',ENT_QUOTES,'UTF-8'); ?><?php if((int)$loan['overdue_count']>0): ?><span class="sub" style="color:var(--danger)"><?php echo (int)$loan['overdue_count']; ?> overdue installment<?php echo (int)$loan['overdue_count']===1?'':'s'; ?></span><?php endif; ?></td><td><?php echo htmlspecialchars($loan['last_payment_date'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td><td><span class="badge <?php echo htmlspecialchars($loan['status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($loan['status'],ENT_QUOTES,'UTF-8'); ?></span></td></tr><?php endforeach; else: ?><tr><td colspan="8" class="empty">No loans match the selected filter.</td></tr><?php endif; ?></tbody></table></div></section>
</main>
<?php pascco_global_footer(); ?>
</body></html>
