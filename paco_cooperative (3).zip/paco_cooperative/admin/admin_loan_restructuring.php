<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

require_admin();

$message = '';
$error = '';
$adminId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'create_request') {
            $loanId = (int) ($_POST['loan_id'] ?? 0);
            $reason = trim((string) ($_POST['reason'] ?? ''));
            $term = (int) ($_POST['proposed_term_months'] ?? 0);
            $monthly_raw = trim((string) ($_POST['proposed_monthly_payment'] ?? ''));
            $total_raw = trim((string) ($_POST['proposed_total_payable'] ?? ''));
            $monthly_cents = $monthly_raw === '' ? 0 : pascco_money_input_to_cents($monthly_raw);
            $total_cents = $total_raw === '' ? 0 : pascco_money_input_to_cents($total_raw);
            if ($monthly_cents === null || $total_cents === null) throw new RuntimeException('Money values must have no more than two decimal places.');
            $effective = trim((string) ($_POST['proposed_effective_date'] ?? ''));

            if ($loanId <= 0 || $reason === '') {
                throw new RuntimeException('Loan and restructuring reason are required.');
            }
            if ($term <= 0 || $monthly_cents < 0 || $total_cents < 0) {
                throw new RuntimeException('A restructuring proposal must include a valid term, and financial values cannot be negative.');
            }
            $effectiveCheck = DateTimeImmutable::createFromFormat('!Y-m-d', $effective);
            if ($effective === '' || !$effectiveCheck || $effectiveCheck->format('Y-m-d') !== $effective) {
                throw new RuntimeException('A valid restructuring effective date is required.');
            }
            if ($monthly_cents <= 0 && $total_cents <= 0) {
                throw new RuntimeException('Provide a proposed monthly payment or total payable.');
            }
            if ($monthly_cents > 0 && $total_cents > 0) {
                $expectedTotalCents = $monthly_cents * $term;
                if (abs($expectedTotalCents - $total_cents) > 1) {
                    throw new RuntimeException('The proposed monthly payment, term, and total payable must agree.');
                }
            }

            $pdo->beginTransaction();
            $loanStmt = $pdo->prepare("SELECT id, loan_number, status, remaining_balance FROM loans WHERE id = ? FOR UPDATE");
            $loanStmt->execute([$loanId]);
            $loan = $loanStmt->fetch(PDO::FETCH_ASSOC);
            if (!$loan || !in_array($loan['status'], ['active','approved','disbursed'], true)) {
                throw new RuntimeException('Only an active/disbursed loan can receive a restructuring request.');
            }

            $pendingStmt = $pdo->prepare("SELECT id FROM loan_restructuring_requests WHERE loan_id = ? AND status = 'pending' LIMIT 1");
            $pendingStmt->execute([$loanId]);
            if ($pendingStmt->fetchColumn()) {
                throw new RuntimeException('This loan already has a pending restructuring request.');
            }

            if ($total_cents <= 0) $total_cents = $monthly_cents * $term;
            if ($monthly_cents <= 0) $monthly_cents = pascco_money_round_divide($total_cents, $term);
            if ($total_cents <= 0 || $monthly_cents <= 0) {
                throw new RuntimeException('The proposed restructuring values are invalid.');
            }
            if ($total_cents < pascco_money_to_cents((string) $loan['remaining_balance'])) {
                throw new RuntimeException('The proposed total payable cannot be lower than the current remaining balance.');
            }
            if (abs(($monthly_cents * $term) - $total_cents) > 1) {
                throw new RuntimeException('The proposed monthly payment, term, and total payable must agree.');
            }

            $monthly = pascco_money_from_cents($monthly_cents);
            $total = pascco_money_from_cents($total_cents);
            $insert = $pdo->prepare('INSERT INTO loan_restructuring_requests (loan_id, requested_by, reason, proposed_term_months, proposed_monthly_payment, proposed_total_payable, proposed_effective_date) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $insert->execute([
                $loanId,
                $adminId,
                substr($reason, 0, 500),
                $term > 0 ? $term : null,
                $monthly_cents > 0 ? $monthly : null,
                $total_cents > 0 ? $total : null,
                $effective !== '' ? $effective : null,
            ]);
            $requestId = (int) $pdo->lastInsertId();
            $pdo->commit();
            record_audit($pdo, $adminId, 'loan_restructuring_request', 'Created restructuring request ' . $requestId . ' for loan ' . $loanId, 'success');
            $message = 'Restructuring request created for ' . $loan['loan_number'] . '. No loan terms have been changed.';
        } elseif ($action === 'execute_request') {
            $requestId = (int) ($_POST['request_id'] ?? 0);
            if ($requestId <= 0) {
                throw new RuntimeException('Invalid restructuring request.');
            }
            $pdo->beginTransaction();
            $result = pascco_execute_loan_restructuring($pdo, $requestId, $adminId);
            $pdo->commit();
            record_audit($pdo, $adminId, 'loan_restructuring_execution', 'Executed restructuring ' . $result['execution_reference'] . ' for loan ' . $result['loan_number'], 'success');
            $message = 'Restructuring executed for ' . $result['loan_number'] . '. New remaining balance: ₱' . number_format($result['remaining_balance'], 2) . '.';
        } elseif ($action === 'review_request') {
            $requestId = (int) ($_POST['request_id'] ?? 0);
            $decision = ($_POST['decision'] ?? '') === 'approved' ? 'approved' : 'rejected';
            $notes = trim((string) ($_POST['notes'] ?? ''));
            if ($requestId <= 0) {
                throw new RuntimeException('Invalid restructuring request.');
            }
            $pdo->beginTransaction();
            $reqStmt = $pdo->prepare("SELECT r.*, l.loan_number, l.status AS loan_status FROM loan_restructuring_requests r JOIN loans l ON l.id = r.loan_id WHERE r.id = ? FOR UPDATE");
            $reqStmt->execute([$requestId]);
            $request = $reqStmt->fetch(PDO::FETCH_ASSOC);
            if (!$request || $request['status'] !== 'pending') {
                throw new RuntimeException('This restructuring request is no longer pending.');
            }
            if (!in_array($request['loan_status'], ['active','approved','disbursed'], true)) {
                throw new RuntimeException('The loan is no longer eligible for restructuring review.');
            }
            $existing = $pdo->prepare('SELECT id FROM loan_restructuring_reviews WHERE restructuring_request_id = ? AND reviewer_id = ? LIMIT 1');
            $existing->execute([$requestId, $adminId]);
            if ($existing->fetchColumn()) {
                throw new RuntimeException('You have already reviewed this request.');
            }
            $review = $pdo->prepare('INSERT INTO loan_restructuring_reviews (restructuring_request_id, reviewer_id, decision, notes) VALUES (?, ?, ?, ?)');
            $review->execute([$requestId, $adminId, $decision, $notes !== '' ? substr($notes, 0, 500) : null]);
            $status = $decision === 'approved' ? 'approved' : 'rejected';
            $update = $pdo->prepare('UPDATE loan_restructuring_requests SET status = ?, completed_at = NOW(), completed_by = ? WHERE id = ? AND status = \'pending\'');
            $update->execute([$status, $adminId, $requestId]);
            $pdo->commit();
            record_audit($pdo, $adminId, 'loan_restructuring_review', ucfirst($decision) . ' restructuring request ' . $requestId . ' for loan ' . $request['loan_number'], 'success');
            $message = 'Request ' . $request['loan_number'] . ' marked ' . $status . '. The loan terms were not changed.';
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $exception->getMessage();
    }
}

$loanStmt = $pdo->query("SELECT l.id, l.loan_number, l.loan_product, l.loan_amount, l.remaining_balance, l.monthly_payment, l.loan_term, l.status, m.first_name, m.last_name, m.member_number FROM loans l JOIN members m ON m.id = l.member_id WHERE l.status IN ('active','approved','disbursed') ORDER BY l.id DESC");
$loans = $loanStmt->fetchAll(PDO::FETCH_ASSOC);

$requestsStmt = $pdo->query("SELECT r.*, ex.execution_reference, ex.executed_at, ex.executed_by, l.loan_number, l.loan_product, l.remaining_balance, l.status AS loan_status, m.first_name, m.last_name, m.member_number, creator.username AS requested_by_username, completer.username AS completed_by_username, (SELECT COUNT(*) FROM loan_restructuring_reviews rv WHERE rv.restructuring_request_id = r.id AND rv.decision = 'approved') AS approval_count, (SELECT COUNT(*) FROM loan_restructuring_reviews rv WHERE rv.restructuring_request_id = r.id AND rv.decision = 'rejected') AS rejection_count FROM loan_restructuring_requests r JOIN loans l ON l.id = r.loan_id JOIN members m ON m.id = l.member_id JOIN users creator ON creator.id = r.requested_by LEFT JOIN users completer ON completer.id = r.completed_by LEFT JOIN loan_restructuring_executions ex ON ex.restructuring_request_id = r.id ORDER BY CASE r.status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END, r.submitted_at DESC");
$requests = $requestsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Loan Restructuring | PASCCO</title><?php pascco_global_styles(); ?><style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--bg:#f4f7fb;--line:#d8e0ee;--muted:#6e7e93;--green:#247748;--danger:#a52f37}body{margin:0;background:var(--bg);color:#18324f;font-family:Poppins,Arial,sans-serif}.wrap{width:min(1240px,calc(100% - 32px));margin:30px auto 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}.eyebrow{color:var(--blue);font-size:.73rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.head h1{margin:7px 0;color:var(--navy);font-size:clamp(2rem,4vw,2.7rem)}.head p{margin:0;color:var(--muted);line-height:1.5}.back,.button{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);background:#fff;color:var(--navy);padding:9px 12px;border-radius:9px;text-decoration:none;font-weight:800;cursor:pointer}.button.primary{background:var(--blue);border-color:var(--blue);color:#fff}.button.danger{background:#a52f37;border-color:#a52f37;color:#fff}.msg{padding:12px 14px;border-radius:10px;margin-bottom:16px;font-weight:700}.success{background:#e7f5ec;color:#17673b}.error{background:#fde7e7;color:#9d2933}.panel{background:#fff;border:1px solid var(--line);border-radius:17px;overflow:hidden;margin-bottom:18px}.panel-title{padding:16px 18px;border-bottom:1px solid var(--line);font-weight:900;color:var(--navy)}.table-wrap{overflow:auto}.table{width:100%;min-width:1200px;border-collapse:collapse}.table th,.table td{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.77rem}.table th{background:#eef4fb;color:var(--navy);font-weight:900}.sub{display:block;color:#8794a4;font-size:.68rem;margin-top:3px}.money{color:var(--blue);font-weight:900;white-space:nowrap}.badge{display:inline-block;padding:4px 7px;border-radius:999px;background:#fff0bf;color:#8a6500;font-size:.65rem;font-weight:900;text-transform:uppercase}.badge.approved{background:#e7f5ec;color:var(--green)}.badge.rejected{background:#fde7e7;color:var(--danger)}.actions{display:flex;gap:7px;flex-wrap:wrap}.empty{text-align:center;color:var(--muted);padding:28px}.note{margin-bottom:18px;padding:13px 15px;border:1px solid #eadba8;background:#fffaf0;border-radius:11px;color:#66501c;line-height:1.5;font-size:.8rem}.modal{display:none;position:fixed;inset:0;background:rgba(7,29,73,.45);align-items:center;justify-content:center;padding:20px;z-index:9999}.modal:target{display:flex}.dialog{width:min(650px,100%);max-height:90vh;overflow:auto;background:#fff;border-radius:16px;padding:20px;box-shadow:0 20px 60px rgba(0,0,0,.18)}.dialog h2{margin:0 0 8px;color:var(--navy)}.field{margin:11px 0}.field label{display:block;margin-bottom:6px;color:var(--navy);font-weight:800;font-size:.78rem}.field input,.field select,.field textarea{width:100%;box-sizing:border-box;padding:10px;border:1px solid #cbd7e4;border-radius:9px;font:inherit}.field textarea{min-height:90px;resize:vertical}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}.modal-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:15px}.close{padding:9px 12px;border:1px solid var(--line);border-radius:9px;color:var(--navy);text-decoration:none;font-weight:800}.help{color:var(--muted);font-size:.72rem;line-height:1.45}.section-gap{margin-top:20px}@media(max-width:850px){.head{align-items:flex-start;flex-direction:column}.grid2{grid-template-columns:1fr}}
</style></head><body><?php pascco_admin_header(); ?><main class="wrap"><header class="head"><div><div class="eyebrow">Credit administration</div><h1>Loan Restructuring</h1><p>Record and review proposed changes to an active loan. Approval here does not alter financial terms until execution.</p></div><a class="back" href="/paco_cooperative/admin/admin_loan_servicing.php"><i class="bx bx-arrow-back"></i> Loan Servicing</a></header>
<?php if($message): ?><div class="msg success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?><?php if($error): ?><div class="msg error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<div class="note"><strong>Important:</strong> This step records a restructuring proposal and administrator review. It does not rewrite the loan balance, interest, repayment schedule, or loan status. With the current one-administrator PASCCO setup, the same authorized administrator may create, review, and execute the request. Execution is still transactional, audited, and subject to the approved proposal values.</div>
<section class="panel"><div class="panel-title">Active Loans — Create Restructuring Request</div><div class="table-wrap"><table class="table"><thead><tr><th>Loan</th><th>Member</th><th>Status</th><th>Current Balance</th><th>Current Term</th><th>Current Monthly</th><th>Action</th></tr></thead><tbody><?php if($loans): foreach($loans as $loan): ?><tr><td><strong><?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['loan_product'] ?: 'Loan',ENT_QUOTES,'UTF-8'); ?></span></td><td><strong><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['member_number'],ENT_QUOTES,'UTF-8'); ?></span></td><td><span class="badge"><?php echo htmlspecialchars($loan['status'],ENT_QUOTES,'UTF-8'); ?></span></td><td class="money">₱<?php echo number_format((float)$loan['remaining_balance'],2); ?></td><td><?php echo htmlspecialchars($loan['loan_term'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td><td>₱<?php echo number_format((float)$loan['monthly_payment'],2); ?></td><td><a class="button primary" href="#request-<?php echo (int)$loan['id']; ?>">Create Request</a></td></tr><?php endforeach; else: ?><tr><td colspan="7" class="empty">No active loans are currently eligible for restructuring requests.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="panel"><div class="panel-title">Restructuring Requests</div><div class="table-wrap"><table class="table"><thead><tr><th>Request</th><th>Loan / Member</th><th>Proposal</th><th>Reason</th><th>Submitted By</th><th>Status</th><th>Action</th></tr></thead><tbody><?php if($requests): foreach($requests as $r): ?><tr><td><strong>#<?php echo (int)$r['id']; ?></strong><span class="sub"><?php echo htmlspecialchars($r['submitted_at'],ENT_QUOTES,'UTF-8'); ?></span></td><td><strong><?php echo htmlspecialchars($r['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($r['first_name'].' '.$r['last_name'],ENT_QUOTES,'UTF-8'); ?></span></td><td><?php if($r['proposed_term_months']): ?>Term: <?php echo (int)$r['proposed_term_months']; ?> months<br><?php endif; ?><?php if($r['proposed_monthly_payment']!==null): ?>Monthly: ₱<?php echo number_format((float)$r['proposed_monthly_payment'],2); ?><br><?php endif; ?><?php if($r['proposed_total_payable']!==null): ?>Total: ₱<?php echo number_format((float)$r['proposed_total_payable'],2); ?><br><?php endif; ?><?php if($r['proposed_effective_date']): ?>Effective: <?php echo htmlspecialchars($r['proposed_effective_date'],ENT_QUOTES,'UTF-8'); ?><?php endif; ?></td><td><?php echo htmlspecialchars($r['reason'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($r['requested_by_username'],ENT_QUOTES,'UTF-8'); ?></td><td><span class="badge <?php echo htmlspecialchars($r['status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($r['status'],ENT_QUOTES,'UTF-8'); ?></span><span class="sub">Approved: <?php echo (int)$r['approval_count']; ?> · Rejected: <?php echo (int)$r['rejection_count']; ?></span></td><td class="actions"><?php if($r['status']==='pending'): ?><a class="button primary" href="#review-<?php echo (int)$r['id']; ?>">Review</a><?php elseif($r['status']==='approved' && empty($r['execution_reference'])): ?><a class="button primary" href="#execute-<?php echo (int)$r['id']; ?>">Execute</a><?php elseif($r['execution_reference']): ?><span class="badge approved">Executed</span><span class="sub"><?php echo htmlspecialchars($r['execution_reference'],ENT_QUOTES,'UTF-8'); ?></span><?php else: ?><span class="sub"><?php echo $r['status']==='pending' ? 'Awaiting administrator review' : 'No further action'; ?></span><?php endif; ?></td></tr><?php endforeach; else: ?><tr><td colspan="7" class="empty">No restructuring requests have been recorded.</td></tr><?php endif; ?></tbody></table></div></section>
<p class="help">Approved proposals can be executed only by an administrator. Execution preserves existing payment allocations, records a before/after snapshot, replaces unpaid schedule rows with the approved schedule, and updates the loan terms.</p>
</main>
<?php foreach($loans as $loan): ?><div class="modal" id="request-<?php echo (int)$loan['id']; ?>"><div class="dialog"><h2>Restructuring Request — <?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?></h2><p class="help">Current remaining balance: ₱<?php echo number_format((float)$loan['remaining_balance'],2); ?>. Enter only the terms formally proposed for review.</p><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="action" value="create_request"><input type="hidden" name="loan_id" value="<?php echo (int)$loan['id']; ?>"><div class="field"><label>Reason</label><textarea name="reason" maxlength="500" required placeholder="Why is restructuring being requested?"></textarea></div><div class="grid2"><div class="field"><label>Proposed Term (months)</label><input type="number" name="proposed_term_months" min="0" max="600" placeholder="Optional"></div><div class="field"><label>Proposed Monthly Payment</label><input type="number" name="proposed_monthly_payment" min="0" step="0.01" placeholder="Optional"></div><div class="field"><label>Proposed Total Payable</label><input type="number" name="proposed_total_payable" min="0" step="0.01" placeholder="Optional"></div><div class="field"><label>Proposed Effective Date</label><input type="date" name="proposed_effective_date"></div></div><p class="help">A proposed total payable cannot be lower than the current remaining balance. Leaving a field blank means no proposal was made for that field.</p><div class="modal-actions"><a class="close" href="#">Cancel</a><button class="button primary" type="submit">Submit Request</button></div></form></div></div><?php endforeach; ?>
<?php foreach($requests as $r): if($r['status']!=='approved' || !empty($r['execution_reference'])) continue; ?><div class="modal" id="execute-<?php echo (int)$r['id']; ?>"><div class="dialog"><h2>Execute Restructuring #<?php echo (int)$r['id']; ?></h2><p><strong><?php echo htmlspecialchars($r['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong> — <?php echo htmlspecialchars($r['first_name'].' '.$r['last_name'],ENT_QUOTES,'UTF-8'); ?></p><p class="help">This applies the approved proposal. Existing paid/partial allocations remain as history. Unpaid schedule rows are marked waived and a replacement schedule is created using the approved term, monthly payment, remaining payable, and effective date.</p><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="action" value="execute_request"><input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>"><div class="modal-actions"><a class="close" href="#">Cancel</a><button class="button primary" type="submit">Confirm Execution</button></div></form></div></div><?php endforeach; ?>
<?php foreach($requests as $r): if($r['status']!=='pending') continue; ?><div class="modal" id="review-<?php echo (int)$r['id']; ?>"><div class="dialog"><h2>Review Request #<?php echo (int)$r['id']; ?></h2><p><strong><?php echo htmlspecialchars($r['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong> — <?php echo htmlspecialchars($r['first_name'].' '.$r['last_name'],ENT_QUOTES,'UTF-8'); ?></p><p class="help">Requested by <?php echo htmlspecialchars($r['requested_by_username'],ENT_QUOTES,'UTF-8'); ?>. Record the administrator's review decision and supporting notes before the request is approved or rejected.</p><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="action" value="review_request"><input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>"><div class="field"><label>Decision</label><select name="decision"><option value="approved">Approve Proposal</option><option value="rejected">Reject Proposal</option></select></div><div class="field"><label>Review Notes</label><textarea name="notes" maxlength="500" placeholder="Record the basis for your review"></textarea></div><div class="modal-actions"><a class="close" href="#">Cancel</a><button class="button primary" type="submit">Save Review</button></div></form></div></div><?php endforeach; ?>
</body></html>
