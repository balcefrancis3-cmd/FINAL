<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

require_admin();

// Refresh installment states before producing an overdue snapshot.
pascco_refresh_overdue_loan_payments($pdo);

$today = date('Y-m-d');
$defaultStart = date('Y-m-01');
$startDate = trim((string)($_GET['start_date'] ?? $defaultStart));
$endDate = trim((string)($_GET['end_date'] ?? $today));
$status = (string)($_GET['status'] ?? 'all');
$allowedStatuses = ['all', 'active', 'overdue', 'paid'];
if (!in_array($status, $allowedStatuses, true)) $status = 'all';
$datePattern = '/^\d{4}-\d{2}-\d{2}$/';
$startObj = DateTime::createFromFormat('!Y-m-d', $startDate);
$endObj = DateTime::createFromFormat('!Y-m-d', $endDate);
if (!preg_match($datePattern, $startDate) || !preg_match($datePattern, $endDate)
    || !$startObj || $startObj->format('Y-m-d') !== $startDate
    || !$endObj || $endObj->format('Y-m-d') !== $endDate || $startDate > $endDate) {
    $startDate = $defaultStart;
    $endDate = $today;
}
$endExclusive = date('Y-m-d', strtotime($endDate . ' +1 day'));

// Half-open date range allows the payment_date index to be used.
$where = ['a.payment_date >= ?', 'a.payment_date < ?'];
$params = [$startDate . ' 00:00:00', $endExclusive . ' 00:00:00'];
if ($status === 'active') {
    $where[] = "l.status IN ('approved','disbursed','active')";
} elseif ($status === 'paid') {
    $where[] = "l.status = 'paid'";
} elseif ($status === 'overdue') {
    $where[] = "EXISTS (SELECT 1 FROM loan_payments op WHERE op.loan_id=l.id AND op.status='overdue')";
}
$whereSql = implode(' AND ', $where);

$sql = "SELECT a.id AS allocation_id, a.payment_date, a.reference_number, a.amount,
               lp.payment_number, lp.due_date, lp.status AS installment_status,
               l.id AS loan_id, l.loan_number, l.loan_product, l.status AS loan_status,
               m.member_number, m.first_name, m.last_name
        FROM loan_payment_allocations a
        JOIN loans l ON l.id=a.loan_id
        JOIN loan_payments lp ON lp.id=a.loan_payment_id
        JOIN members m ON m.id=l.member_id
        WHERE {$whereSql}
        ORDER BY a.payment_date DESC, a.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalCollectedCents = 0;
foreach ($rows as $row) $totalCollectedCents += pascco_money_to_cents((string) $row['amount']);
$totalCollected = pascco_money_from_cents($totalCollectedCents);
$paymentCount = count($rows);

$portfolioStmt = $pdo->query("SELECT
    COUNT(CASE WHEN status IN ('approved','disbursed','active') THEN 1 END) AS active_count,
    COALESCE(SUM(CASE WHEN status IN ('approved','disbursed','active') THEN remaining_balance ELSE 0 END),0) AS outstanding,
    COUNT(CASE WHEN status='paid' THEN 1 END) AS paid_count
    FROM loans");
$portfolio = $portfolioStmt->fetch(PDO::FETCH_ASSOC) ?: [];
$overdueStmt = $pdo->query("SELECT COUNT(DISTINCT l.id) FROM loans l JOIN loan_payments p ON p.loan_id=l.id WHERE l.status IN ('approved','disbursed','active') AND p.status='overdue'");
$overdueCount = (int)$overdueStmt->fetchColumn();

if (($_GET['export'] ?? '') === 'csv') {
    $filename = 'pascco_loan_payments_' . $startDate . '_to_' . $endDate . '.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('X-Content-Type-Options: nosniff');
    $out = fopen('php://output', 'w');
    // UTF-8 BOM improves compatibility with spreadsheet applications.
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Payment Date', 'Loan Number', 'Loan Product', 'Member Number', 'Member Name', 'Installment Number', 'Due Date', 'Installment Status', 'Loan Status', 'Reference', 'Allocated Amount']);
    foreach ($rows as $row) {
        $safe = static function ($value) {
            $value = (string)$value;
            return preg_match('/^[=+@\-]/', $value) ? "'" . $value : $value;
        };
        fputcsv($out, [
            $row['payment_date'], $safe($row['loan_number']), $safe($row['loan_product'] ?? ''),
            $safe($row['member_number']), $safe($row['first_name'] . ' ' . $row['last_name']),
            (int)$row['payment_number'], $row['due_date'], $row['installment_status'], $row['loan_status'],
            $safe($row['reference_number']), number_format((float)$row['amount'], 2, '.', '')
        ]);
    }
    fclose($out);
    exit;
}

$queryParams = http_build_query(['start_date'=>$startDate, 'end_date'=>$endDate, 'status'=>$status]);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Loan Reports | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--bg:#f4f7fb;--line:#d8e0ee;--muted:#6e7e93;--danger:#a52f37}body{margin:0;background:var(--bg);color:#18324f;font-family:Poppins,Arial,sans-serif}.wrap{width:min(1240px,calc(100% - 32px));margin:30px auto 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}.eyebrow{color:var(--blue);font-size:.73rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.head h1{margin:7px 0;color:var(--navy);font-size:clamp(2rem,4vw,2.7rem)}.head p{margin:0;color:var(--muted);line-height:1.5}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:7px;padding:10px 13px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--navy);font-weight:800;text-decoration:none}.btn.primary{background:var(--blue);color:#fff;border-color:var(--blue)}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-bottom:18px}.stat,.panel{background:#fff;border:1px solid var(--line);border-radius:15px}.stat{padding:16px}.stat span{display:block;color:var(--muted);font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.04em}.stat strong{display:block;margin-top:8px;color:var(--navy);font-size:clamp(1.05rem,2vw,1.45rem);overflow-wrap:anywhere}.panel{overflow:hidden;margin-bottom:18px}.panel-title{padding:16px 18px;border-bottom:1px solid var(--line);color:var(--navy);font-weight:900}.filters{display:flex;align-items:end;gap:12px;flex-wrap:wrap;padding:16px 18px}.field{display:flex;flex-direction:column;gap:5px}.field label{font-size:.72rem;font-weight:800;color:var(--navy)}.field input,.field select{min-height:40px;box-sizing:border-box;border:1px solid #cbd7e4;border-radius:9px;padding:8px 10px;font:inherit;background:#fff}.hint{font-size:.75rem;color:var(--muted);padding:0 18px 14px}.table-wrap{overflow:auto}.table{width:100%;min-width:1080px;border-collapse:collapse}.table th,.table td{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.78rem}.table th{background:#eef4fb;color:var(--navy);font-weight:900}.sub{display:block;color:#8794a4;font-size:.69rem;margin-top:3px}.money{color:var(--blue);font-weight:900;white-space:nowrap}.badge{display:inline-block;padding:4px 7px;border-radius:999px;background:#e9f3ff;color:#2966a8;font-size:.66rem;font-weight:900;text-transform:uppercase}.badge.paid{background:#e4f6ea;color:#17673b}.badge.overdue{background:#fde7e7;color:var(--danger)}.empty{text-align:center;color:var(--muted);padding:28px}.footnote{font-size:.76rem;line-height:1.5;color:var(--muted);padding:0 2px}@media(max-width:1000px){.stats{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:650px){.head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr 1fr}.filters{align-items:stretch}.field{flex:1;min-width:130px}.actions{width:100%}}@media(max-width:420px){.stats{grid-template-columns:1fr}}
</style>
</head>
<body>
<?php pascco_admin_header(); ?>
<main class="wrap">
<header class="head"><div><div class="eyebrow">Credit operations</div><h1>Loan Reports</h1><p>Review recorded installment allocations, collection totals, outstanding balances, and overdue loan counts.</p></div><div class="actions"><a class="btn" href="/paco_cooperative/admin/admin_loan_servicing.php"><i class="bx bx-calendar-check"></i> Loan Servicing</a><a class="btn primary" href="/paco_cooperative/admin/admin_loan_payments.php"><i class="bx bx-plus-circle"></i> Record Payment</a></div></header>
<section class="stats">
<div class="stat"><span>Collected in Selected Period</span><strong>₱<?php echo pascco_money_display($totalCollected); ?></strong></div>
<div class="stat"><span>Payment Allocations</span><strong><?php echo number_format($paymentCount); ?></strong></div>
<div class="stat"><span>Active Loans</span><strong><?php echo number_format((int)($portfolio['active_count'] ?? 0)); ?></strong></div>
<div class="stat"><span>Outstanding Balance</span><strong>₱<?php echo number_format((float)($portfolio['outstanding'] ?? 0),2); ?></strong></div>
<div class="stat"><span>Overdue Loans</span><strong><?php echo number_format($overdueCount); ?></strong><span style="margin-top:4px">Paid loans: <?php echo number_format((int)($portfolio['paid_count'] ?? 0)); ?></span></div>
</section>
<section class="panel"><div class="panel-title">Report Filters</div><form class="filters" method="get">
<div class="field"><label for="start_date">Payment date from</label><input id="start_date" type="date" name="start_date" value="<?php echo htmlspecialchars($startDate,ENT_QUOTES,'UTF-8'); ?>" required></div>
<div class="field"><label for="end_date">Payment date to</label><input id="end_date" type="date" name="end_date" value="<?php echo htmlspecialchars($endDate,ENT_QUOTES,'UTF-8'); ?>" required></div>
<div class="field"><label for="status">Loan status</label><select id="status" name="status"><option value="all" <?php echo $status==='all'?'selected':''; ?>>All statuses</option><option value="active" <?php echo $status==='active'?'selected':''; ?>>Active</option><option value="overdue" <?php echo $status==='overdue'?'selected':''; ?>>Overdue</option><option value="paid" <?php echo $status==='paid'?'selected':''; ?>>Paid</option></select></div>
<button class="btn primary" type="submit"><i class="bx bx-filter-alt"></i> Apply Filters</button>
<a class="btn" href="/paco_cooperative/admin/admin_loan_reports.php">Reset</a>
<a class="btn" href="/paco_cooperative/admin/admin_loan_reports.php?<?php echo htmlspecialchars($queryParams,ENT_QUOTES,'UTF-8'); ?>&amp;export=csv"><i class="bx bx-download"></i> Export CSV</a>
</form><div class="hint">Collection totals include each payment allocation once. External receipts are not added separately, preventing double-counting.</div></section>
<section class="panel"><div class="panel-title">Payment Allocation Details <span style="font-weight:500;color:var(--muted)">(<?php echo htmlspecialchars($startDate,ENT_QUOTES,'UTF-8'); ?> to <?php echo htmlspecialchars($endDate,ENT_QUOTES,'UTF-8'); ?>)</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Payment Date</th><th>Loan</th><th>Member</th><th>Installment</th><th>Due Date</th><th>Reference</th><th>Amount Allocated</th><th>Installment Status</th><th>Loan Status</th></tr></thead><tbody>
<?php if($rows): foreach($rows as $row): ?><tr><td><?php echo htmlspecialchars($row['payment_date'],ENT_QUOTES,'UTF-8'); ?></td><td><strong><?php echo htmlspecialchars($row['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($row['loan_product'] ?: 'Loan',ENT_QUOTES,'UTF-8'); ?></span><a class="sub" href="/paco_cooperative/member/loan_details.php?loan_id=<?php echo (int)$row['loan_id']; ?>" target="_blank" rel="noopener">Open loan details</a><a class="sub" href="/paco_cooperative/member/loan_statement.php?loan_id=<?php echo (int)$row['loan_id']; ?>" target="_blank" rel="noopener">Statement</a></td><td><strong><?php echo htmlspecialchars($row['first_name'].' '.$row['last_name'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($row['member_number'],ENT_QUOTES,'UTF-8'); ?></span></td><td>#<?php echo (int)$row['payment_number']; ?></td><td><?php echo htmlspecialchars($row['due_date'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($row['reference_number'],ENT_QUOTES,'UTF-8'); ?></td><td class="money">₱<?php echo number_format((float)$row['amount'],2); ?></td><td><span class="badge <?php echo htmlspecialchars($row['installment_status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($row['installment_status'],ENT_QUOTES,'UTF-8'); ?></span></td><td><span class="badge <?php echo htmlspecialchars($row['loan_status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($row['loan_status'],ENT_QUOTES,'UTF-8'); ?></span></td></tr><?php endforeach; else: ?><tr><td colspan="9" class="empty">No payment allocations match these filters.</td></tr><?php endif; ?>
</tbody></table></div></section>
<p class="footnote">Reporting note: this page summarizes payment allocations recorded by the loan system. It is an operational report, not a certified accounting statement or audited financial report. Please reconcile totals with PASCCO's official accounting records before using them for financial reporting.</p>
</main>
<?php pascco_global_footer(); ?>
</body></html>
