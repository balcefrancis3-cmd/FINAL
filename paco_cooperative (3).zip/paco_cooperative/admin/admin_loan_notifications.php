<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';
require_once __DIR__ . '/../includes/loan_notifications.php';

require_admin();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'run_notifications') {
    verify_csrf();
    try {
        pascco_refresh_overdue_loan_payments($pdo);
        $summary = pascco_process_loan_notifications($pdo);
        record_audit($pdo, (int)$_SESSION['user_id'], 'loan_notification_run', 'Ran loan due-date notification processor: sent ' . $summary['sent'] . ', failed ' . $summary['failed'], $summary['failed'] > 0 ? 'warning' : 'success');
        $message = 'Notification run completed. Sent: ' . $summary['sent'] . '; failed: ' . $summary['failed'] . '; skipped: ' . $summary['skipped'] . '.';
    } catch (Throwable $exception) {
        $error = 'Notification run failed. Please check the mail configuration and server logs.';
        error_log('PASCCO loan notification run failed: ' . $exception->getMessage());
    }
}

pascco_refresh_overdue_loan_payments($pdo);

$today = date('Y-m-d');
$windowEnd = date('Y-m-d', strtotime('+7 days'));
$candidateStmt = $pdo->prepare("SELECT l.id, l.loan_number, l.next_due_date, l.remaining_balance, l.status, m.member_number, m.first_name, m.last_name, m.email,
    DATEDIFF(l.next_due_date, CURDATE()) AS days_until_due,
    CASE
        WHEN l.next_due_date < CURDATE() THEN 'Overdue'
        WHEN l.next_due_date = CURDATE() THEN 'Due today'
        WHEN l.next_due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 'Upcoming'
        ELSE 'Later'
    END AS reminder_state
    FROM loans l JOIN members m ON m.id=l.member_id
    WHERE l.status IN ('approved','disbursed','active') AND l.remaining_balance > 0 AND l.next_due_date IS NOT NULL
    ORDER BY l.next_due_date, l.id");
$candidateStmt->execute();
$candidates = $candidateStmt->fetchAll(PDO::FETCH_ASSOC);

$logStmt = $pdo->query("SELECT n.notification_type, n.reference_date, n.recipient_email, n.status, n.sent_at, n.error_message, l.loan_number, m.first_name, m.last_name
    FROM loan_notification_logs n JOIN loans l ON l.id=n.loan_id JOIN members m ON m.id=n.member_id
    ORDER BY n.id DESC LIMIT 50");
$logs = $logStmt->fetchAll(PDO::FETCH_ASSOC);

$stats = ['upcoming'=>0,'today'=>0,'overdue'=>0];
foreach ($candidates as $candidate) {
    if ($candidate['reminder_state'] === 'Upcoming') $stats['upcoming']++;
    elseif ($candidate['reminder_state'] === 'Due today') $stats['today']++;
    elseif ($candidate['reminder_state'] === 'Overdue') $stats['overdue']++;
}
?>
<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Loan Notifications | PASCCO Admin</title><?php pascco_global_styles(); ?><style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--bg:#f4f7fb;--line:#d8e0ee;--muted:#6e7e93;--danger:#a52f37;--green:#17673b}body{margin:0;background:var(--bg);color:#18324f;font-family:Poppins,Arial,sans-serif}.wrap{width:min(1240px,calc(100% - 32px));margin:30px auto 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}.eyebrow{color:var(--blue);font-size:.73rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.head h1{margin:7px 0;color:var(--navy);font-size:clamp(2rem,4vw,2.7rem)}.head p{margin:0;color:var(--muted);line-height:1.5}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:7px;padding:10px 13px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--navy);font-weight:800;text-decoration:none}.btn.primary{background:var(--blue);color:#fff;border-color:var(--blue)}.msg{padding:12px 14px;border-radius:10px;margin-bottom:16px;font-weight:700}.success{background:#e7f6ed;color:var(--green);border:1px solid #bfe4cd}.error{background:#fde9e9;color:var(--danger);border:1px solid #efc5c5}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:18px}.stat,.panel{background:#fff;border:1px solid var(--line);border-radius:15px}.stat{padding:17px}.stat span{display:block;color:var(--muted);font-size:.7rem;font-weight:800;text-transform:uppercase}.stat strong{display:block;margin-top:8px;color:var(--navy);font-size:1.55rem}.panel{overflow:hidden;margin-bottom:18px}.panel-title{padding:16px 18px;border-bottom:1px solid var(--line);color:var(--navy);font-weight:900}.panel-note{padding:12px 18px;color:var(--muted);font-size:.78rem;line-height:1.55;background:#f8fafc}.run{padding:16px 18px}.run button{border:0;border-radius:10px;padding:11px 15px;background:var(--blue);color:#fff;font:inherit;font-weight:800;cursor:pointer}.table-wrap{overflow:auto}.table{width:100%;min-width:1050px;border-collapse:collapse}.table th,.table td{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.77rem}.table th{background:#eef4fb;color:var(--navy);font-weight:900}.sub{display:block;color:#8794a4;font-size:.68rem;margin-top:3px}.money{font-weight:900;color:var(--blue);white-space:nowrap}.badge{display:inline-block;padding:4px 7px;border-radius:999px;background:#e8f2ff;color:#2863a5;font-size:.64rem;font-weight:900;text-transform:uppercase}.badge.today{background:#fff4d6;color:#795800}.badge.overdue{background:#fde7e7;color:var(--danger)}.badge.sent{background:#e4f6ea;color:var(--green)}.badge.failed{background:#fde7e7;color:var(--danger)}.empty{text-align:center;padding:28px;color:var(--muted)}@media(max-width:700px){.head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr}.actions{width:100%}}
</style></head><body>
<?php pascco_admin_header(); ?><main class="wrap">
<header class="head"><div><div class="eyebrow">Credit operations</div><h1>Loan Notifications</h1><p>Review upcoming and overdue loan reminders. Notifications are informational and do not change financial records.</p></div><div class="actions"><a class="btn" href="/paco_cooperative/admin/admin_loan_servicing.php"><i class="bx bx-calendar-check"></i> Loan Servicing</a><a class="btn" href="/paco_cooperative/admin/admin_loan_reports.php"><i class="bx bx-bar-chart-alt-2"></i> Loan Reports</a></div></header>
<?php if($message): ?><div class="msg success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<?php if($error): ?><div class="msg error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<section class="stats"><div class="stat"><span>Upcoming within 7 days</span><strong><?php echo number_format($stats['upcoming']); ?></strong></div><div class="stat"><span>Due today</span><strong><?php echo number_format($stats['today']); ?></strong></div><div class="stat"><span>Overdue</span><strong><?php echo number_format($stats['overdue']); ?></strong></div></section>
<section class="panel"><div class="panel-title">Run Notification Processor</div><div class="panel-note">The processor sends only the scheduled reminder milestones: 7, 3, 1, and 0 days before due date, plus 1, 7, and 30 days overdue. Each milestone is logged once per loan and due date.</div><div class="run"><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="action" value="run_notifications"><button type="submit"><i class="bx bx-mail-send"></i> Run Now</button></form></div></section>
<section class="panel"><div class="panel-title">Loan Reminder Candidates</div><div class="table-wrap"><table class="table"><thead><tr><th>Loan / Member</th><th>Due Date</th><th>Days</th><th>Balance</th><th>State</th><th>Email</th></tr></thead><tbody><?php if($candidates): foreach($candidates as $c): ?><tr><td><strong><?php echo htmlspecialchars($c['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($c['member_number'].' — '.$c['first_name'].' '.$c['last_name'],ENT_QUOTES,'UTF-8'); ?></span></td><td><?php echo htmlspecialchars($c['next_due_date'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo (int)$c['days_until_due']; ?></td><td class="money">₱<?php echo number_format((float)$c['remaining_balance'],2); ?></td><td><span class="badge <?php echo $c['reminder_state']==='Overdue'?'overdue':($c['reminder_state']==='Due today'?'today':''); ?>"><?php echo htmlspecialchars($c['reminder_state'],ENT_QUOTES,'UTF-8'); ?></span></td><td><?php echo htmlspecialchars($c['email'],ENT_QUOTES,'UTF-8'); ?></td></tr><?php endforeach; else: ?><tr><td colspan="6" class="empty">No active loan notification candidates found.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="panel"><div class="panel-title">Recent Notification Log</div><div class="table-wrap"><table class="table"><thead><tr><th>Loan / Member</th><th>Type</th><th>Reference Date</th><th>Recipient</th><th>Status</th><th>Sent</th></tr></thead><tbody><?php if($logs): foreach($logs as $log): ?><tr><td><strong><?php echo htmlspecialchars($log['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($log['first_name'].' '.$log['last_name'],ENT_QUOTES,'UTF-8'); ?></span></td><td><?php echo htmlspecialchars(str_replace('_',' ', $log['notification_type']),ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($log['reference_date'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($log['recipient_email'],ENT_QUOTES,'UTF-8'); ?></td><td><span class="badge <?php echo $log['status']==='sent'?'sent':'failed'; ?>"><?php echo htmlspecialchars($log['status'],ENT_QUOTES,'UTF-8'); ?></span><?php if(!empty($log['error_message'])): ?><span class="sub"><?php echo htmlspecialchars($log['error_message'],ENT_QUOTES,'UTF-8'); ?></span><?php endif; ?></td><td><?php echo htmlspecialchars($log['sent_at'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td></tr><?php endforeach; else: ?><tr><td colspan="6" class="empty">No notification attempts recorded yet.</td></tr><?php endif; ?></tbody></table></div></section>
</main><?php pascco_global_footer(); ?></body></html>
