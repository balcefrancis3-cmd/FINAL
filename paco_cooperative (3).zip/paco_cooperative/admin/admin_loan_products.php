<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';

require_admin();

$message = '';
$error = '';

try {
    $pdo->query('SELECT id FROM loan_products LIMIT 1');
    $pdo->query('SELECT id, interest_rate_basis FROM loan_brackets LIMIT 1');
    $schema_ready = true;
} catch (Throwable $exception) {
    $schema_ready = false;
    error_log('PASCCO loan configuration schema check failed: ' . $exception->getMessage());
    $error = 'Loan configuration tables are not fully installed. Back up the database, then verify database_migration_loan_system_step1.sql and database_migration_loan_system_step2.sql have been applied.';
}

if ($schema_ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'save_product') {
            $id = (int) ($_POST['product_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

            if ($name === '' || mb_strlen($name) > 120) {
                throw new RuntimeException('Enter a loan product name up to 120 characters.');
            }
            if (mb_strlen($description) > 500) {
                throw new RuntimeException('The product description must be 500 characters or fewer.');
            }

            if ($id > 0) {
                $existingProduct = $pdo->prepare('SELECT id FROM loan_products WHERE id = ? LIMIT 1');
                $existingProduct->execute([$id]);
                if (!$existingProduct->fetchColumn()) throw new RuntimeException('The product selected for editing no longer exists. Refresh the page and try again.');
                $stmt = $pdo->prepare('UPDATE loan_products SET name = ?, description = ?, status = ? WHERE id = ?');
                $stmt->execute([$name, $description !== '' ? $description : null, $status, $id]);
                record_audit($pdo, (int) $_SESSION['user_id'], 'loan_product_update', 'Updated loan product ' . $id, 'success');
                $message = 'Loan product updated.';
            } else {
                $stmt = $pdo->prepare('INSERT INTO loan_products (name, description, status) VALUES (?, ?, ?)');
                $stmt->execute([$name, $description !== '' ? $description : null, $status]);
                record_audit($pdo, (int) $_SESSION['user_id'], 'loan_product_create', 'Created loan product ' . (int) $pdo->lastInsertId(), 'success');
                $message = 'Loan product created.';
            }
        } elseif ($action === 'save_bracket') {
            $id = (int) ($_POST['bracket_id'] ?? 0);
            $productId = (int) ($_POST['loan_product_id'] ?? 0);
            $bracketName = trim($_POST['bracket_name'] ?? '');
            $minimumAmountRaw = trim((string) ($_POST['minimum_amount'] ?? ''));
            $maximumAmountRaw = trim((string) ($_POST['maximum_amount'] ?? ''));
            $minimumAmountCents = pascco_money_input_to_cents($minimumAmountRaw);
            $maximumAmountCents = pascco_money_input_to_cents($maximumAmountRaw);
            if ($minimumAmountCents === null || $maximumAmountCents === null) throw new RuntimeException('Loan bracket amounts must have no more than two decimal places.');
            $minimumAmount = pascco_money_from_cents($minimumAmountCents);
            $maximumAmount = pascco_money_from_cents($maximumAmountCents);
            $minimumIncomeRaw = trim($_POST['minimum_income'] ?? '');
            $maximumIncomeRaw = trim($_POST['maximum_income'] ?? '');
            $termMonths = (int) ($_POST['term_months'] ?? 0);
            $interestRateRaw = trim((string) ($_POST['interest_rate'] ?? ''));
            if ($interestRateRaw === '' || !preg_match('/^\d{1,3}(?:\.\d{1,4})?$/D', $interestRateRaw)) {
                throw new RuntimeException('Enter an interest rate using up to four decimal places, without a percent sign.');
            }
            $interestRate = (float) $interestRateRaw;
            $interestMethod = $_POST['interest_method'] ?? 'flat';
            $rateBasis = $_POST['interest_rate_basis'] ?? 'annual';
            $requiredSavingsRaw = trim($_POST['required_savings'] ?? '');
            $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

            $minimumIncomeCents = $minimumIncomeRaw === '' ? null : pascco_money_input_to_cents($minimumIncomeRaw);
            $maximumIncomeCents = $maximumIncomeRaw === '' ? null : pascco_money_input_to_cents($maximumIncomeRaw);
            $requiredSavingsCents = $requiredSavingsRaw === '' ? null : pascco_money_input_to_cents($requiredSavingsRaw);
            if (($minimumIncomeRaw !== '' && $minimumIncomeCents === null) || ($maximumIncomeRaw !== '' && $maximumIncomeCents === null) || ($requiredSavingsRaw !== '' && $requiredSavingsCents === null)) throw new RuntimeException('Income and savings amounts must have no more than two decimal places.');
            $minimumIncome = $minimumIncomeCents === null ? null : pascco_money_from_cents($minimumIncomeCents);
            $maximumIncome = $maximumIncomeCents === null ? null : pascco_money_from_cents($maximumIncomeCents);
            $requiredSavings = $requiredSavingsCents === null ? null : pascco_money_from_cents($requiredSavingsCents);

            if ($productId <= 0 || $bracketName === '' || mb_strlen($bracketName) > 80) {
                throw new RuntimeException('Select a product and enter a bracket name up to 80 characters.');
            }
            if ($minimumAmountCents <= 0 || $maximumAmountCents < $minimumAmountCents) {
                throw new RuntimeException('The maximum loan amount must be at least the minimum amount.');
            }
            if ($minimumIncomeCents !== null && $minimumIncomeCents < 0) {
                throw new RuntimeException('Minimum income cannot be negative.');
            }
            if ($maximumIncomeCents !== null && ($maximumIncomeCents < 0 || ($minimumIncomeCents !== null && $maximumIncomeCents < $minimumIncomeCents))) {
                throw new RuntimeException('Check the income range.');
            }
            if ($termMonths <= 0 || $termMonths > 120) {
                throw new RuntimeException('Loan term must be between 1 and 120 months.');
            }
            if ($interestRate < 0 || $interestRate > 100) {
                throw new RuntimeException('Interest rate must be between 0% and 100%.');
            }
            if (!in_array($interestMethod, ['flat', 'reducing_balance'], true)) {
                throw new RuntimeException('Invalid interest method.');
            }
            if (!in_array($rateBasis, ['annual', 'term'], true)) {
                throw new RuntimeException('Invalid interest-rate basis.');
            }
            if ($interestMethod === 'reducing_balance' && $rateBasis !== 'annual') {
                throw new RuntimeException('Reducing-balance calculations require an annual rate basis.');
            }
            if ($requiredSavingsCents !== null && $requiredSavingsCents < 0) {
                throw new RuntimeException('Required savings cannot be negative.');
            }

            $productCheck = $pdo->prepare('SELECT id FROM loan_products WHERE id = ? LIMIT 1');
            $productCheck->execute([$productId]);
            if (!$productCheck->fetch()) {
                throw new RuntimeException('Selected loan product does not exist.');
            }

            if ($status === 'active') {
                $overlapSql = "SELECT id FROM loan_brackets WHERE loan_product_id = ? AND status = 'active' AND minimum_amount <= ? AND maximum_amount >= ?";
                $overlapParams = [$productId, $maximumAmount, $minimumAmount];
                if ($id > 0) {
                    $overlapSql .= ' AND id <> ?';
                    $overlapParams[] = $id;
                }
                $overlapCheck = $pdo->prepare($overlapSql . ' LIMIT 1');
                $overlapCheck->execute($overlapParams);
                if ($overlapCheck->fetch()) {
                    throw new RuntimeException('This active bracket overlaps another active bracket for the same product. Use non-overlapping amount ranges.');
                }
            }

            if ($id > 0) {
                $existingBracket = $pdo->prepare('SELECT id FROM loan_brackets WHERE id = ? LIMIT 1');
                $existingBracket->execute([$id]);
                if (!$existingBracket->fetchColumn()) {
                    throw new RuntimeException('The bracket selected for editing no longer exists. Refresh the page and try again.');
                }
            }

            if ($id > 0) {
                $stmt = $pdo->prepare('UPDATE loan_brackets SET loan_product_id = ?, bracket_name = ?, minimum_amount = ?, maximum_amount = ?, minimum_income = ?, maximum_income = ?, term_months = ?, interest_rate = ?, interest_rate_basis = ?, interest_method = ?, required_savings = ?, status = ? WHERE id = ?');
                $stmt->execute([$productId, $bracketName, $minimumAmount, $maximumAmount, $minimumIncome, $maximumIncome, $termMonths, $interestRate, $rateBasis, $interestMethod, $requiredSavings, $status, $id]);
                if ($stmt->rowCount() === 0) {
                    $verifyUpdated = $pdo->prepare('SELECT id FROM loan_brackets WHERE id = ? LIMIT 1');
                    $verifyUpdated->execute([$id]);
                    if (!$verifyUpdated->fetchColumn()) throw new RuntimeException('The bracket could not be found for updating.');
                }
                record_audit($pdo, (int) $_SESSION['user_id'], 'loan_bracket_update', 'Updated loan bracket ' . $id, 'success');
                $message = 'Loan bracket updated.';
            } else {
                $stmt = $pdo->prepare('INSERT INTO loan_brackets (loan_product_id, bracket_name, minimum_amount, maximum_amount, minimum_income, maximum_income, term_months, interest_rate, interest_rate_basis, interest_method, required_savings, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$productId, $bracketName, $minimumAmount, $maximumAmount, $minimumIncome, $maximumIncome, $termMonths, $interestRate, $rateBasis, $interestMethod, $requiredSavings, $status]);
                record_audit($pdo, (int) $_SESSION['user_id'], 'loan_bracket_create', 'Created loan bracket for product ' . $productId, 'success');
                $message = 'Loan bracket created.';
            }
        } elseif ($action === 'toggle_product') {
            $id = (int) ($_POST['product_id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Select a valid loan product.');
            $stmt = $pdo->prepare("UPDATE loan_products SET status = IF(status = 'active', 'inactive', 'active') WHERE id = ?");
            $stmt->execute([$id]);
            if ($stmt->rowCount() !== 1) throw new RuntimeException('The selected loan product could not be found.');
            record_audit($pdo, (int) $_SESSION['user_id'], 'loan_product_toggle', 'Toggled loan product ' . $id, 'success');
            $message = 'Loan product status updated.';
        } elseif ($action === 'toggle_bracket') {
            $id = (int) ($_POST['bracket_id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Select a valid loan bracket.');
            $currentBracketStmt = $pdo->prepare('SELECT id, loan_product_id, bracket_name, minimum_amount, maximum_amount, status FROM loan_brackets WHERE id = ? LIMIT 1');
            $currentBracketStmt->execute([$id]);
            $currentBracket = $currentBracketStmt->fetch(PDO::FETCH_ASSOC);
            if (!$currentBracket) throw new RuntimeException('The selected loan bracket could not be found.');
            if ($currentBracket['status'] !== 'active') {
                $parentStmt = $pdo->prepare("SELECT status FROM loan_products WHERE id = ? LIMIT 1");
                $parentStmt->execute([(int) $currentBracket['loan_product_id']]);
                if ($parentStmt->fetchColumn() !== 'active') throw new RuntimeException('Activate the loan product before activating its bracket.');
                $overlapStmt = $pdo->prepare("SELECT id FROM loan_brackets WHERE loan_product_id = ? AND status = 'active' AND minimum_amount <= ? AND maximum_amount >= ? AND id <> ? LIMIT 1");
                $overlapStmt->execute([(int) $currentBracket['loan_product_id'], $currentBracket['maximum_amount'], $currentBracket['minimum_amount'], $id]);
                if ($overlapStmt->fetchColumn()) throw new RuntimeException('This bracket overlaps another active bracket. Adjust the amount range before activating it.');
            }
            $stmt = $pdo->prepare("UPDATE loan_brackets SET status = IF(status = 'active', 'inactive', 'active') WHERE id = ?");
            $stmt->execute([$id]);
            if ($stmt->rowCount() !== 1) throw new RuntimeException('The selected loan bracket could not be updated.');
            record_audit($pdo, (int) $_SESSION['user_id'], 'loan_bracket_toggle', 'Toggled loan bracket ' . $id, 'success');
            $message = 'Loan bracket status updated.';
        }
    } catch (Throwable $exception) {
        if ((string) $exception->getCode() === '23000') {
            $error = 'That product or bracket name already exists.';
        } elseif ($exception instanceof RuntimeException || $exception instanceof InvalidArgumentException) {
            $error = $exception->getMessage();
        } else {
            error_log('PASCCO loan configuration error: ' . $exception->getMessage());
            $error = 'The loan configuration could not be saved. Please review the values and try again.';
        }
    }
}

$products = [];
$brackets = [];
$editProduct = null;
$editBracket = null;
if ($schema_ready) {
    $products = $pdo->query("SELECT p.id, p.name, p.description, p.status, p.created_at, p.updated_at, (SELECT COUNT(*) FROM loan_brackets b WHERE b.loan_product_id = p.id AND b.status = 'active') AS active_bracket_count FROM loan_products p ORDER BY p.name")->fetchAll();
    $brackets = $pdo->query("SELECT b.*, p.name AS product_name FROM loan_brackets b JOIN loan_products p ON p.id = b.loan_product_id ORDER BY p.name, b.minimum_amount, b.id")->fetchAll();
    $editProductId = (int) ($_GET['edit_product'] ?? 0);
    $editBracketId = (int) ($_GET['edit_bracket'] ?? 0);
    if ($editProductId > 0) {
        $editStmt = $pdo->prepare('SELECT id, name, description, status FROM loan_products WHERE id = ? LIMIT 1');
        $editStmt->execute([$editProductId]);
        $editProduct = $editStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if ($editBracketId > 0) {
        $editStmt = $pdo->prepare('SELECT * FROM loan_brackets WHERE id = ? LIMIT 1');
        $editStmt->execute([$editBracketId]);
        $editBracket = $editStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
}

function h(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
<title>Loan Products | PASCCO Admin</title>
<style>
:root{--navy:#071d49;--blue:#1456a0;--blue2:#2b74c8;--gold:#e7b84b;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb;--surface:#fff;--danger:#b52f38;--success:#1c7442;--shadow:0 16px 40px rgba(7,29,73,.08)}
*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Poppins,Arial,sans-serif}.wrap{width:min(100% - 40px,1250px);margin:auto;padding:34px 0 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:22px}.eyebrow{color:var(--blue);font-size:.74rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.head h1{margin:8px 0 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem)}.head p{margin:10px 0 0;color:var(--muted);line-height:1.6}.back{display:inline-flex;padding:11px 15px;border:1px solid #cdd8e5;border-radius:11px;background:#fff;color:var(--navy);text-decoration:none;font-weight:800}.notice{padding:14px 16px;border-radius:12px;margin-bottom:18px;font-weight:700}.notice.success{background:#e8f6ee;color:var(--success);border:1px solid #c6e7d3}.notice.error{background:#fdeced;color:var(--danger);border:1px solid #f1c7cb}.grid{display:grid;grid-template-columns:minmax(280px,.7fr) minmax(0,1.3fr);gap:20px;margin-bottom:20px}.card{background:#fff;border:1px solid rgba(7,29,73,.07);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}.card h2{margin:0;color:var(--navy);font-size:1.1rem}.card-head{padding:20px 22px;border-bottom:1px solid var(--line)}.card-body{padding:22px}.fields{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field.full{grid-column:1/-1}.field label{display:block;margin-bottom:6px;font-size:.76rem;font-weight:800;color:var(--navy)}.field input,.field select,.field textarea{width:100%;padding:11px 12px;border:1px solid #cbd7e7;border-radius:10px;background:#fbfdff;color:var(--ink);font:inherit}.field textarea{min-height:86px;resize:vertical}.actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:16px}.btn{border:0;border-radius:10px;padding:11px 14px;font:inherit;font-weight:800;cursor:pointer}.btn.primary{background:var(--blue);color:#fff}.btn.gold{background:var(--gold);color:var(--navy)}.btn.light{background:#f0f4f9;color:var(--navy)}.btn.danger{background:#fde7e7;color:#a52f37}.hint{display:block;color:var(--muted);font-size:.72rem;line-height:1.45;margin-top:5px}.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;min-width:900px}.table th,.table td{padding:12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.79rem}.table th{background:#f3f7fc;color:var(--navy);font-weight:800}.pill{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:.68rem;font-weight:800;text-transform:uppercase}.pill.active{background:#e4f6ea;color:#17673b}.pill.inactive{background:#edf0f4;color:#667487}.small-actions{display:flex;gap:6px;flex-wrap:wrap}.small-actions form{margin:0}.empty{padding:24px;text-align:center;color:var(--muted)}.policy-note{padding:14px 16px;background:#fff8df;border:1px solid #f0dda2;border-radius:12px;color:#6f5410;line-height:1.55;font-size:.82rem;margin-bottom:20px}@media(max-width:900px){.grid{grid-template-columns:1fr}.head{align-items:flex-start;flex-direction:column}}@media(max-width:600px){.wrap{width:min(100% - 24px,1250px)}.fields{grid-template-columns:1fr}.field.full{grid-column:auto}.card-body{padding:17px}}
</style>
<link rel="stylesheet" href="/paco_cooperative/assets/css/pascco-loan-phase5.css?v=1">
</head>
<body>
<?php pascco_admin_header(); ?>
<main class="wrap">
    <header class="head">
        <div><div class="eyebrow">Credit configuration</div><h1>Loan Products &amp; Brackets</h1><p>Maintain the cooperative-approved loan products, eligibility ranges, terms, savings requirements, and interest settings used by member applications.</p></div>
        <a class="back" href="/paco_cooperative/admin/admin_loans.php">← Loan Approvals</a>
    </header>

    <div class="policy-note"><strong>Important:</strong> this page does not define PASCCO policy for you. Enter only the actual approved figures from your cooperative rules. Member applications use active brackets; inactive products and brackets cannot be selected.</div>

    <?php if($message): ?><div class="notice success"><?php echo h($message); ?></div><?php endif; ?>
    <?php if($error): ?><div class="notice error"><?php echo h($error); ?></div><?php endif; ?>

    <?php if($schema_ready): ?>
    <div class="grid">
        <section class="card">
            <div class="card-head"><h2><?php echo $editProduct ? 'Edit Loan Product' : 'Add Loan Product'; ?></h2></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="save_product">
                    <input type="hidden" name="product_id" value="<?php echo (int)($editProduct['id'] ?? 0); ?>">
                    <div class="fields">
                        <div class="field full"><label>Product Name</label><input name="name" maxlength="120" required value="<?php echo h($editProduct['name'] ?? ''); ?>" placeholder="e.g. Livelihood Loan"></div>
                        <div class="field full"><label>Description</label><textarea name="description" maxlength="500" placeholder="Short description shown to members."><?php echo h($editProduct['description'] ?? ''); ?></textarea></div>
                        <div class="field"><label>Status</label><select name="status"><option value="active" <?php echo (($editProduct['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option><option value="inactive" <?php echo (($editProduct['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option></select></div>
                    </div>
                    <div class="actions"><button class="btn primary" type="submit"><?php echo $editProduct ? 'Update Product' : 'Save Product'; ?></button><?php if ($editProduct): ?> <a class="btn light" href="/paco_cooperative/admin/admin_loan_products.php">Cancel edit</a><?php endif; ?></div>
                </form>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><h2>Configured Products</h2></div>
            <div class="table-wrap">
                <?php if($products): ?><table class="table"><thead><tr><th>ID</th><th>Product</th><th>Description</th><th>Configuration</th><th>Status</th><th>Action</th></tr></thead><tbody>
                <?php foreach($products as $product): ?><tr><td><?php echo (int)$product['id']; ?></td><td><strong><?php echo h($product['name']); ?></strong></td><td><?php echo h($product['description'] ?: '—'); ?></td><td><?php if ((int)$product['active_bracket_count'] > 0): ?><span class="pill active"><?php echo (int)$product['active_bracket_count']; ?> active bracket(s)</span><?php else: ?><span class="pill inactive">Needs bracket setup</span><?php endif; ?></td><td><span class="pill <?php echo h($product['status']); ?>"><?php echo h($product['status']); ?></span></td><td><div class="small-actions"><a class="btn light" href="?edit_product=<?php echo (int)$product['id']; ?>">Edit</a><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="toggle_product"><input type="hidden" name="product_id" value="<?php echo (int)$product['id']; ?>"><button class="btn light" type="submit"><?php echo $product['status']==='active'?'Deactivate':'Activate'; ?></button></form></div></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No loan products found.</div><?php endif; ?>
            </div>
        </section>
    </div>

    <section class="card">
        <div class="card-head"><h2><?php echo $editBracket ? 'Edit Loan Bracket' : 'Add Loan Bracket'; ?></h2></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="save_bracket">
                <input type="hidden" name="bracket_id" value="<?php echo (int)($editBracket['id'] ?? 0); ?>">
                <div class="fields">
                    <div class="field"><label>Loan Product</label><select name="loan_product_id" required><option value="">Choose product</option><?php foreach($products as $product): ?><option value="<?php echo (int)$product['id']; ?>" <?php echo ((int)($editBracket['loan_product_id'] ?? 0) === (int)$product['id']) ? 'selected' : ''; ?>><?php echo h($product['name']); ?><?php echo $product['status']==='inactive'?' (inactive)':''; ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label>Bracket Name</label><input name="bracket_name" maxlength="80" required value="<?php echo h($editBracket['bracket_name'] ?? ''); ?>" placeholder="e.g. Regular Member Tier 1"></div>
                    <div class="field"><label>Status</label><select name="status"><option value="active" <?php echo (($editBracket['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option><option value="inactive" <?php echo (($editBracket['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option></select></div>
                    <div class="field"><label>Minimum Loan Amount (PHP)</label><input type="number" name="minimum_amount" min="0.01" step="0.01" required value="<?php echo h(isset($editBracket['minimum_amount']) ? (string)$editBracket['minimum_amount'] : ''); ?>"></div>
                    <div class="field"><label>Maximum Loan Amount (PHP)</label><input type="number" name="maximum_amount" min="0.01" step="0.01" required value="<?php echo h(isset($editBracket['maximum_amount']) ? (string)$editBracket['maximum_amount'] : ''); ?>"></div>
                    <div class="field"><label>Minimum Monthly Income (PHP)</label><input type="number" name="minimum_income" min="0" step="0.01" placeholder="Optional" value="<?php echo h(isset($editBracket['minimum_income']) ? (string)$editBracket['minimum_income'] : ''); ?>"></div>
                    <div class="field"><label>Maximum Monthly Income (PHP)</label><input type="number" name="maximum_income" min="0" step="0.01" placeholder="Optional" value="<?php echo h(isset($editBracket['maximum_income']) ? (string)$editBracket['maximum_income'] : ''); ?>"></div>
                    <div class="field"><label>Term (Months)</label><input type="number" name="term_months" min="1" max="120" required value="<?php echo h(isset($editBracket['term_months']) ? (string)$editBracket['term_months'] : ''); ?>"></div>
                    <div class="field"><label>Interest Rate (%)</label><input type="number" name="interest_rate" min="0" max="100" step="0.0001" required value="<?php echo h(isset($editBracket['interest_rate']) ? (string)$editBracket['interest_rate'] : ''); ?>"></div>
                    <div class="field"><label>Rate Basis</label><select name="interest_rate_basis"><option value="annual" <?php echo (($editBracket['interest_rate_basis'] ?? 'annual') === 'annual') ? 'selected' : ''; ?>>Annual rate</option><option value="term" <?php echo (($editBracket['interest_rate_basis'] ?? '') === 'term') ? 'selected' : ''; ?>>Rate for entire term</option></select></div>
                    <div class="field"><label>Interest Method</label><select name="interest_method"><option value="flat" <?php echo (($editBracket['interest_method'] ?? 'flat') === 'flat') ? 'selected' : ''; ?>>Flat</option><option value="reducing_balance" <?php echo (($editBracket['interest_method'] ?? '') === 'reducing_balance') ? 'selected' : ''; ?>>Reducing balance</option></select></div>
                    <div class="field"><label>Required Savings (PHP)</label><input type="number" name="required_savings" min="0" step="0.01" placeholder="Optional" value="<?php echo h(isset($editBracket['required_savings']) ? (string)$editBracket['required_savings'] : ''); ?>"></div>
                </div>
                <small class="hint">For reducing-balance calculations, the system requires an annual rate. The member application will calculate the repayment estimate from the configured bracket.</small>
                <div class="actions"><button class="btn gold" type="submit"><?php echo $editBracket ? 'Update Bracket' : 'Save Bracket'; ?></button><?php if ($editBracket): ?> <a class="btn light" href="/paco_cooperative/admin/admin_loan_products.php">Cancel edit</a><?php endif; ?></div>
            </form>
        </div>
    </section>

    <section class="card" style="margin-top:20px">
        <div class="card-head"><h2>Configured Brackets</h2></div>
        <div class="table-wrap">
            <?php if($brackets): ?><table class="table"><thead><tr><th>ID</th><th>Product / Bracket</th><th>Loan Range</th><th>Income Range</th><th>Term</th><th>Interest</th><th>Savings</th><th>Status</th><th>Action</th></tr></thead><tbody>
            <?php foreach($brackets as $bracket): ?><tr><td><?php echo (int)$bracket['id']; ?></td><td><strong><?php echo h($bracket['product_name']); ?></strong><span style="display:block;color:#6e7e93;margin-top:3px"><?php echo h($bracket['bracket_name']); ?></span></td><td>₱<?php echo number_format((float)$bracket['minimum_amount'],2); ?> – ₱<?php echo number_format((float)$bracket['maximum_amount'],2); ?></td><td><?php echo $bracket['minimum_income']===null?'Any':'₱'.number_format((float)$bracket['minimum_income'],2); ?> – <?php echo $bracket['maximum_income']===null?'Any':'₱'.number_format((float)$bracket['maximum_income'],2); ?></td><td><?php echo (int)$bracket['term_months']; ?> mo.</td><td><?php echo number_format((float)$bracket['interest_rate'],4); ?>%<span class="sub"><?php echo h($bracket['interest_rate_basis']); ?> · <?php echo h(str_replace('_',' ', $bracket['interest_method'])); ?></span></td><td><?php echo $bracket['required_savings']===null?'None':'₱'.number_format((float)$bracket['required_savings'],2); ?></td><td><span class="pill <?php echo h($bracket['status']); ?>"><?php echo h($bracket['status']); ?></span></td><td><div class="small-actions"><a class="btn light" href="?edit_bracket=<?php echo (int)$bracket['id']; ?>">Edit</a><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>"><input type="hidden" name="action" value="toggle_bracket"><input type="hidden" name="bracket_id" value="<?php echo (int)$bracket['id']; ?>"><button class="btn light" type="submit"><?php echo $bracket['status']==='active'?'Deactivate':'Activate'; ?></button></form></div></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No brackets configured yet. Add the cooperative-approved brackets above before members submit new loan applications.</div><?php endif; ?>
        </div>
    </section>
    <?php endif; ?>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
