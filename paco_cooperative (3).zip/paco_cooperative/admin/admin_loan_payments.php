<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_shell.php';
require_once __DIR__ . '/../includes/loan_engine.php';

require_admin();

$message = '';
$error = '';
$idempotency_key = bin2hex(random_bytes(32));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'record_external_payment') {
    verify_csrf();
    $idempotency_key = trim($_POST['idempotency_key'] ?? '');
    if (!preg_match('/^[a-f0-9]{64}$/', $idempotency_key)) {
        $error = 'This payment form is no longer valid. Please reload the page and try again.';
    }
    $loanId = (int) ($_POST['loan_id'] ?? 0);
    $amount_raw = trim((string) ($_POST['amount'] ?? ''));
    $amount_cents = pascco_money_input_to_cents($amount_raw);
    $amount = $amount_cents === null ? '0.00' : pascco_money_from_cents($amount_cents);
    $method = trim($_POST['payment_method'] ?? '');
    $receipt = trim($_POST['receipt_number'] ?? '');
    $externalReference = trim($_POST['external_reference'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($receipt === '') {
        $receipt = 'EXT-' . date('YmdHis') . '-' . random_int(100000, 999999);
    }

    if ($error !== '') {
        // Idempotency validation already assigned an error.
    } elseif ($loanId <= 0 || $amount_cents === null || $amount_cents <= 0 || $method === '') {
        $error = 'Loan, payment method, and a payment amount are required.';
    } else {
        try {
            $pdo->beginTransaction();
            pascco_record_external_loan_payment($pdo, $loanId, $amount, $method, $receipt, $externalReference, $notes, (int) $_SESSION['user_id'], $idempotency_key);
            $pdo->commit();
            record_audit($pdo, (int) $_SESSION['user_id'], 'loan_external_payment', 'Recorded external loan payment for loan ' . $loanId . ' with receipt ' . $receipt, 'success');
            $message = 'External loan payment recorded and allocated to the repayment schedule.';
            $idempotency_key = bin2hex(random_bytes(32));
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $exception->getMessage();
        }
    }
}

pascco_refresh_overdue_loan_payments($pdo);

$loansStmt = $pdo->query("SELECT l.id, l.loan_number, l.loan_product, l.remaining_balance, l.status, m.first_name, m.last_name, m.member_number, l.next_due_date FROM loans l JOIN members m ON m.id = l.member_id WHERE l.status IN ('approved','disbursed','active') AND l.remaining_balance > 0 ORDER BY l.next_due_date IS NULL, l.next_due_date, l.id DESC");
$loans = $loansStmt->fetchAll();

$receiptsStmt = $pdo->query("SELECT r.id AS receipt_id, r.receipt_number, r.amount, r.payment_method, r.external_reference, r.received_at, l.loan_number, m.first_name, m.last_name FROM loan_payment_receipts r JOIN loans l ON l.id = r.loan_id JOIN members m ON m.id = l.member_id ORDER BY r.id DESC LIMIT 30");
$receipts = $receiptsStmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Loan Payments | PASCCO</title>
<?php pascco_global_styles(); ?>
<style>
:root{--navy:#071d49;--blue:#1456a0;--gold:#e7b84b;--bg:#f4f7fb;--line:#d8e0ee;--muted:#6e7e93;--danger:#b8323b}body{margin:0;background:var(--bg);color:#18324f;font-family:Poppins,Arial,sans-serif}.wrap{width:min(1180px,calc(100% - 32px));margin:30px auto 60px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}.eyebrow{color:var(--blue);font-size:.73rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.head h1{margin:7px 0;color:var(--navy);font-size:clamp(2rem,4vw,2.7rem)}.head p{margin:0;color:var(--muted)}.back{display:inline-flex;gap:7px;align-items:center;border:1px solid var(--line);background:#fff;color:var(--navy);padding:10px 14px;border-radius:9px;text-decoration:none;font-weight:800}.grid{display:grid;grid-template-columns:1fr 1.2fr;gap:18px}.surface{background:#fff;border:1px solid var(--line);border-radius:17px;overflow:hidden}.surface h2{margin:0;padding:18px;border-bottom:1px solid var(--line);color:var(--navy);font-size:1.05rem}.body{padding:18px}.msg{padding:12px 14px;border-radius:10px;margin-bottom:16px;font-weight:700}.success{background:#e7f5ec;color:#17673b}.error{background:#fde7e7;color:#9d2933}.field{margin-bottom:13px}.field label{display:block;margin-bottom:6px;color:var(--navy);font-weight:800;font-size:.78rem}.field input,.field select,.field textarea{width:100%;box-sizing:border-box;padding:10px 11px;border:1px solid #cbd7e4;border-radius:9px;font:inherit}.field textarea{min-height:85px;resize:vertical}.hint{font-size:.72rem;color:var(--muted);margin-top:5px;line-height:1.4}.submit{width:100%;border:0;border-radius:10px;padding:11px 14px;background:var(--blue);color:#fff;font:inherit;font-weight:800;cursor:pointer}.table-wrap{overflow:auto}.table{width:100%;min-width:780px;border-collapse:collapse}.table th,.table td{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left;font-size:.78rem;vertical-align:top}.table th{background:#eef4fb;color:var(--navy);font-weight:800}.sub{display:block;color:#8794a4;font-size:.69rem;margin-top:3px}.money{color:var(--blue);font-weight:800}.empty{padding:25px;text-align:center;color:var(--muted)}@media(max-width:850px){.grid{grid-template-columns:1fr}.head{align-items:flex-start;flex-direction:column}}
</style>
</head>
<body>
<?php pascco_admin_header(); ?>
<main class="wrap">
<header class="head"><div><div class="eyebrow">Credit operations</div><h1>Record Loan Payment</h1><p>Post an external or over-the-counter payment and allocate it to the existing repayment schedule.</p></div><a class="back" href="/paco_cooperative/admin/admin_loan_servicing.php"><i class="bx bx-arrow-back"></i> Loan Servicing</a></header>
<?php if($message): ?><div class="msg success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<?php if($error): ?><div class="msg error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<div class="grid">
<section class="surface"><h2>Payment Entry</h2><div class="body"><form method="post"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="idempotency_key" value="<?php echo htmlspecialchars($idempotency_key,ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="action" value="record_external_payment"><div class="field"><label for="loan_id">Loan</label><select id="loan_id" name="loan_id" required><option value="">Select an active loan</option><?php foreach($loans as $loan): ?><option value="<?php echo (int)$loan['id']; ?>"><?php echo htmlspecialchars($loan['loan_number'].' — '.$loan['first_name'].' '.$loan['last_name'].' — ₱'.number_format((float)$loan['remaining_balance'],2),ENT_QUOTES,'UTF-8'); ?></option><?php endforeach; ?></select></div><div class="field"><label for="amount">Amount</label><input id="amount" type="number" name="amount" step="0.01" min="0.01" required><div class="hint">The system will reject an amount above the loan's remaining balance or available repayment schedule.</div></div><div class="field"><label for="payment_method">Payment Method</label><input id="payment_method" name="payment_method" maxlength="50" placeholder="e.g. Cash, Bank Transfer" required></div><div class="field"><label for="receipt_number">Receipt Number</label><input id="receipt_number" name="receipt_number" maxlength="60" placeholder="Leave blank to generate one"></div><div class="field"><label for="external_reference">External Reference</label><input id="external_reference" name="external_reference" maxlength="100" placeholder="Optional bank / payment reference"></div><div class="field"><label for="notes">Notes</label><textarea id="notes" name="notes" maxlength="500" placeholder="Optional collection notes"></textarea></div><button class="submit" type="submit"><i class="bx bx-check-circle"></i> Record Payment</button></form></div></section>
<section class="surface"><h2>Recent External Payment Receipts</h2><div class="table-wrap"><table class="table"><thead><tr><th>Receipt</th><th>Loan / Member</th><th>Amount</th><th>Method</th><th>Reference</th><th>Received</th></tr></thead><tbody><?php if($receipts): foreach($receipts as $r): ?><tr><td><strong><?php echo htmlspecialchars($r['receipt_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><a href="/paco_cooperative/member/loan_payment_receipt.php?receipt_id=<?php echo (int)$r['receipt_id']; ?>" target="_blank" rel="noopener">View receipt</a></span></td><td><strong><?php echo htmlspecialchars($r['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong><span class="sub"><?php echo htmlspecialchars($r['first_name'].' '.$r['last_name'],ENT_QUOTES,'UTF-8'); ?></span></td><td class="money">₱<?php echo number_format((float)$r['amount'],2); ?></td><td><?php echo htmlspecialchars($r['payment_method'],ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($r['external_reference'] ?: '—',ENT_QUOTES,'UTF-8'); ?></td><td><?php echo htmlspecialchars($r['received_at'],ENT_QUOTES,'UTF-8'); ?></td></tr><?php endforeach; else: ?><tr><td colspan="6" class="empty">No external loan payments recorded yet.</td></tr><?php endif; ?></tbody></table></div></section>
</div>
</main>
<?php pascco_global_footer(); ?>
</body></html>
