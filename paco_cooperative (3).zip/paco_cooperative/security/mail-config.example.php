<?php
// Copy this file to C:/xampp/pascco-private/mail.php and replace the placeholders.
return [
    'username' => 'your-smtp-account@example.com',
    'password' => 'your-smtp-app-password',
    'from_email' => 'your-smtp-account@example.com',
    'from_name' => 'Paco Savings and Credit Cooperative',
    // Use 'tls' with port 587, 'ssl' with port 465, or 'none' only for a trusted local relay.
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'encryption' => 'tls',
    'timeout' => 15,
];
