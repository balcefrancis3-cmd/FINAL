<?php
/**
 * PASCCO scheduled loan notification runner.
 * Run from Windows Task Scheduler / PHP CLI once per day.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI only.\n");
}

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/loan_engine.php';
require_once __DIR__ . '/../includes/loan_notifications.php';

pascco_refresh_overdue_loan_payments($pdo);
$summary = pascco_process_loan_notifications($pdo, static function (string $status, array $loan, string $type): void {
    echo strtoupper($status) . ' | ' . $type . ' | loan=' . $loan['loan_number'] . PHP_EOL;
});

echo PHP_EOL . 'Checked: ' . $summary['checked'] . PHP_EOL;
echo 'Eligible: ' . $summary['eligible'] . PHP_EOL;
echo 'Sent: ' . $summary['sent'] . PHP_EOL;
echo 'Failed: ' . $summary['failed'] . PHP_EOL;
echo 'Skipped: ' . $summary['skipped'] . PHP_EOL;
