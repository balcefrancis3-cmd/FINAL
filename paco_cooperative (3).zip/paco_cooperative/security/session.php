<?php
if (PHP_SAPI !== 'cli') {
    if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
        http_response_code(403); exit('PASCCO is available only on this computer.');
    }
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header('X-Permitted-Cross-Domain-Policies: none');
    // HSTS is only appropriate when the deployment is confirmed to use HTTPS.
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('PASCCOSESSID');
    $secureCookie = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(['lifetime' => 0, 'path' => '/paco_cooperative/', 'secure' => $secureCookie, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'] ?? '';
    $verificationMissing = false;

    if ($role === 'admin') {
        $verificationMissing = empty($_SESSION['mfa_verified']);
    }

    if ($role === 'member') {
        $verificationMissing = empty($_SESSION['email_otp_verified']);
    }

    $sessionExpired =
        time() - (int) ($_SESSION['last_activity'] ?? 0) > 1800 ||
        time() - (int) ($_SESSION['authenticated_at'] ?? 0) > 28800;

    if ($verificationMissing || $sessionExpired) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
}

if (isset($_SESSION['user_id'])) {
    $_SESSION['last_activity'] = time();
}
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
