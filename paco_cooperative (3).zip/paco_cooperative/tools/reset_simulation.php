<?php
/**
 * DANGEROUS, CLI-ONLY simulation reset. Dry-run is the default.
 * Run: php tools/reset_simulation.php
 * Execute: php tools/reset_simulation.php --execute --confirm=RESET-PASCCO-SIMULATION
 * It preserves users, members, accounts, loan_products, loan_brackets, announcements,
 * security settings, and audit_logs. It clears simulation activity and resets account balances to 0.
 * Back up first. Do not use on a production/real-money database.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found.\n"); }
$execute = in_array('--execute', $argv, true);
$confirmed = in_array('--confirm=RESET-PASCCO-SIMULATION', $argv, true);
$configPath = 'C:/xampp/pascco-private/config.php';
if (!is_file($configPath)) { fwrite(STDERR, "Private PASCCO config not found: {$configPath}\n"); exit(2); }
$config = require $configPath;
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=paco_cooperative;charset=utf8mb4', 'pascco_app', $config['db_password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (Throwable $e) { fwrite(STDERR, "Database connection failed. Check local PASCCO configuration.\n"); exit(2); }
$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$targets = [
    'loan_restructuring_executions','loan_restructuring_reviews','loan_restructuring_requests',
    'loan_closures','loan_collection_notes','loan_notification_logs','loan_payment_receipts',
    'loan_payment_allocations','loan_payments','loan_approval_reviews','transactions',
    'deposit_requests','withdrawal_requests','loans'
];
$existing = [];
foreach ($targets as $table) {
    $q = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
    $q->execute([$table]); if ((int)$q->fetchColumn() > 0) $existing[] = $table;
}
// Refuse to proceed if any table outside the reset allowlist references a table that will be cleared.
$placeholders = implode(',', array_fill(0, count($existing), '?'));
if ($existing) {
    $fkSql = "SELECT TABLE_NAME, REFERENCED_TABLE_NAME, CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME IN ({$placeholders}) AND TABLE_NAME NOT IN ({$placeholders})";
    $fk = $pdo->prepare($fkSql); $fk->execute(array_merge($existing, $existing)); $externalRefs = $fk->fetchAll();
    if ($externalRefs) {
        fwrite(STDERR, "Reset stopped: tables outside the approved reset list reference data scheduled for deletion:\n");
        foreach ($externalRefs as $r) fwrite(STDERR, "- {$r['TABLE_NAME']} references {$r['REFERENCED_TABLE_NAME']} ({$r['CONSTRAINT_NAME']})\n");
        fwrite(STDERR, "Review dependencies before changing the reset allowlist. No data was changed.\n"); exit(3);
    }
}
$counts = [];
foreach ($existing as $table) $counts[$table] = (int)$pdo->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
$accounts = (int)$pdo->query('SELECT COUNT(*) FROM accounts')->fetchColumn();
echo "PASCCO SIMULATION RESET — DATABASE: paco_cooperative\n";
echo "Accounts to preserve and reset to ₱0.00: {$accounts}\n";
foreach ($counts as $table=>$count) echo "Rows in {$table} to delete: {$count}\n";
echo "Preserved: users, members, accounts, loan_products, loan_brackets, announcements, settings, MFA/session data, and audit_logs. Uploaded files are not deleted.\n";
if (!$execute) { echo "DRY RUN ONLY. No changes made. To execute after a verified backup, use --execute --confirm=RESET-PASCCO-SIMULATION\n"; exit(0); }
if (!$confirmed) { fwrite(STDERR, "Execution requires --confirm=RESET-PASCCO-SIMULATION. No changes made.\n"); exit(2); }
try {
    $pdo->beginTransaction();
    // FK checks are disabled only for this connection, after rejecting external references.
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
    foreach ($existing as $table) $pdo->exec("DELETE FROM `{$table}`");
    $pdo->exec('UPDATE accounts SET balance = 0.00');
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    $pdo->commit();
    try { $stmt=$pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, status) VALUES (NULL, 'simulation_reset', ?, '127.0.0.1', 'success')"); $stmt->execute(['Simulation activity reset via CLI; accounts and configuration preserved.']); } catch (Throwable $e) { error_log('[PASCCO][simulation_reset_audit] ' . $e->getMessage()); }
    echo "Reset completed. Account balances are now ₱0.00; users, members, accounts, loan configuration, and audit logs were preserved.\n";
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    try { $pdo->exec('SET FOREIGN_KEY_CHECKS = 1'); } catch (Throwable $ignored) {}
    fwrite(STDERR, "Reset failed and was rolled back where supported. Review the PHP error log.\n"); error_log('[PASCCO][simulation_reset] ' . $e->getMessage()); exit(4);
}
