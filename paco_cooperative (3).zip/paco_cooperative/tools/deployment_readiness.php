<?php
/**
 * Read-only CLI deployment readiness inventory. It does not change configuration,
 * connect to the database, or make the local-only app remotely accessible.
 * Usage: php tools/deployment_readiness.php
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found.\n"); }
$root = dirname(__DIR__);
$checks = [];
$add = static function (string $status, string $label, string $detail = '') use (&$checks): void {
    $checks[] = [$status, $label, $detail];
};
$config = 'C:/xampp/pascco-private/config.php';
$add(is_file($config) ? 'PASS' : 'CHECK', 'Private database config', is_file($config) ? 'Found outside htdocs at expected local path.' : 'Not found at expected path; verify local setup.');
$session = @file_get_contents($root . '/security/session.php') ?: '';
$add(str_contains($session, "['127.0.0.1', '::1']") ? 'PASS' : 'FAIL', 'Local-only access guard', str_contains($session, "['127.0.0.1', '::1']") ? 'Current code restricts HTTP requests to loopback addresses.' : 'Expected localhost restriction was not detected.');
$headers = ['X-Content-Type-Options', 'X-Frame-Options', 'Referrer-Policy', 'Permissions-Policy'];
foreach ($headers as $header) $add(str_contains($session, $header . ':') ? 'PASS' : 'CHECK', 'Security header: ' . $header, str_contains($session, $header . ':') ? 'Configured in security/session.php.' : 'Not detected; review before any deployment.');
$add(str_contains($session, 'Strict-Transport-Security') ? 'PASS' : 'CHECK', 'HSTS handling', str_contains($session, 'Strict-Transport-Security') ? 'Header is conditional on HTTPS.' : 'Not detected. HSTS must only be enabled after HTTPS is confirmed.');
$htaccess = @file_get_contents($root . '/.htaccess') ?: '';
$add(str_contains($htaccess, 'Options -Indexes') ? 'PASS' : 'CHECK', 'Directory listing disabled', str_contains($htaccess, 'Options -Indexes') ? 'Root .htaccess disables directory indexes.' : 'Review Apache directory listing settings.');
$add(str_contains($htaccess, 'RewriteRule ^(tools|tests)') ? 'PASS' : 'CHECK', 'CLI tools blocked from HTTP', str_contains($htaccess, 'RewriteRule ^(tools|tests)') ? 'Root .htaccess denies web access to tools and tests.' : 'Review access restrictions for CLI-only files.');
foreach (['uploads/loan_documents/.htaccess', 'uploads/deposit_receipts/.htaccess', 'member/uploads/.htaccess'] as $rel) {
    $contents = @file_get_contents($root . '/' . $rel) ?: '';
    $add(str_contains($contents, 'Require all denied') ? 'PASS' : 'CHECK', 'Upload protection: ' . $rel, str_contains($contents, 'Require all denied') ? 'Direct web access denied by Apache 2.4 rule.' : 'Protection not detected; verify this directory cannot serve private documents.');
}
foreach (['pdo_mysql', 'openssl', 'fileinfo'] as $ext) $add(extension_loaded($ext) ? 'PASS' : 'CHECK', 'PHP extension: ' . $ext, extension_loaded($ext) ? 'Loaded in this CLI PHP runtime.' : 'Not loaded in this CLI PHP runtime; confirm required runtime support.');
$add('MANUAL', 'TLS/HTTPS', 'Not tested. Local XAMPP currently remains localhost-only; do not expose it to a LAN or the internet.');
$add('MANUAL', 'Backup restore drill', 'Not tested. Restore an encrypted backup into a separate disposable database and verify login, uploads, and financial records.');
$add('MANUAL', 'Security and privacy review', 'Not tested. Review access controls, consent/retention, incident response, and applicable Philippine requirements with a qualified reviewer.');
$counts = ['PASS'=>0, 'CHECK'=>0, 'FAIL'=>0, 'MANUAL'=>0];
echo "PASCCO DEPLOYMENT READINESS — READ ONLY\nProject: {$root}\nThis report is read-only: it does not change settings, connect to MySQL, or enable remote access; it is not a production certification.\n\n";
foreach ($checks as [$status, $label, $detail]) { $counts[$status] = ($counts[$status] ?? 0) + 1; echo "[{$status}] {$label}\n  {$detail}\n"; }
echo "\nTotals: PASS {$counts['PASS']} | CHECK {$counts['CHECK']} | FAIL {$counts['FAIL']} | MANUAL {$counts['MANUAL']}\n";
if ($counts['FAIL'] > 0) exit(2);
