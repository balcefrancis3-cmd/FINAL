<?php
/**
 * CLI-only migration inventory/tracker. It never executes SQL migration files.
 * Usage: php tools/migration_tracker.php list
 *        php tools/migration_tracker.php mark database_migration_x.sql --confirm=MARK-APPLIED
 * Mark only AFTER manually applying and verifying the migration in phpMyAdmin.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found.\n"); }
$root = dirname(__DIR__);
$configPath = 'C:/xampp/pascco-private/config.php';
if (!is_file($configPath)) { fwrite(STDERR, "Private PASCCO config not found: {$configPath}\n"); exit(2); }
$config = require $configPath;
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=paco_cooperative;charset=utf8mb4', 'pascco_app', $config['db_password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (Throwable $e) { fwrite(STDERR, "Database connection failed. Check local PASCCO configuration.\n"); exit(2); }
$action = $argv[1] ?? 'list';
$files = glob($root . '/database_migration*.sql') ?: [];
$files = array_merge($files, glob($root . '/security/schema.sql') ?: []);
$inventory = [];
foreach ($files as $file) {
    $name = basename($file);
    $inventory[$name] = hash_file('sha256', $file);
}
if ($action === 'list') {
    try { $tracked = $pdo->query('SELECT migration_name, checksum_sha256, applied_at, applied_by FROM schema_migrations ORDER BY migration_name')->fetchAll(); }
    catch (Throwable $e) { fwrite(STDERR, "Migration tracking table is missing. Import database_migration_phase5_tracking.sql first.\n"); exit(2); }
    $map = []; foreach ($tracked as $row) $map[$row['migration_name']] = $row;
    echo "Migration inventory (files are NOT executed by this tool)\n";
    foreach ($inventory as $name=>$checksum) {
        if (!isset($map[$name])) echo "[UNTRACKED] {$name}\n";
        elseif (!hash_equals($map[$name]['checksum_sha256'], $checksum)) echo "[CHECKSUM CHANGED] {$name} (recorded {$map[$name]['checksum_sha256']}; current {$checksum})\n";
        else echo "[TRACKED] {$name} — {$map[$name]['applied_at']} by {$map[$name]['applied_by']}\n";
    }
    exit(0);
}
if ($action !== 'mark' || empty($argv[2]) || !in_array('--confirm=MARK-APPLIED', $argv, true)) {
    fwrite(STDERR, "Usage:\n  php tools/migration_tracker.php list\n  php tools/migration_tracker.php mark <migration_filename.sql> --confirm=MARK-APPLIED\n"); exit(2);
}
$name = basename((string)$argv[2]);
if (!isset($inventory[$name])) { fwrite(STDERR, "Migration filename is not in the project inventory.\n"); exit(2); }
try {
    $stmt = $pdo->prepare('INSERT INTO schema_migrations (migration_name, checksum_sha256, applied_by, notes) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE checksum_sha256 = VALUES(checksum_sha256), applied_at = CURRENT_TIMESTAMP, applied_by = VALUES(applied_by), notes = VALUES(notes)');
    $stmt->execute([$name, $inventory[$name], 'local-admin-cli', 'Marked manually after external application and verification']);
    echo "Recorded {$name}. Reminder: this tool does not verify the migration's schema effects; mark only after you have applied and checked it.\n";
} catch (Throwable $e) { fwrite(STDERR, "Could not record migration. Ensure schema_migrations exists.\n"); exit(2); }
