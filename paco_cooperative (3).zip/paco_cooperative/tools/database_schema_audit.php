<?php
declare(strict_types=1);
/**
 * Read-only PASCCO schema inventory. Does not query member/financial row contents
 * and never executes migration SQL. Run from Command Prompt:
 *   php tools/database_schema_audit.php
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found.\n");
}
$configPath = 'C:/xampp/pascco-private/config.php';
if (!is_file($configPath)) {
    fwrite(STDERR, "Private PASCCO config not found: {$configPath}\n");
    exit(2);
}
$config = require $configPath;
if (!is_array($config) || !isset($config['db_password'])) {
    fwrite(STDERR, "PASCCO database configuration is incomplete.\n");
    exit(2);
}
try {
    $pdo = new PDO(
        'mysql:host=127.0.0.1;dbname=paco_cooperative;charset=utf8mb4',
        'pascco_app',
        (string) $config['db_password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
    );
    $pdo->exec('SET SESSION TRANSACTION READ ONLY');
    $pdo->beginTransaction();
    $schema = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
    $tables = $pdo->query(
        'SELECT TABLE_NAME, ENGINE, TABLE_ROWS FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = \'BASE TABLE\' ORDER BY TABLE_NAME'
    )->fetchAll();
    $columns = $pdo->query(
        'SELECT TABLE_NAME, COUNT(*) AS column_count FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() GROUP BY TABLE_NAME ORDER BY TABLE_NAME'
    )->fetchAll();
    $indexes = $pdo->query(
        'SELECT TABLE_NAME, COUNT(DISTINCT INDEX_NAME) AS index_count FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() GROUP BY TABLE_NAME ORDER BY TABLE_NAME'
    )->fetchAll();
    $foreignKeys = $pdo->query(
        'SELECT TABLE_NAME, COUNT(*) AS fk_count FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME IS NOT NULL GROUP BY TABLE_NAME ORDER BY TABLE_NAME'
    )->fetchAll();
    $pdo->commit();
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    fwrite(STDERR, "Schema inventory failed. Check local database availability and configuration; details withheld.\n");
    exit(2);
}
$columnMap = []; foreach ($columns as $row) $columnMap[$row['TABLE_NAME']] = (int) $row['column_count'];
$indexMap = []; foreach ($indexes as $row) $indexMap[$row['TABLE_NAME']] = (int) $row['index_count'];
$fkMap = []; foreach ($foreignKeys as $row) $fkMap[$row['TABLE_NAME']] = (int) $row['fk_count'];
echo "PASCCO read-only database schema inventory\n";
echo "Database: {$schema}\nTables found: " . count($tables) . "\n\n";
printf("%-38s %-12s %8s %8s %8s\n", 'TABLE', 'ENGINE', 'COLUMNS', 'INDEXES', 'FKs');
foreach ($tables as $table) {
    $name = (string) $table['TABLE_NAME'];
    printf("%-38s %-12s %8d %8d %8d\n", $name, (string) ($table['ENGINE'] ?? 'unknown'), $columnMap[$name] ?? 0, $indexMap[$name] ?? 0, $fkMap[$name] ?? 0);
}
echo "\nThis tool reads schema metadata only. It does not inspect row contents, alter tables, or run migrations.\n";
echo "Note: information_schema.TABLE_ROWS is intentionally not displayed because InnoDB values can be estimates.\n";
