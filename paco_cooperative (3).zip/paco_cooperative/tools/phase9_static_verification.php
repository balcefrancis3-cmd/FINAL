<?php
declare(strict_types=1);
/**
 * PASCCO Phase 9 static verification runner.
 * CLI only. Does not connect to MySQL, alter data, or apply migrations.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found\n");
}
$root = dirname(__DIR__);
function collectFiles(string $root, string $extension): array {
    $items = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if (!$file->isFile()) continue;
        $path = $file->getPathname();
        $relative = substr($path, strlen($root) + 1);
        if (str_starts_with($relative, 'vendor' . DIRECTORY_SEPARATOR) || str_starts_with($relative, '.git' . DIRECTORY_SEPARATOR)) continue;
        if (strtolower($file->getExtension()) === strtolower($extension)) $items[] = $path;
    }
    sort($items);
    return $items;
}
function runCommand(array $command, string $cwd): array {
    $spec = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $process = proc_open($command, $spec, $pipes, $cwd);
    if (!is_resource($process)) return [127, 'Could not start process'];
    fclose($pipes[0]);
    $stdout = stream_get_contents($pipes[1]); fclose($pipes[1]);
    $stderr = stream_get_contents($pipes[2]); fclose($pipes[2]);
    $status = proc_close($process);
    return [$status, trim($stdout . ($stderr !== '' ? "\n" . $stderr : ''))];
}
$phpFiles = collectFiles($root, 'php');
$jsFiles = collectFiles($root, 'js');
$phpFailures = [];
foreach ($phpFiles as $file) {
    [$code, $output] = runCommand([PHP_BINARY, '-l', $file], $root);
    if ($code !== 0) $phpFailures[] = substr($file, strlen($root) + 1) . ': ' . $output;
}
echo 'PHP syntax: ' . (count($phpFiles) - count($phpFailures)) . '/' . count($phpFiles) . " passed\n";
foreach ($phpFailures as $failure) echo "FAIL PHP: $failure\n";
$node = trim((string) shell_exec('command -v node 2>/dev/null'));
$jsFailures = [];
if ($node !== '') {
    foreach ($jsFiles as $file) {
        [$code, $output] = runCommand([$node, '--check', $file], $root);
        if ($code !== 0) $jsFailures[] = substr($file, strlen($root) + 1) . ': ' . $output;
    }
    echo 'JavaScript syntax: ' . (count($jsFiles) - count($jsFailures)) . '/' . count($jsFiles) . " passed\n";
    foreach ($jsFailures as $failure) echo "FAIL JS: $failure\n";
} else {
    echo "JavaScript syntax: SKIPPED (Node.js not found)\n";
}
$testFiles = glob($root . '/tests/*_tests.php') ?: [];
sort($testFiles);
$testFailures = [];
foreach ($testFiles as $file) {
    [$code, $output] = runCommand([PHP_BINARY, $file], $root);
    $label = basename($file);
    if ($code !== 0) $testFailures[] = $label . ': ' . $output;
    echo ($code === 0 ? 'PASS ' : 'FAIL ') . $label . "\n";
}
echo 'Static test scripts: ' . (count($testFiles) - count($testFailures)) . '/' . count($testFiles) . " passed\n";
foreach ($testFailures as $failure) echo "DETAIL: $failure\n";
$failed = count($phpFailures) + count($jsFailures) + count($testFailures);
echo $failed === 0 ? "RESULT: PASS (static checks only)\n" : "RESULT: FAIL ($failed failing checks)\n";
exit($failed === 0 ? 0 : 1);
