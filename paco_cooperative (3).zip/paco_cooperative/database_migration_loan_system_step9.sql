-- PASCCO Loan System Step 9 — Loan Closure and Clearance
-- Adds a formal closure record for fully paid loans without changing the existing loan status model.
-- Apply after database_migration_loan_system_step8.sql.

CREATE TABLE IF NOT EXISTS loan_closures (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    closure_reference VARCHAR(60) NOT NULL,
    cleared_by INT UNSIGNED NOT NULL,
    cleared_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes VARCHAR(500) DEFAULT NULL,
    UNIQUE KEY uq_loan_closure_loan (loan_id),
    UNIQUE KEY uq_loan_closure_reference (closure_reference),
    INDEX idx_loan_closures_date (cleared_at, id),
    CONSTRAINT fk_loan_closures_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_loan_closures_user FOREIGN KEY (cleared_by) REFERENCES users(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
