<?php
http_response_code(404);
header('Location: /paco_cooperative/public/login.php');
exit;