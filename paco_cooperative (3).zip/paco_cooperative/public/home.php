<?php
require_once __DIR__ . '/../includes/pascco_layout.php';
pascco_header('Home', 'home');
?>
<style>
    .home-hero { position: relative; overflow: hidden; border-radius: 0 0 28px 28px; background: linear-gradient(125deg, rgba(7,29,73,.98), rgba(20,86,160,.90)), url('/paco_cooperative/assets/images/paco2.png') center/cover; color: #fff; padding: clamp(42px, 8vw, 86px) clamp(24px, 7vw, 76px); box-shadow: 0 18px 45px rgba(7,29,73,.16); }
    .home-hero::after { content: ''; position: absolute; width: 260px; height: 260px; border-radius: 50%; right: -90px; top: -100px; background: rgba(231,184,75,.12); }
    .home-hero .eyebrow { color: #ffe7a1; }
    .home-hero h1 { color: #fff; max-width: 760px; margin-bottom: 22px; }
    .home-hero .intro { color: rgba(255,255,255,.9); max-width: 720px; font-size: 1.15rem; }
    .home-actions { margin-top: 28px; }
    .home-stats { display: grid; gap: 14px; grid-template-columns: repeat(3, minmax(0, 1fr)); margin-top: 34px; max-width: 760px; }
    .home-stat { background: rgba(255,255,255,.10); border: 1px solid rgba(255,255,255,.16); border-radius: 14px; padding: 16px 18px; backdrop-filter: blur(4px); }
    .home-stat strong { display:block; font-size: 1.02rem; color: #ffe7a1; margin-bottom: 4px; }
    .home-stat span { font-size: .92rem; color: rgba(255,255,255,.84); }
    .section-heading { display:flex; align-items:end; justify-content:space-between; gap:20px; margin-top: 54px; }
    .section-heading h2 { margin: 6px 0 0; color: #071d49; font-size: clamp(1.7rem, 3vw, 2.3rem); }
    .section-heading p { margin:0; max-width: 610px; line-height:1.65; }
    .feature-grid { display:grid; gap:20px; grid-template-columns: repeat(3, minmax(0,1fr)); margin-top:22px; }
    .feature-card { background:#fff; border:1px solid #d8e0ee; border-radius:18px; padding:28px; box-shadow:0 10px 28px rgba(7,29,73,.07); transition:transform .2s ease, box-shadow .2s ease; }
    .feature-card:hover { transform:translateY(-3px); box-shadow:0 15px 32px rgba(7,29,73,.11); }
    .feature-icon { width:48px; height:48px; border-radius:14px; display:grid; place-items:center; background:#e6edf8; color:#1456a0; font-size:1.45rem; margin-bottom:18px; }
    .feature-card h3 { color:#071d49; margin:0 0 9px; font-size:1.3rem; }
    .feature-card p { line-height:1.7; margin:0 0 18px; }
    .feature-card a { color:#1456a0; font-weight:bold; text-decoration:none; }
    .member-callout { margin-top:24px; border-radius:20px; background:#071d49; color:#fff; padding:26px 28px; display:flex; justify-content:space-between; align-items:center; gap:24px; }
    .member-callout h2 { color:#fff; margin:0 0 7px; }
    .member-callout p { margin:0; color:rgba(255,255,255,.84); line-height:1.6; }
    @media (max-width: 820px) { .home-stats, .feature-grid { grid-template-columns:1fr; } .section-heading { display:block; } .member-callout { display:block; } .member-callout .button { margin-top:18px; } }
</style>
<main class="page-shell">
    <section class="home-hero">
        <div class="eyebrow">Paco Savings &amp; Credit Cooperative</div>
        <h1>Helping People Help Themselves</h1>
        <p class="intro">Save with purpose. Borrow responsibly. Grow together.</p>
        <div class="home-actions">
            <a class="button" href="/paco_cooperative/public/register.php">Become a Member</a>
            <a class="button secondary" href="/paco_cooperative/public/about.php">Learn About PASCCO</a>
        </div>
        <div class="home-stats">
            <div class="home-stat"><strong>Save with purpose</strong><span>Savings options for different goals.</span></div>
            <div class="home-stat"><strong>Borrow responsibly</strong><span>Loan options for work and personal needs.</span></div>
            <div class="home-stat"><strong>Stay connected</strong><span>Access your cooperative services online.</span></div>
        </div>
    </section>

    <section class="section-heading">
        <div>
            <div class="eyebrow">What PASCCO offers</div>
            <h2>Services built around our members</h2>
        </div>
        <p>Explore savings, loans, and member services.</p>
    </section>

    <section class="feature-grid">
        <article class="feature-card">
            <div class="feature-icon"><i class='bx bx-wallet'></i></div>
            <h3>Savings</h3>
            <p>Compare savings options for different needs and goals.</p>
            <a href="/paco_cooperative/public/savings.php">View savings products <i class='bx bx-right-arrow-alt'></i></a>
        </article>
        <article class="feature-card">
            <div class="feature-icon"><i class='bx bx-trending-up'></i></div>
            <h3>Credit</h3>
            <p>Review loan categories before applying.</p>
            <a href="/paco_cooperative/public/credit.php">Explore loan products <i class='bx bx-right-arrow-alt'></i></a>
        </article>
        <article class="feature-card">
            <div class="feature-icon"><i class='bx bx-user-circle'></i></div>
            <h3>Member Portal</h3>
            <p>View accounts, transactions, deposits, transfers, and loan applications.</p>
            <a href="/paco_cooperative/public/login.php">Sign in to your account <i class='bx bx-right-arrow-alt'></i></a>
        </article>
    </section>

    <section class="member-callout">
        <div>
            <h2>Ready to become part of PASCCO?</h2>
            <p>Check qualifications and required documents before registering.</p>
        </div>
        <a class="button" href="/paco_cooperative/public/requirements.php">View Requirements</a>
    </section>
</main>
    <?php pascco_footer(); ?>
