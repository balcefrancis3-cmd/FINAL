<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/pascco_layout.php';

pascco_header('Announcements', 'announcements');

$stmt = $pdo->query("SELECT title, body, image_path, published_at FROM announcements WHERE status = 'published' AND audience IN ('public', 'both') ORDER BY published_at DESC, id DESC");
$announcements = $stmt->fetchAll();
?>

    

<main class="announcements-page">
    <section class="hero" aria-labelledby="announcements-title">
        <div class="hero-inner">
            <div class="eyebrow">PASCCO community</div>
            <h1 id="announcements-title">Announcements</h1>
            <p>Stay connected with the latest cooperative news, service updates, activities, and important member information.</p>
        </div>
    </section>

    <div class="section-head">
        <div>
            <h2>Latest updates</h2>
        </div>
        <p><?php echo count($announcements); ?> published announcement<?php echo count($announcements) === 1 ? '' : 's'; ?></p>
    </div>

    <?php if ($announcements): ?>
        <section class="announcement-grid" aria-label="Community announcements">
            <?php foreach ($announcements as $announcement): ?>
                <article class="announcement-card">
                    <?php if (!empty($announcement['image_path'])): ?>
                        <div class="announcement-media">
                            <img
                                src="<?php echo htmlspecialchars($announcement['image_path'], ENT_QUOTES, 'UTF-8'); ?>"
                                alt="<?php echo htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8'); ?>"
                                loading="lazy"
                            >
                        </div>
                    <?php else: ?>
                        <div class="announcement-media placeholder" aria-hidden="true">
                            <div>
                                <span>✦</span>
                                PASCCO update
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="announcement-content">
                        <div class="announcement-date">
                            <?php echo htmlspecialchars(date('F j, Y', strtotime($announcement['published_at'])), ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <h3><?php echo htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                        <p class="announcement-body"><?php echo htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <div class="announcement-footer">Published by PASCCO Cooperative</div>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php else: ?>
        <section class="empty-state" aria-live="polite">
            <div>
                <div class="empty-icon" aria-hidden="true">✦</div>
                <h2>No announcements yet</h2>
                <p>New PASCCO community updates will appear here as soon as they are published.</p>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php pascco_footer(); ?>

