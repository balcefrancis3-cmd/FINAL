-- PASCCO Loan System Step 10
-- Delinquency and collection follow-up notes.
-- This migration does not change balances, schedules, or loan status.

CREATE TABLE IF NOT EXISTS loan_collection_notes (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id INT UNSIGNED NOT NULL,
    contact_date DATE NOT NULL,
    contact_method VARCHAR(40) NOT NULL,
    outcome VARCHAR(100) NOT NULL,
    promise_date DATE NULL,
    promise_amount DECIMAL(15,2) NULL,
    notes TEXT NULL,
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_collection_notes_loan_date (loan_id, contact_date),
    KEY idx_collection_notes_promise_date (promise_date),
    CONSTRAINT fk_collection_notes_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE,
    CONSTRAINT fk_collection_notes_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
