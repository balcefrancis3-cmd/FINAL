PASCCO — FINAL COMPILED PROJECT
Includes the integrated PASCCO application and Animation Phases 1–7.

LOCAL INSTALLATION (XAMPP)
1. Back up your existing project folder and database first.
2. Copy this folder into XAMPP's htdocs and name it paco_cooperative.
3. Check includes/db.php (or the project's database configuration) and set your local database credentials.
4. Start Apache and MySQL, then open http://localhost/paco_cooperative/.
5. Test public pages, member login/dashboard, admin pages, loan/deposit/transfer flows, settings, and announcements.

PHASE 1 SIMULATION WORKFLOW
1. Before using the updated project, import database_migration_phase1_withdrawal_approval.sql into the existing paco_cooperative database using phpMyAdmin. Back up the database first.
2. Member withdrawals now create pending requests and do not immediately deduct the simulated balance. The single admin reviews them at Admin > Withdrawal Reviews. Approval rechecks the current balance and posts the debit and completed transaction together. Rejection leaves the balance unchanged.
3. This phase does not connect to real banks or move real money. Existing completed historical transactions are not converted or deleted.

DATABASE WARNING
This package includes the project's existing SQL schema and multiple incremental migration files.
Do NOT import every SQL file indiscriminately into an existing database. Some migrations are intended to run once and in a specific order; applying them again may cause duplicate-column/index errors. Back up the database and use the migration appropriate to the current schema state.

SECURITY / TESTING
The package has previously passed PHP syntax and JavaScript syntax checks, but local end-to-end testing is still required after installation. Do not use real member financial data until the application has been tested and secured in the deployment environment.

PHASE 2 UPDATE — FINANCIAL CALCULATION ACCURACY
The Phase 2 package adds includes/money.php and uses integer centavos for key financial input validation, balance comparisons, loan calculations, repayment allocations, and restructuring calculations. No SQL migration is required because the schema is unchanged. Run `php tests/phase2_money_tests.php` from the project directory to run the CLI-only monetary regression tests. See `PHASE_2_FINANCIAL_PRECISION_REPORT.txt` for scope and verification limitations.


PHASE 5 — TESTING, REPORTS, AND SIMULATION RESET
See PHASE_5_TESTING_REPORTS_RESET.txt. The admin has a read-only Simulation Reconciliation page. A CLI-only reset tool is dry-run by default and requires explicit confirmation to delete simulation activity and zero account balances; it preserves accounts, members, users, loan product configuration, and audit logs. Back up first and never use the reset tool with real-money data.

MIGRATION TRACKING
Import database_migration_phase5_tracking.sql once after backing up. tools/migration_tracker.php lists migration files and checksums; it never executes SQL files. Mark a migration only after manually applying and verifying it.


PHASE 6 — OPTIONAL PRODUCTION PREPARATION
See PHASE_6_OPTIONAL_PRODUCTION_PREPARATION.md. Run `php tools\deployment_readiness.php` from Command Prompt for a read-only checklist. The local-only access guard remains enabled. This phase does not make PASCCO production-ready or authorize remote access. Backups must be encrypted, stored outside htdocs, and verified by restoring to a separate disposable database.


PHASE 7 — FINAL UI IMPROVEMENT AND CODE CLEANUP
See PHASE_7_UI_CLEANUP_REPORT.txt. A shared final-loaded stylesheet normalizes page gutters, reduces excess vertical whitespace, aligns public/member/admin content widths, tightens common card/dashboard spacing, and improves responsive table and grid behavior. PASCCO navy/gold styling and banking workflows are preserved. Static checks passed, but visual testing in the local XAMPP browser is still required.
