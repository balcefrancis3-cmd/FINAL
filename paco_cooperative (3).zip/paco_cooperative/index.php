<?php
header('Location: /paco_cooperative/public/home.php');
exit;
