-- PASCCO Loan System Step 8 — Loan Statements and Payment Documents
-- Adds supporting indexes for statement and receipt lookups only.
-- Apply after database_migration_loan_system_step7.sql.

SET @idx_alloc_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'loan_payment_allocations'
      AND INDEX_NAME = 'idx_loan_alloc_statement'
);
SET @sql := IF(
    @idx_alloc_exists = 0,
    'ALTER TABLE loan_payment_allocations ADD INDEX idx_loan_alloc_statement (loan_id, payment_date, id)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_receipt_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'loan_payment_receipts'
      AND INDEX_NAME = 'idx_loan_receipts_statement'
);
SET @sql := IF(
    @idx_receipt_exists = 0,
    'ALTER TABLE loan_payment_receipts ADD INDEX idx_loan_receipts_statement (loan_id, received_at, id)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
