-- PASCCO Step 16 - Membership Data Hardening
-- Adds database-level uniqueness for user/member email addresses.
-- Run AFTER Step 15 and after taking a database backup.
--
-- IMPORTANT:
-- The duplicate checks below are read-only. If either query returns rows,
-- resolve those existing duplicates first. The corresponding ALTER TABLE will
-- then fail rather than silently modifying existing records.

-- PRE-FLIGHT: users with duplicate email addresses
SELECT LOWER(TRIM(email)) AS email, COUNT(*) AS duplicate_count
FROM users
WHERE email IS NOT NULL AND TRIM(email) <> ''
GROUP BY LOWER(TRIM(email))
HAVING COUNT(*) > 1;

-- PRE-FLIGHT: members with duplicate email addresses
SELECT LOWER(TRIM(email)) AS email, COUNT(*) AS duplicate_count
FROM members
WHERE email IS NOT NULL AND TRIM(email) <> ''
GROUP BY LOWER(TRIM(email))
HAVING COUNT(*) > 1;

SET @idx_exists := (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'users'
      AND INDEX_NAME = 'uq_users_email'
);
SET @sql := IF(
    @idx_exists = 0,
    'ALTER TABLE users ADD UNIQUE KEY uq_users_email (email)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_exists := (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'members'
      AND INDEX_NAME = 'uq_members_email'
);
SET @sql := IF(
    @idx_exists = 0,
    'ALTER TABLE members ADD UNIQUE KEY uq_members_email (email)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
