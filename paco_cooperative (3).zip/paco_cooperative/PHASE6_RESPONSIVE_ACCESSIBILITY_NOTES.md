# PASCCO Phase 6 — Responsive Design & Accessibility

## Changes
- Added `assets/css/pascco-responsive-phase6.css` as an additive presentation layer.
- Linked the stylesheet from the shared member/admin shell and the public layout.
- Improved small-screen grid collapse, heading/action wrapping, form control sizing, long-reference wrapping, focus visibility, reduced-motion behavior, and forced-colors outlines.
- Added safe-area padding for shared header/footer and scroll offsets for anchored headings.

## Scope and limitations
- No PHP business logic, SQL, authentication, session, or financial calculations were changed.
- Existing Phase 8 mobile/accessibility CSS remains in place; this file adds a focused follow-up layer.
- This is a code-level pass only. No live browser, screen-reader, keyboard-only, or device-size testing was performed.
- Paths retain the project's existing `/paco_cooperative/` deployment base. If the local folder/URL changes, the existing project asset paths may also need updating.
