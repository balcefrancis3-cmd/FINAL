# PASCCO Phase 1 — Loan Application and Validation

## Baseline
- Base package: `PASCCO_PHASE6_RESPONSIVE_ACCESSIBILITY.zip`
- Existing application path: `member/apply_loan.php`
- Existing calculation helper: `includes/loan_engine.php`
- Existing product/bracket administration: `admin/admin_loan_products.php`
- No database schema changes or data migrations were added in this phase.

## Changes made
1. Added a one-time session nonce to the loan application form. Reusing an already-submitted form token is rejected and the user is asked to review and submit the form again.
2. Added server-side format and length checks for the loan purpose, contact number, address, occupation, employer/business name, and government ID number.
3. Wrapped the new loan row and its application audit row in a single database transaction. The audit row is written directly in this transaction because the shared `record_audit()` helper intentionally suppresses write errors. If the insert or audit write fails, the transaction is rolled back.
4. Kept existing server-side checks for active product/bracket selection, amount range, income range, configured savings requirement, birth date, required documents, MIME type, upload size, and configured repayment calculation.
5. Preserved the existing loan status (`pending`) and did not change approval policy or create sample loan products/brackets.
6. Added `tests/phase1_loan_application_validation_tests.php` for static regression checks.

## Files changed
- `member/apply_loan.php`
- `tests/phase1_loan_application_validation_tests.php`
- `PHASE1_LOAN_APPLICATION_VALIDATION_REPORT.md` (this report)

## Tests performed
- PHP syntax check: all 171 PHP files passed.
- Phase 1 static checks: 10 passed, 0 failed.
- Existing Phase 3 loan configuration static checks: 9 passed, 0 failed.
- Existing Phase 2 money calculation tests: 16 passed, 0 failed.
- ZIP integrity check: performed on the generated package.

## Not tested in this environment
- Live XAMPP/MariaDB submission, database transaction behavior, and record preservation.
- Actual upload requests and web-server access restrictions.
- Browser-side behavior, including the one-time nonce after validation errors.
- Concurrent submissions under the exact PHP session handler configured by the user.
- Real loan decisions against cooperative-approved bracket values.

## Notes / remaining risks
- The current active brackets and financial policy values remain administrator-configured; no rates, amounts, or eligibility rules were invented.
- This phase adds form replay protection, but a database-backed idempotency key could provide stronger protection across independent sessions if desired. That would require a carefully reviewed additive migration and should be considered only after confirming the production schema.
- This phase does not generate certificates, change email OTP, modify SMTP, implement OCR, or change dashboard/database normalization. Those belong to later phases.
- Back up the project and database before deploying. The archive does not apply migrations or alter the live database.
